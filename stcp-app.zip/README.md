# Próxima Paragem (app STCP para iPhone)

Web app (PWA) que se instala no ecrã principal do iPhone pelo Safari. Não precisa de Mac, App Store nem conta de programador Apple. Custo: **0 €** (GitHub Pages + Cloudflare Workers, planos gratuitos).

**O que faz**
1. **Origem**: paragem (nome ou código, ex.: `BCM1`), morada/local, ponto no mapa ou a localização atual. As 4 paragens mais próximas (GPS) aparecem como sugestão. Com uma morada, o app considera todas as paragens a pé até ~800 m e escolhe a que dá o melhor percurso.
2. **Destino**: as mesmas opções (paragem, código, morada ou ponto no mapa).
3. **Buscar**: opções de **autocarro STCP e metro** (diretas e com os transbordos necessários, a pé entre paragens quando preciso), com:
   - hora do próximo autocarro, marcada **TEMPO REAL** (dados ao vivo da STCP) ou **PREVISÃO** (horário oficial);
   - próximas partidas seguintes;
   - **zona Andante** necessária (Z2, Z3…), preço 2026 e zonas atravessadas;
   - **aviso de meteorologia** na origem e no destino (temperatura e, se for caso disso, guarda-chuva, casaco, água, protetor solar, vento, neve ou trovoada);
   - mapa com o trajeto; se a rede não chega perto do destino, o troço em falta aparece **a vermelho**, com atalhos para continuar a pé, de comboio (Apple Mapas / Google Maps) ou TVDE (Uber).

---

## 1. Publicar o app (GitHub, grátis) — ~10 min

Funciona tanto num computador como só no iPhone (Safari).

1. Crie uma conta em <https://github.com> (se ainda não tiver).
2. **Novo repositório**: botão **+ › New repository**. Nome: `paragem`. Marque **Public**. Crie.
3. **Ativar o site**: no repositório, **Settings › Pages › Build and deployment › Source: GitHub Actions**.
4. **Enviar o app**: separador **Code › Add file › Upload files** e envie o ficheiro **`stcp-app.zip`** (tal como está, sem descompactar). Clique **Commit changes**.
5. **Criar o publicador**: **Add file › Create new file**. No nome escreva exatamente
   `.github/workflows/publicar.yml`
   e cole o conteúdo do ficheiro `publicar.yml` que acompanha o zip. **Commit changes**.
6. Abra o separador **Actions**: o fluxo *Atualizar dados e publicar* corre sozinho (2–4 min). Quando ficar verde, o app está em
   `https://SEU-UTILIZADOR.github.io/paragem/`

A partir daí o GitHub lê os horários da STCP **todos os dias às ~05:30** e republica. Para forçar: **Actions › Atualizar dados e publicar › Run workflow**.

> Num computador, em alternativa ao passo 4, pode descompactar o zip e arrastar todas as pastas para a página de upload.

## 2. Tempo real (opcional, grátis) — ~5 min

O iPhone não pode ler diretamente os tempos de chegada do site da STCP (bloqueio de segurança do browser, CORS). Um pequeno "proxy" na Cloudflare resolve isso.

1. Crie conta em <https://dash.cloudflare.com/sign-up> (plano Free).
2. **Workers & Pages › Create › Create Worker** › nome `stcp-rt` › **Deploy**.
3. **Edit code**: apague o conteúdo, cole o ficheiro `cloudflare-worker/worker.js` › **Deploy**.
4. Copie o endereço (ex.: `https://stcp-rt.seu-nome.workers.dev`).
5. Coloque o endereço em `site/config.js` (`REALTIME_PROXY`), para vir já configurado para todos os utilizadores. (Alternativa por aparelho: **⚙︎ Definições › Avançado**.)

Sem este passo o app funciona na mesma, mas todos os horários aparecem como **PREVISÃO**.

## 3. Instalar no iPhone

Safari › abra `https://SEU-UTILIZADOR.github.io/paragem/` › botão **Partilhar** › **Adicionar ao ecrã principal**. Abra pelo ícone e aceite o pedido de localização.

---

## Validação recomendada na primeira utilização

- [ ] **⚙︎ Definições** mostra a data dos horários, nº de paragens e quantas têm zona Andante (deve ser perto do total).
- [ ] Compare 2–3 percursos que conhece com o site da STCP / Google Maps (linhas e horas).
- [ ] Zona: confira 2–3 percursos com o [mapa de zonas Andante](https://andante.pt/comprar/andante-azul/zonas/). Se uma zona estiver errada, veja "Ajustar zonas".
- [ ] Tempo real: numa paragem com autocarro a chegar, confirme que o badge verde **TEMPO REAL** bate com o painel da paragem.

## Como funciona (resumo técnico)

| Parte | Fonte | Notas |
|---|---|---|
| Paragens, linhas, horários, zonas | API do site da STCP (`stcp.pt/api/route/...`), lida todos os dias pelo GitHub | não oficial; se o Portal de Dados Abertos do Porto voltar, o GTFS dele é usado como alternativa automática |
| Metro do Porto | GTFS oficial da página [Mapas e horários](https://www.metrodoporto.pt/pages/337) | o link é lido da própria página (o nome do ficheiro muda a cada atualização); 6 linhas, 85 estações; junta-se à rede da STCP e entra nos percursos e transbordos |
| Horas das paragens intermédias | calculadas pela distância entre timepoints, o mesmo método da STCP | validado contra o site: 31 de 33 horas iguais ao segundo, 2 com 1 s de diferença (paragem CORI1, linha 701) |
| Calendário (dia útil, sábado, domingo/feriado) | `services?date=` da API, dia a dia, 8 dias à frente | inclui feriados |
| Percursos | algoritmo RAPTOR no próprio iPhone (`site/js/engine.js`) | até 4 transbordos; transbordo a pé até 400 m; último troço a pé até 1,2 km |
| Tempo real | `stcp.pt/api/stops/{código}/realtime` via Worker | a STCP mistura previsões ao vivo e horas do horário no mesmo campo; o app marca **Previsão** quando a hora coincide com o horário (±20 s) e **Tempo real** quando não coincide |
| Zona Andante | `zone_id` de cada paragem, dado pela STCP e pelo Metro | anéis contados a partir da zona da 1.ª validação, contando todas as zonas atravessadas; vizinhança e distâncias entre zonas deduzidas das linhas e da tabela oficial do Metro (`scripts/zonas_ajustes.json`) |
| Zona em percursos só de metro | tabela oficial do planeador do Metro do Porto (`scripts/metro_titulos.json`) | 3 928 pares de estações; usada tal e qual quando a viagem não sai do metro — validada a 100 % contra o planeador |
| Preços | tarifário Andante 2026 (Z2 1,40 € … Z9 4,65 €) | editar em `site/js/engine.js` (`ANDANTE`) se mudar |
| Moradas | Photon / OpenStreetMap (Nominatim como alternativa) | gratuito, sem chave |
| Mapa | OpenStreetMap (sem chave); traçados das linhas de `wab.stcp.pt` | |
| Meteorologia | [Open-Meteo](https://open-meteo.com) (gratuito, sem chave, uso não comercial) | temperatura e avisos na origem à partida e no destino à hora de chegada; a sensação térmica já inclui o vento; limiares calibrados para o Porto em `site/js/weather.js` (`RULES`); desliga-se em `site/config.js` (`WEATHER: false`) |

### Se a STCP bloquear o GitHub
Se o passo de horários falhar com erros 403 ou "timed out" para `stcp.pt`, use o Worker da Cloudflare como intermediário:
**Settings › Secrets and variables › Actions › Variables › New repository variable**, nome `STCP_PROXY`, valor `https://stcp-rt.SEU-NOME.workers.dev`, e corra de novo o fluxo.

### Ajustar zonas
Se duas zonas fazem fronteira mas nenhuma linha as liga diretamente, o app pode sobrestimar o Z. Edite `scripts/zonas_ajustes.json` (dentro do zip, ou descompactado no repositório) e corra de novo o fluxo:
```json
{
  "adjacencias_extra": { "PRT1": ["GDM1"] },
  "distancias_oficiais": { "MTS1|MAI4": 2 },
  "zona_por_paragem": { "BCM1": "PRT1" }
}
```
- `adjacencias_extra`: zonas que fazem fronteira.
- `distancias_oficiais`: número de anéis entre duas zonas quando ele é conhecido (`Z` − 1). Manda sobre o cálculo automático; o ficheiro já traz os 78 pares que se tiram do planeador do Metro.
- `zona_por_paragem`: corrige a zona de uma paragem pelo código.

### Limitações conhecidas
- Horários vêm de uma API não oficial do site da STCP: se ela mudar, a atualização diária falha e o app continua com os últimos horários publicados até eu (ou alguém) adaptar o script.
- O metro entra nos percursos com os **horários oficiais**, mas **sem tempo real**: o Metro não publica previsões de chegada, por isso as horas do metro aparecem sempre como **PREVISÃO**.
- A CP (comboios) **não** entra no cálculo; aparece só como opção para o troço que a rede não cobre (via Apple Mapas/Google Maps).
- Fora do metro, a zona é uma estimativa a partir dos dados; valide antes de confiar a 100%.
- App não oficial, sem ligação à STCP ou à TIP/Andante.
