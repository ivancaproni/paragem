# Próxima Paragem (app STCP para iPhone)

Web app (PWA) que se instala no ecrã principal do iPhone pelo Safari. Não precisa de Mac, App Store nem conta de programador Apple. Custo: **0 €** (GitHub Pages + Cloudflare Workers, planos gratuitos).

**O que faz**
1. **Origem**: escolhe a paragem de partida. As 4 paragens mais próximas (GPS) aparecem como sugestão; pesquisa por nome ou código (ex.: `BCM1`).
2. **Destino**: morada/local (pesquisa OpenStreetMap), paragem, ou ponto tocado no mapa.
3. **Buscar**: opções de linhas STCP (diretas e com os transbordos necessários, a pé entre paragens quando preciso), com:
   - hora do próximo autocarro, marcada **TEMPO REAL** (dados ao vivo da STCP) ou **PREVISÃO** (horário oficial);
   - próximas partidas seguintes;
   - **zona Andante** necessária (Z2, Z3…), preço 2026 e zonas atravessadas;
   - mapa com o trajeto; se a STCP não chega perto do destino, o troço em falta aparece **a vermelho**, com atalhos para continuar a pé, de metro/comboio (Apple Mapas / Google Maps) ou TVDE (Uber).

---

## 1. Publicar o app (GitHub, grátis) — ~10 min

Funciona tanto num computador como só no iPhone (Safari).

1. Crie uma conta em <https://github.com> (se ainda não tiver).
2. **Novo repositório**: botão **+ › New repository**. Nome: `paragem`. Marque **Public**. Crie.
3. **Ativar o site**: no repositório, **Settings › Pages › Build and deployment › Source: GitHub Actions**.
4. **Enviar o app**: separador **Code › Add file › Upload files** e envie o ficheiro **`stcp-app.zip`** (tal como está, sem descompactar). Clique **Commit changes**.
5. **Criar o publicador**: **Add file › Create new file**. No nome escreva exatamente
   `.github/workflows/publicar.yml`
   e cole o conteúdo do ficheiro `publicar.yml` que acompanha o zip. **Commit changes**.
6. Abra o separador **Actions**: o fluxo *Atualizar dados e publicar* corre sozinho (2–4 min). Quando ficar verde, o app está em
   `https://SEU-UTILIZADOR.github.io/paragem/`

A partir daí o GitHub descarrega o GTFS mais recente da STCP **todos os dias às ~05:30** e republica. Para forçar: **Actions › Atualizar dados e publicar › Run workflow**.

> Num computador, em alternativa ao passo 4, pode descompactar o zip e arrastar todas as pastas para a página de upload.

## 2. Tempo real (opcional, grátis) — ~5 min

O iPhone não pode ler diretamente os tempos de chegada do site da STCP (bloqueio de segurança do browser, CORS). Um pequeno "proxy" na Cloudflare resolve isso.

1. Crie conta em <https://dash.cloudflare.com/sign-up> (plano Free).
2. **Workers & Pages › Create › Create Worker** › nome `stcp-rt` › **Deploy**.
3. **Edit code**: apague o conteúdo, cole o ficheiro `cloudflare-worker/worker.js` › **Deploy**.
4. Copie o endereço (ex.: `https://stcp-rt.seu-nome.workers.dev`).
5. No app: **⚙︎ Definições** › cole o endereço › **Testar** (deve aparecer `OK ✓` e um JSON com `arrivals`) › **Guardar**.

Sem este passo o app funciona na mesma, mas todos os horários aparecem como **PREVISÃO**.

## 3. Instalar no iPhone

Safari › abra `https://SEU-UTILIZADOR.github.io/paragem/` › botão **Partilhar** › **Adicionar ao ecrã principal**. Abra pelo ícone e aceite o pedido de localização.

---

## Validação recomendada na primeira utilização

- [ ] **⚙︎ Definições** mostra a data dos horários, nº de paragens e quantas têm zona Andante (deve ser perto do total).
- [ ] Compare 2–3 percursos que conhece com o site da STCP / Google Maps (linhas e horas).
- [ ] Zona: confira 2–3 percursos com o [mapa de zonas Andante](https://andante.pt/comprar/andante-azul/zonas/). Se uma zona estiver errada, veja "Ajustar zonas".
- [ ] Tempo real: numa paragem com autocarro a chegar, confirme que o badge verde **TEMPO REAL** bate com o painel da paragem.

## Como funciona (resumo técnico)

| Parte | Fonte | Notas |
|---|---|---|
| Paragens, linhas, horários | GTFS STCP, [Portal de Dados Abertos do Porto](https://opendata.porto.digital/dataset/horarios-paragens-e-rotas-em-formato-gtfs-stcp) (CC0) | processado todos os dias em `scripts/build_data.py` para JSON compacto |
| Percursos | algoritmo RAPTOR no próprio iPhone (`site/js/engine.js`) | até 4 transbordos; transbordo a pé até 400 m; último troço a pé até 1,2 km |
| Tempo real | `https://stcp.pt/api/stops/{código}/realtime` via Worker | endpoint **não oficial** do site da STCP; pode mudar sem aviso — o app volta a mostrar PREVISÃO |
| Zona Andante | `zone_id` das paragens no GTFS (ou API da STCP se faltar) | anéis contados a partir da zona da 1.ª validação; vizinhança entre zonas deduzida das próprias linhas |
| Preços | tarifário Andante 2026 (Z2 1,40 € … Z9 4,65 €) | editar em `site/js/engine.js` (`ANDANTE`) se mudar |
| Moradas | Photon / OpenStreetMap (Nominatim como alternativa) | gratuito, sem chave |
| Mapa | OpenStreetMap + CARTO | |

### Ajustar zonas
Se duas zonas fazem fronteira mas nenhuma linha STCP as liga diretamente, o app pode sobrestimar o Z. Edite `scripts/zonas_ajustes.json` (dentro do zip, ou descompactado no repositório) e corra de novo o fluxo:
```json
{ "adjacencias_extra": { "PRT1": ["GDM1"] }, "zona_por_paragem": { "BCM1": "PRT1" } }
```

### Limitações conhecidas
- Metro do Porto e CP **não** entram no cálculo; aparecem só como opção para o troço que a STCP não cobre (via Apple Mapas/Google Maps).
- A zona é uma estimativa a partir dos dados; valide antes de confiar a 100%.
- App não oficial, sem ligação à STCP ou à TIP/Andante.
