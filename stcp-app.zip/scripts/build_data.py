#!/usr/bin/env python3
"""
Gera os dados do app (site/data/*.json) a partir de uma de duas fontes:

  1. API do site da STCP (stcp.pt)                      -> fonte principal
  2. GTFS do Portal de Dados Abertos do Porto (CC0)     -> alternativa, se voltar a existir

Uso:
  python scripts/build_data.py                  # tenta STCP API e depois o portal
  python scripts/build_data.py --source gtfs    # so o portal
  python scripts/build_data.py --gtfs feed.zip  # GTFS local
Variavel opcional STCP_PROXY=https://<worker>.workers.dev  (se o GitHub for bloqueado pela STCP)
"""
import argparse
import csv
import io
import json
import math
import os
import re
import sys
import time
import urllib.parse
import urllib.request
import zipfile
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

try:
    from zoneinfo import ZoneInfo
    LISBON = ZoneInfo("Europe/Lisbon")
except Exception:  # noqa: BLE001
    LISBON = timezone.utc

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "site", "data")
ZONE_OVERRIDES = os.path.join(ROOT, "scripts", "zonas_ajustes.json")
UA = {"User-Agent": "Mozilla/5.0 (proxima-paragem build; uso pessoal)", "Accept": "application/json, text/html"}
DAYS_AHEAD = 8
TRAMS = {"1", "18", "22"}  # eletricos: fora do tarifario Andante ocasional

# lista de reserva caso a pagina /pt/linhas mude (confirmada em 20/09/2026)
FALLBACK_ROUTES = """200 201 202 203 204 205 206 207 208 209 300 301 302 303 304 305 400 401 402 403 404
500 501 502 503 504 505 506 507 508 600 601 602 603 604 605 700 701 702 703 704 705 706 707
800 801 803 804 805 806 900 901 902 903 904 905 906 907 ZC 1M 2M 3M 4M 5M 7M 8M 9M 10M 11M 12M 13M""".split()


# ================================================================ util
def http_get(url, timeout=60, tries=3):
    last = None
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(1.5 * (k + 1))
    raise last


def dist(a, b):
    lat1, lon1, lat2, lon2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 6371000 * 2 * math.asin(math.sqrt(h))


def tsec(s):
    """'25:10:07' -> segundos desde o inicio do dia de servico."""
    if not s:
        return None
    p = s.strip().split(":")
    return int(p[0]) * 3600 + int(p[1]) * 60 + (int(p[2]) if len(p) > 2 else 0)


def simplify(points, tol_m=8.0):
    """Douglas-Peucker (aproximacao planar local)."""
    if len(points) < 3:
        return points
    lat0 = math.radians(points[0][0])
    kx, ky = 111320 * math.cos(lat0), 110540
    xy = [(p[1] * kx, p[0] * ky) for p in points]
    keep = [False] * len(points)
    keep[0] = keep[-1] = True
    stack = [(0, len(points) - 1)]
    while stack:
        i, j = stack.pop()
        (x1, y1), (x2, y2) = xy[i], xy[j]
        dx, dy = x2 - x1, y2 - y1
        d2 = dx * dx + dy * dy
        best, idx = 0.0, -1
        for k in range(i + 1, j):
            x, y = xy[k]
            if d2 == 0:
                dd = math.hypot(x - x1, y - y1)
            else:
                t = max(0, min(1, ((x - x1) * dx + (y - y1) * dy) / d2))
                dd = math.hypot(x - (x1 + t * dx), y - (y1 + t * dy))
            if dd > best:
                best, idx = dd, k
        if best > tol_m and idx > 0:
            keep[idx] = True
            stack += [(i, idx), (idx, j)]
    return [p for p, k in zip(points, keep) if k]


def encode_poly(pts):
    """Polyline do Google (precisao 1e5)."""
    out, plat, plon = [], 0, 0
    for la, lo in pts:
        ila, ilo = int(round(la * 1e5)), int(round(lo * 1e5))
        for v in (ila - plat, ilo - plon):
            v = ~(v << 1) if v < 0 else (v << 1)
            while v >= 0x20:
                out.append(chr((0x20 | (v & 0x1f)) + 63))
                v >>= 5
            out.append(chr(v + 63))
        plat, plon = ila, ilo
    return "".join(out)


def service_days():
    today = datetime.now(LISBON).date()
    return [today - timedelta(days=1) + timedelta(days=i) for i in range(DAYS_AHEAD + 1)]


class Feed:
    """Representacao intermedia comum as duas fontes."""
    def __init__(self, source):
        self.source = source
        self.stops = {}      # id -> [code, name, lat, lon, zone]
        self.routes = {}     # rid -> [short, long, color, text, type]
        self.trips = []      # (rid, dir, head, svc_key, [stop_ids], [secs], shape_key)
        self.shapes = {}     # shape_key -> [(lat, lon)]
        self.calendar = defaultdict(set)  # 'YYYY-MM-DD' -> {svc_key}


# ================================================================ fonte 1: API da STCP
class StcpApi:
    def __init__(self, proxy=None):
        self.proxy = (proxy or "").rstrip("/")

    def url(self, host, path):
        if self.proxy:
            return f"{self.proxy}/{'wab' if host == 'wab' else 'api'}{path}"
        return (f"https://wab.stcp.pt/tracking/api{path}" if host == "wab" else f"https://stcp.pt/api{path}")

    def get(self, path, host="stcp"):
        return json.loads(http_get(self.url(host, path), 40))

    def route_ids(self):
        try:
            base = f"{self.proxy}/page/linhas" if self.proxy else "https://stcp.pt/pt/linhas"
            html = http_get(base, 40).decode("utf-8", "replace")
            ids = []
            for m in re.findall(r'/pt/linhas/([A-Za-z0-9]+)["\'?#]', html):
                if m not in ids:
                    ids.append(m)
            if len(ids) >= 40:
                return ids
            print(f"Aviso: so encontrei {len(ids)} linhas na pagina; uso a lista de reserva.")
        except Exception as e:  # noqa: BLE001
            print("Aviso: pagina de linhas indisponivel:", e)
        return list(FALLBACK_ROUTES)


def interpolate(dir_stops, idx_times):
    """dir_stops: [(id, lat, lon)]; idx_times: [(indice, segundos)] ordenado.
    Devolve (stop_ids, secs) do primeiro ao ultimo timepoint, com as paragens
    intermedias interpoladas pela distancia em linha reta (metodo da STCP)."""
    a0, a1 = idx_times[0][0], idx_times[-1][0]
    ids = [s[0] for s in dir_stops[a0:a1 + 1]]
    cum = [0.0]
    for p, q in zip(dir_stops[a0:a1], dir_stops[a0 + 1:a1 + 1]):
        cum.append(cum[-1] + dist((p[1], p[2]), (q[1], q[2])))
    secs = [None] * len(ids)
    for (i, t) in idx_times:
        secs[i - a0] = t
    for (i, t), (j, u) in zip(idx_times, idx_times[1:]):
        i, j = i - a0, j - a0
        span = cum[j] - cum[i]
        for k in range(i + 1, j):
            f = (cum[k] - cum[i]) / span if span > 0 else (k - i) / (j - i)
            secs[k] = int(math.floor(t + f * (u - t) + 1e-6))  # a STCP trunca os segundos
    return ids, secs


def load_stcp_api(proxy=None):
    api = StcpApi(proxy)
    feed = Feed("stcp.pt (API do site)")
    days = service_days()
    routes = [r for r in api.route_ids() if r not in TRAMS]
    print(f"STCP API: {len(routes)} linhas")
    failures = []

    def do_route(rid):
        out = {"stops": {}, "trips": [], "shapes": {}, "cal": defaultdict(set), "route": None}
        q = urllib.parse.quote
        active = set()
        for d in days:
            r = api.get(f"/route/{q(rid)}/services?date={d.isoformat()}")
            sid = r.get("active_service_id")
            if sid and str(r.get("selected_date", "")).replace("-", "") == d.strftime("%Y%m%d"):
                out["cal"][d.isoformat()].add(f"{rid}|{sid}")
                active.add(sid)
        for direction in (0, 1):
            try:
                st = api.get(f"/route/{q(rid)}/stops/direction?direction_id={direction}")
            except Exception:  # noqa: BLE001
                continue
            stops = sorted(st.get("stops") or [], key=lambda s: s.get("stop_sequence") or 0)
            if len(stops) < 2:
                continue
            dir_stops = []
            seq_idx = {}
            for i, s in enumerate(stops):
                sid = s["stop_id"]
                out["stops"][sid] = [s.get("stop_code") or sid, (s.get("stop_name") or sid).strip(),
                                     round(float(s["stop_lat"]), 6), round(float(s["stop_lon"]), 6), s.get("zone_id") or ""]
                dir_stops.append((sid, float(s["stop_lat"]), float(s["stop_lon"])))
                seq_idx[s.get("stop_sequence")] = i
            shape_key = f"{rid}_{direction}"
            try:
                w = api.get(f"/route-stops?route={q(rid)}&direction={direction}", host="wab")
                if w.get("shape"):
                    out["shapes"][shape_key] = [(float(a), float(b)) for a, b in w["shape"]]
                ro = w.get("route") or {}
                out["route"] = out["route"] or [ro.get("short") or rid, ro.get("long") or "", ro.get("color") or "", "FFFFFF", 3]
            except Exception:  # noqa: BLE001
                pass
            for sid in sorted(active):
                sc = api.get(f"/route/{q(rid)}/schedule?service_id={q(sid)}&direction_id={direction}")
                sel = sc.get("selected_stops") or []
                for trip in sc.get("schedule") or []:
                    tps = trip.get("stops") or []
                    idx_times = []
                    for n, tp in enumerate(tps):
                        t = tsec(tp.get("departure_time") or tp.get("arrival_time"))
                        if t is None:
                            continue
                        i = None
                        if len(sel) == len(tps):
                            i = seq_idx.get(sel[n].get("stopSequence"))
                        if i is None:  # procura sequencial pelo id
                            start = idx_times[-1][0] + 1 if idx_times else 0
                            i = next((k for k in range(start, len(dir_stops)) if dir_stops[k][0] == tp.get("stop_id")), None)
                        if i is not None and (not idx_times or i > idx_times[-1][0]):
                            idx_times.append((i, t))
                    if len(idx_times) < 2:
                        continue
                    ids, secs = interpolate(dir_stops, idx_times)
                    out["trips"].append((rid, direction, (trip.get("trip_headsign") or "").strip(),
                                         f"{rid}|{sid}", ids, secs, shape_key))
        if out["route"] is None:
            out["route"] = [rid, "", "", "FFFFFF", 3]
        return rid, out

    def safe(rid):
        try:
            return do_route(rid)
        except Exception as e:  # noqa: BLE001
            return rid, e

    with ThreadPoolExecutor(6) as ex:
        for rid, res in ex.map(safe, routes):
            if isinstance(res, Exception) or not res["trips"]:
                failures.append((rid, str(res)[:120] if isinstance(res, Exception) else "sem viagens"))
                continue
            feed.routes[rid] = res["route"]
            feed.stops.update(res["stops"])
            feed.trips += res["trips"]
            feed.shapes.update(res["shapes"])
            for d, s in res["cal"].items():
                feed.calendar[d] |= s
    for rid, why in failures:
        print(f"  linha {rid}: {why}")
    if len(failures) > len(routes) * 0.3:
        raise RuntimeError(f"Falharam {len(failures)} de {len(routes)} linhas na API da STCP")
    feed.failures = failures
    return feed


# ================================================================ fonte 2: GTFS do portal
DATASET = "horarios-paragens-e-rotas-em-formato-gtfs-stcp"
CKAN = "https://opendata.porto.digital/api/3/action/package_show?id=" + DATASET


def latest_gtfs_url():
    data = json.loads(http_get(CKAN, 60, 1))
    res = [r for r in data["result"]["resources"]
           if (r.get("format") or "").lower() in ("zip", "gtfs", "application/zip")
           or (r.get("url") or "").lower().endswith(".zip")]
    res.sort(key=lambda r: r.get("created") or r.get("last_modified") or "")
    if not res:
        raise RuntimeError("portal sem recursos GTFS")
    return res[-1]["url"]


def read_csv(zf, name):
    names = {os.path.basename(n): n for n in zf.namelist()}
    if name not in names:
        return []
    return list(csv.DictReader(io.StringIO(zf.read(names[name]).decode("utf-8-sig", "replace"))))


def load_gtfs(zf, source):
    feed = Feed(source)
    for r in read_csv(zf, "stops.txt"):
        if ((r.get("location_type") or "0").strip() or "0") != "0":
            continue
        try:
            lat, lon = round(float(r["stop_lat"]), 6), round(float(r["stop_lon"]), 6)
        except (KeyError, ValueError):
            continue
        sid = r["stop_id"].strip()
        feed.stops[sid] = [(r.get("stop_code") or "").strip() or sid, (r.get("stop_name") or sid).strip(),
                           lat, lon, (r.get("zone_id") or "").strip()]
    for r in read_csv(zf, "routes.txt"):
        rid = r["route_id"].strip()
        feed.routes[rid] = [(r.get("route_short_name") or rid).strip(), (r.get("route_long_name") or "").strip(),
                            (r.get("route_color") or "").strip(), (r.get("route_text_color") or "").strip(),
                            int((r.get("route_type") or "3").strip() or 3)]
    days = service_days()
    wd = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    for r in read_csv(zf, "calendar.txt"):
        a = datetime.strptime(r["start_date"].strip(), "%Y%m%d").date()
        b = datetime.strptime(r["end_date"].strip(), "%Y%m%d").date()
        for d in days:
            if a <= d <= b and r.get(wd[d.weekday()], "0").strip() == "1":
                feed.calendar[d.isoformat()].add(r["service_id"].strip())
    for r in read_csv(zf, "calendar_dates.txt"):
        d = datetime.strptime(r["date"].strip(), "%Y%m%d").date()
        if d not in days:
            continue
        (feed.calendar[d.isoformat()].add if r["exception_type"].strip() == "1"
         else feed.calendar[d.isoformat()].discard)(r["service_id"].strip())
    trips = {r["trip_id"].strip(): r for r in read_csv(zf, "trips.txt") if r["route_id"].strip() in feed.routes}
    st = defaultdict(list)
    names = {os.path.basename(n): n for n in zf.namelist()}
    with zf.open(names["stop_times.txt"]) as fh:
        for r in csv.DictReader(io.TextIOWrapper(fh, encoding="utf-8-sig")):
            tid, sid = r["trip_id"].strip(), r["stop_id"].strip()
            if tid in trips and sid in feed.stops:
                t = tsec(r.get("departure_time") or r.get("arrival_time"))
                if t is not None:
                    st[tid].append((int(r["stop_sequence"]), sid, t))
    for tid, rows in st.items():
        rows.sort()
        if len(rows) < 2:
            continue
        tr = trips[tid]
        d = (tr.get("direction_id") or "0").strip()
        feed.trips.append((tr["route_id"].strip(), int(d) if d.isdigit() else 0, (tr.get("trip_headsign") or "").strip(),
                           tr["service_id"].strip(), [x[1] for x in rows], [x[2] for x in rows],
                           (tr.get("shape_id") or "").strip()))
    pts = defaultdict(list)
    for r in read_csv(zf, "shapes.txt"):
        try:
            pts[r["shape_id"].strip()].append((int(r["shape_pt_sequence"]), float(r["shape_pt_lat"]), float(r["shape_pt_lon"])))
        except (KeyError, ValueError):
            pass
    feed.shapes = {k: [(a, b) for _, a, b in sorted(v)] for k, v in pts.items()}
    return feed


# ================================================================ empacotar para o app
def pack(feed):
    if os.path.exists(ZONE_OVERRIDES):
        ov = json.load(open(ZONE_OVERRIDES, encoding="utf-8"))
        for sid, z in ov.get("zona_por_paragem", {}).items():
            for k, s in feed.stops.items():
                if k == sid or s[0] == sid:
                    s[4] = z
    else:
        ov = {}
    stop_ids = sorted(feed.stops)
    sidx = {s: i for i, s in enumerate(stop_ids)}
    rids = sorted(feed.routes, key=lambda r: (len(feed.routes[r][0]), feed.routes[r][0]))
    ridx = {r: i for i, r in enumerate(rids)}
    services = {}
    def svc(k):
        if k not in services:
            services[k] = len(services)
        return services[k]

    patterns = {}
    for (rid, d, head, skey, ids, secs, shk) in feed.trips:
        if rid not in ridx:
            continue
        seq = tuple(sidx[s] for s in ids)
        start = secs[0]
        offs = tuple(t - start for t in secs)
        key = (ridx[rid], d, seq)
        p = patterns.get(key)
        if p is None:
            p = patterns[key] = {"profiles": {}, "trips": [], "heads": Counter(), "shapes": Counter()}
        pi = p["profiles"].setdefault(offs, len(p["profiles"]))
        p["trips"].append((start, pi, svc(skey)))
        p["heads"][head] += 1
        if shk:
            p["shapes"][shk] += 1

    shape_idx, shapes_out = {}, []
    out_patterns, used = [], set()
    for (ri, d, seq), p in sorted(patterns.items(), key=lambda kv: kv[0][:2]):
        sh = -1
        if p["shapes"]:
            k = p["shapes"].most_common(1)[0][0]
            if k in feed.shapes and len(feed.shapes[k]) > 1:
                if k not in shape_idx:
                    shape_idx[k] = len(shapes_out)
                    shapes_out.append(encode_poly(simplify(feed.shapes[k])))
                sh = shape_idx[k]
        out_patterns.append({
            "r": ri, "d": d, "h": p["heads"].most_common(1)[0][0] or feed.stops[stop_ids[seq[-1]]][1],
            "s": list(seq), "sh": sh,
            "p": [list(o) for o, _ in sorted(p["profiles"].items(), key=lambda kv: kv[1])],
            "t": [x for trip in sorted(p["trips"]) for x in trip],
        })
        used.update(seq)

    adj = defaultdict(set)
    for pat in out_patterns:
        zs = [feed.stops[stop_ids[i]][4] for i in pat["s"]]
        for a, b in zip(zs, zs[1:]):
            if a and b and a != b:
                adj[a].add(b)
                adj[b].add(a)
    for a, bs in ov.get("adjacencias_extra", {}).items():
        for b in bs:
            adj[a].add(b)
            adj[b].add(a)

    stops = [[sid] + feed.stops[sid] for sid in stop_ids]
    net = {
        "v": 2,  # tempos em segundos
        "tz": "Europe/Lisbon",
        "stops": stops,
        "routes": [feed.routes[r] for r in rids],
        "services": [k for k, _ in sorted(services.items(), key=lambda kv: kv[1])],
        "calendar": {d: sorted(services[k] for k in ks if k in services) for d, ks in sorted(feed.calendar.items())},
        "patterns": out_patterns,
        "zoneAdj": {k: sorted(v) for k, v in sorted(adj.items())},
        "used": sorted(used),
    }
    days = service_days()
    meta = {
        "generated": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source": feed.source,
        "calendar_from": days[0].isoformat(),
        "calendar_to": days[-1].isoformat(),
        "stops": len(used),
        "stops_with_zone": sum(1 for i in used if stops[i][5]),
        "routes": len(rids),
        "patterns": len(out_patterns),
        "trips": sum(len(p["t"]) // 3 for p in out_patterns),
        "zones": len(adj),
        "days_with_service": sum(1 for v in net["calendar"].values() if v),
        "failed_routes": [r for r, _ in getattr(feed, "failures", [])],
    }
    return net, shapes_out, meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gtfs", help="ficheiro GTFS local (zip)")
    ap.add_argument("--source", choices=["auto", "stcp", "gtfs"], default="auto")
    ap.add_argument("--out", default=OUT)
    a = ap.parse_args()

    feed, errors = None, []
    if a.gtfs:
        feed = load_gtfs(zipfile.ZipFile(a.gtfs), os.path.basename(a.gtfs))
    else:
        order = {"auto": ["stcp", "gtfs"], "stcp": ["stcp"], "gtfs": ["gtfs"]}[a.source]
        for src in order:
            try:
                if src == "stcp":
                    feed = load_stcp_api(os.environ.get("STCP_PROXY"))
                else:
                    url = latest_gtfs_url()
                    feed = load_gtfs(zipfile.ZipFile(io.BytesIO(http_get(url, 300))), url)
                if feed.trips:
                    break
                errors.append(f"{src}: sem viagens")
            except Exception as e:  # noqa: BLE001
                errors.append(f"{src}: {e}")
                print(f"Fonte {src} falhou: {e}", file=sys.stderr)
                feed = None
    if not feed or not feed.trips:
        raise SystemExit("Nenhuma fonte de horarios funcionou: " + " | ".join(errors))

    net, shapes, meta = pack(feed)
    os.makedirs(a.out, exist_ok=True)
    json.dump(net, open(os.path.join(a.out, "net.json"), "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
    json.dump(shapes, open(os.path.join(a.out, "shapes.json"), "w", encoding="utf-8"), separators=(",", ":"))
    json.dump(meta, open(os.path.join(a.out, "meta.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(meta, ensure_ascii=False, indent=1))
    if meta["days_with_service"] < 3:
        raise SystemExit("Calendario quase vazio - abortado para nao publicar dados inuteis.")


if __name__ == "__main__":
    main()
