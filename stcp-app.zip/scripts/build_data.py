#!/usr/bin/env python3
"""
Gera os dados do app (site/data/*.json) a partir de uma de duas fontes:

  1. API do site da STCP (stcp.pt)                      -> fonte principal
  2. GTFS do Portal de Dados Abertos do Porto (CC0)     -> alternativa, se voltar a existir

Uso:
  python scripts/build_data.py                  # tenta STCP API e depois o portal
  python scripts/build_data.py --source gtfs    # so o portal
  python scripts/build_data.py --gtfs feed.zip  # GTFS local
Variavel opcional STCP_PROXY=https://<worker>.workers.dev  (se o GitHub for bloqueado pela STCP)
"""
import argparse
import csv
import io
import json
import math
import os
import re
import sys
import time
import unicodedata
import urllib.parse
import urllib.request
import zipfile
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

try:
    from zoneinfo import ZoneInfo
    LISBON = ZoneInfo("Europe/Lisbon")
except Exception:  # noqa: BLE001
    LISBON = timezone.utc

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from validar import ler_anterior, validar  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "site", "data")
ZONE_OVERRIDES = os.path.join(ROOT, "scripts", "zonas_ajustes.json")
MAX_ADJ_M = 3000  # distancia maxima entre paragens seguidas para inferir fronteira de zonas
UA = {"User-Agent": "Mozilla/5.0 (proxima-paragem build; uso pessoal)", "Accept": "application/json, text/html"}
DAYS_AHEAD = 8
TRAMS = {"1", "18", "22"}  # eletricos: fora do tarifario Andante ocasional

# Metro do Porto: GTFS publicado pelo proprio Metro (pagina "Mapas e horarios").
METRO_PREFIX = "M:"   # prefixo dos identificadores do metro dentro do modelo
# Pode ser mudado com a variavel METRO_GTFS (URL ou ficheiro local); "" desliga o metro.
METRO_PAGE = "https://www.metrodoporto.pt/pages/337"      # "Mapas e horarios"
METRO_GTFS = os.environ.get(
    "METRO_GTFS",
    # usado se a pagina nao puder ser lida (o nome do ficheiro muda a cada atualizacao)
    "https://www.metrodoporto.pt/metrodoporto/uploads/document/file/794/google_transit_04_09_2026.zip")

# lista de reserva caso a pagina /pt/linhas mude (confirmada em 20/09/2026)
FALLBACK_ROUTES = """200 201 202 203 204 205 206 207 208 209 300 301 302 303 304 305 400 401 402 403 404
500 501 502 503 504 505 506 507 508 600 601 602 603 604 605 700 701 702 703 704 705 706 707
800 801 803 804 805 806 900 901 902 903 904 905 906 907 ZC 1M 2M 3M 4M 5M 7M 8M 9M 10M 11M 12M 13M""".split()


# ================================================================ util
def http_get(url, timeout=60, tries=3):
    last = None
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(1.5 * (k + 1))
    raise last


def metro_gtfs_url():
    """Le a pagina "Mapas e horarios" do Metro e devolve o link do GTFS mais recente.

    O nome do ficheiro muda a cada atualizacao, por isso nao se pode fixar o URL.
    """
    try:
        html = http_get(METRO_PAGE, 60).decode("utf-8", "replace")
    except Exception as e:  # noqa: BLE001
        print("aviso: pagina do metro ilegivel:", e, file=sys.stderr)
        return None
    links = re.findall(r'href=["\']([^"\']*google_transit[^"\']*\.zip)["\']', html, re.I)
    if not links:
        print("aviso: link do GTFS do metro nao encontrado na pagina", file=sys.stderr)
        return None
    url = urllib.parse.urljoin(METRO_PAGE, links[-1])
    return url


def nome_simples(s):
    """Nome sem acentos, pontuacao nem palavras de ligacao, para casar listas diferentes."""
    s = unicodedata.normalize("NFD", s or "").encode("ascii", "ignore").decode().lower()
    s = re.sub(r"\b(de|da|do|dos|das|sr|senhor|santo|sao|s)\b", " ", s)
    return re.sub(r"[^a-z0-9]+", "", s)


def metro_titles(stops):
    """Tabela oficial de titulos entre estacoes de metro (scripts/metro_titulos.json).

    Devolve {"i": [indices das paragens], "z": ["2323...", ...]}, em que z[a][b] e o
    numero do titulo de i[a] para i[b]. Usada so em percursos feitos apenas de metro.
    """
    path = os.path.join(ROOT, "scripts", "metro_titulos.json")
    if not os.path.exists(path):
        return None
    try:
        with open(path, encoding="utf-8") as fh:
            tab = json.load(fh)
        est, z = tab["estacoes"], tab["titulos"]
    except Exception as e:  # noqa: BLE001
        print("aviso: metro_titulos.json ilegivel:", e, file=sys.stderr)
        return None
    metro = [(i, st) for i, st in enumerate(stops) if st[0].startswith(METRO_PREFIX)]
    if not metro:
        return None
    by_name = defaultdict(list)
    for i, st in metro:
        by_name[nome_simples(st[2])].append(i)
    idx = []
    for name, lat, lon in est:
        cand = by_name.get(nome_simples(name)) or []
        if len(cand) == 1:
            idx.append(cand[0])
            continue
        best, bd = -1, 400.0
        for i, st in (metro if not cand else [(i, stops[i]) for i in cand]):
            d = dist((lat, lon), (st[3], st[4]))
            if d < bd:
                best, bd = i, d
        idx.append(best)
    keep = [k for k, i in enumerate(idx) if i >= 0]
    if len(keep) < len(est):
        print(f"aviso: {len(est) - len(keep)} estacoes da tabela de titulos sem paragem correspondente",
              file=sys.stderr)
    if not keep:
        return None
    return {"i": [idx[k] for k in keep], "z": ["".join(z[k][j] for j in keep) for k in keep]}


def dist(a, b):
    lat1, lon1, lat2, lon2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 6371000 * 2 * math.asin(math.sqrt(h))


def tsec(s):
    """'25:10:07' -> segundos desde o inicio do dia de servico."""
    if not s:
        return None
    p = s.strip().split(":")
    return int(p[0]) * 3600 + int(p[1]) * 60 + (int(p[2]) if len(p) > 2 else 0)


def simplify(points, tol_m=8.0):
    """Douglas-Peucker (aproximacao planar local)."""
    if len(points) < 3:
        return points
    lat0 = math.radians(points[0][0])
    kx, ky = 111320 * math.cos(lat0), 110540
    xy = [(p[1] * kx, p[0] * ky) for p in points]
    keep = [False] * len(points)
    keep[0] = keep[-1] = True
    stack = [(0, len(points) - 1)]
    while stack:
        i, j = stack.pop()
        (x1, y1), (x2, y2) = xy[i], xy[j]
        dx, dy = x2 - x1, y2 - y1
        d2 = dx * dx + dy * dy
        best, idx = 0.0, -1
        for k in range(i + 1, j):
            x, y = xy[k]
            if d2 == 0:
                dd = math.hypot(x - x1, y - y1)
            else:
                t = max(0, min(1, ((x - x1) * dx + (y - y1) * dy) / d2))
                dd = math.hypot(x - (x1 + t * dx), y - (y1 + t * dy))
            if dd > best:
                best, idx = dd, k
        if best > tol_m and idx > 0:
            keep[idx] = True
            stack += [(i, idx), (idx, j)]
    return [p for p, k in zip(points, keep) if k]


def encode_poly(pts):
    """Polyline do Google (precisao 1e5)."""
    out, plat, plon = [], 0, 0
    for la, lo in pts:
        ila, ilo = int(round(la * 1e5)), int(round(lo * 1e5))
        for v in (ila - plat, ilo - plon):
            v = ~(v << 1) if v < 0 else (v << 1)
            while v >= 0x20:
                out.append(chr((0x20 | (v & 0x1f)) + 63))
                v >>= 5
            out.append(chr(v + 63))
        plat, plon = ila, ilo
    return "".join(out)


def service_days():
    today = datetime.now(LISBON).date()
    return [today - timedelta(days=1) + timedelta(days=i) for i in range(DAYS_AHEAD + 1)]


def merge(base, other, prefix):
    """Junta outro feed (ex.: metro) ao principal, com prefixo nos identificadores."""
    for sid, v in other.stops.items():
        if v[0] == sid:          # sem stop_code proprio: nao mostrar o id interno
            v = [''] + v[1:]
        base.stops[prefix + sid] = v
    for rid, v in other.routes.items():
        base.routes[prefix + rid] = v
    for k, pts in other.shapes.items():
        base.shapes[prefix + k] = pts
    for d, svcs in other.calendar.items():
        base.calendar[d] |= {prefix + s for s in svcs}
    for (rid, di, head, svc, ids, secs, shk) in other.trips:
        base.trips.append((prefix + rid, di, head, prefix + svc,
                           [prefix + i for i in ids], secs, (prefix + shk) if shk else shk))
    base.source += " + " + other.source
    return base


class Feed:
    """Representacao intermedia comum as fontes."""
    def __init__(self, source):
        self.source = source
        self.stops = {}      # id -> [code, name, lat, lon, zone]
        self.routes = {}     # rid -> [short, long, color, text, type]
        self.trips = []      # (rid, dir, head, svc_key, [stop_ids], [secs], shape_key)
        self.shapes = {}     # shape_key -> [(lat, lon)]
        self.calendar = defaultdict(set)  # 'YYYY-MM-DD' -> {svc_key}


# ================================================================ fonte 1: API da STCP
class StcpApi:
    def __init__(self, proxy=None):
        self.proxy = (proxy or "").rstrip("/")

    def url(self, host, path):
        if self.proxy:
            return f"{self.proxy}/{'wab' if host == 'wab' else 'api'}{path}"
        return (f"https://wab.stcp.pt/tracking/api{path}" if host == "wab" else f"https://stcp.pt/api{path}")

    def get(self, path, host="stcp"):
        return json.loads(http_get(self.url(host, path), 40))

    def route_ids(self):
        try:
            base = f"{self.proxy}/page/linhas" if self.proxy else "https://stcp.pt/pt/linhas"
            html = http_get(base, 40).decode("utf-8", "replace")
            ids = []
            for m in re.findall(r'/pt/linhas/([A-Za-z0-9]+)["\'?#]', html):
                if m not in ids:
                    ids.append(m)
            if len(ids) >= 40:
                return ids
            print(f"Aviso: so encontrei {len(ids)} linhas na pagina; uso a lista de reserva.")
        except Exception as e:  # noqa: BLE001
            print("Aviso: pagina de linhas indisponivel:", e)
        return list(FALLBACK_ROUTES)


def interpolate(dir_stops, idx_times):
    """dir_stops: [(id, lat, lon)]; idx_times: [(indice, segundos)] ordenado.
    Devolve (stop_ids, secs) do primeiro ao ultimo timepoint, com as paragens
    intermedias interpoladas pela distancia em linha reta (metodo da STCP)."""
    a0, a1 = idx_times[0][0], idx_times[-1][0]
    ids = [s[0] for s in dir_stops[a0:a1 + 1]]
    cum = [0.0]
    for p, q in zip(dir_stops[a0:a1], dir_stops[a0 + 1:a1 + 1]):
        cum.append(cum[-1] + dist((p[1], p[2]), (q[1], q[2])))
    secs = [None] * len(ids)
    for (i, t) in idx_times:
        secs[i - a0] = t
    for (i, t), (j, u) in zip(idx_times, idx_times[1:]):
        i, j = i - a0, j - a0
        span = cum[j] - cum[i]
        for k in range(i + 1, j):
            f = (cum[k] - cum[i]) / span if span > 0 else (k - i) / (j - i)
            secs[k] = int(math.floor(t + f * (u - t) + 1e-6))  # a STCP trunca os segundos
    return ids, secs


def load_stcp_api(proxy=None):
    api = StcpApi(proxy)
    feed = Feed("stcp.pt (API do site)")
    days = service_days()
    routes = [r for r in api.route_ids() if r not in TRAMS]
    print(f"STCP API: {len(routes)} linhas")
    failures = []

    def do_route(rid):
        out = {"stops": {}, "trips": [], "shapes": {}, "cal": defaultdict(set), "route": None}
        q = urllib.parse.quote
        active = set()
        for d in days:
            r = api.get(f"/route/{q(rid)}/services?date={d.isoformat()}")
            sid = r.get("active_service_id")
            if sid and str(r.get("selected_date", "")).replace("-", "") == d.strftime("%Y%m%d"):
                out["cal"][d.isoformat()].add(f"{rid}|{sid}")
                active.add(sid)
        for direction in (0, 1):
            try:
                st = api.get(f"/route/{q(rid)}/stops/direction?direction_id={direction}")
            except Exception:  # noqa: BLE001
                continue
            stops = sorted(st.get("stops") or [], key=lambda s: s.get("stop_sequence") or 0)
            if len(stops) < 2:
                continue
            dir_stops = []
            seq_idx = {}
            for i, s in enumerate(stops):
                sid = s["stop_id"]
                out["stops"][sid] = [s.get("stop_code") or sid, (s.get("stop_name") or sid).strip(),
                                     round(float(s["stop_lat"]), 6), round(float(s["stop_lon"]), 6), s.get("zone_id") or ""]
                dir_stops.append((sid, float(s["stop_lat"]), float(s["stop_lon"])))
                seq_idx[s.get("stop_sequence")] = i
            shape_key = f"{rid}_{direction}"
            try:
                w = api.get(f"/route-stops?route={q(rid)}&direction={direction}", host="wab")
                if w.get("shape"):
                    out["shapes"][shape_key] = [(float(a), float(b)) for a, b in w["shape"]]
                ro = w.get("route") or {}
                out["route"] = out["route"] or [ro.get("short") or rid, ro.get("long") or "", ro.get("color") or "", "FFFFFF", 3]
            except Exception:  # noqa: BLE001
                pass
            for sid in sorted(active):
                sc = api.get(f"/route/{q(rid)}/schedule?service_id={q(sid)}&direction_id={direction}")
                sel = sc.get("selected_stops") or []
                for trip in sc.get("schedule") or []:
                    tps = trip.get("stops") or []
                    idx_times = []
                    for n, tp in enumerate(tps):
                        t = tsec(tp.get("departure_time") or tp.get("arrival_time"))
                        if t is None:
                            continue
                        i = None
                        if len(sel) == len(tps):
                            i = seq_idx.get(sel[n].get("stopSequence"))
                        if i is None:  # procura sequencial pelo id
                            start = idx_times[-1][0] + 1 if idx_times else 0
                            i = next((k for k in range(start, len(dir_stops)) if dir_stops[k][0] == tp.get("stop_id")), None)
                        if i is not None and (not idx_times or i > idx_times[-1][0]):
                            idx_times.append((i, t))
                    if len(idx_times) < 2:
                        continue
                    ids, secs = interpolate(dir_stops, idx_times)
                    out["trips"].append((rid, direction, (trip.get("trip_headsign") or "").strip(),
                                         f"{rid}|{sid}", ids, secs, shape_key))
        if out["route"] is None:
            out["route"] = [rid, "", "", "FFFFFF", 3]
        return rid, out

    def safe(rid):
        try:
            return do_route(rid)
        except Exception as e:  # noqa: BLE001
            return rid, e

    with ThreadPoolExecutor(6) as ex:
        for rid, res in ex.map(safe, routes):
            if isinstance(res, Exception) or not res["trips"]:
                failures.append((rid, str(res)[:120] if isinstance(res, Exception) else "sem viagens"))
                continue
            feed.routes[rid] = res["route"]
            feed.stops.update(res["stops"])
            feed.trips += res["trips"]
            feed.shapes.update(res["shapes"])
            for d, s in res["cal"].items():
                feed.calendar[d] |= s
    for rid, why in failures:
        print(f"  linha {rid}: {why}")
    if len(failures) > len(routes) * 0.3:
        raise RuntimeError(f"Falharam {len(failures)} de {len(routes)} linhas na API da STCP")
    feed.failures = failures
    return feed


# ================================================================ fonte 2: GTFS do portal
DATASET = "horarios-paragens-e-rotas-em-formato-gtfs-stcp"
CKAN = "https://opendata.porto.digital/api/3/action/package_show?id=" + DATASET


def latest_gtfs_url():
    data = json.loads(http_get(CKAN, 60, 1))
    res = [r for r in data["result"]["resources"]
           if (r.get("format") or "").lower() in ("zip", "gtfs", "application/zip")
           or (r.get("url") or "").lower().endswith(".zip")]
    res.sort(key=lambda r: r.get("created") or r.get("last_modified") or "")
    if not res:
        raise RuntimeError("portal sem recursos GTFS")
    return res[-1]["url"]


def read_csv(zf, name):
    names = {os.path.basename(n): n for n in zf.namelist()}
    if name not in names:
        return []
    return list(csv.DictReader(io.StringIO(zf.read(names[name]).decode("utf-8-sig", "replace"))))


def load_gtfs(zf, source):
    feed = Feed(source)
    for r in read_csv(zf, "stops.txt"):
        if ((r.get("location_type") or "0").strip() or "0") != "0":
            continue
        try:
            lat, lon = round(float(r["stop_lat"]), 6), round(float(r["stop_lon"]), 6)
        except (KeyError, ValueError):
            continue
        sid = r["stop_id"].strip()
        feed.stops[sid] = [(r.get("stop_code") or "").strip() or sid, (r.get("stop_name") or sid).strip(),
                           lat, lon, (r.get("zone_id") or "").strip()]
    for r in read_csv(zf, "routes.txt"):
        rid = r["route_id"].strip()
        feed.routes[rid] = [(r.get("route_short_name") or rid).strip(), (r.get("route_long_name") or "").strip(),
                            (r.get("route_color") or "").strip(), (r.get("route_text_color") or "").strip(),
                            int((r.get("route_type") or "3").strip() or 3)]
    days = service_days()
    wd = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    for r in read_csv(zf, "calendar.txt"):
        a = datetime.strptime(r["start_date"].strip(), "%Y%m%d").date()
        b = datetime.strptime(r["end_date"].strip(), "%Y%m%d").date()
        for d in days:
            if a <= d <= b and r.get(wd[d.weekday()], "0").strip() == "1":
                feed.calendar[d.isoformat()].add(r["service_id"].strip())
    for r in read_csv(zf, "calendar_dates.txt"):
        d = datetime.strptime(r["date"].strip(), "%Y%m%d").date()
        if d not in days:
            continue
        (feed.calendar[d.isoformat()].add if r["exception_type"].strip() == "1"
         else feed.calendar[d.isoformat()].discard)(r["service_id"].strip())
    trips = {r["trip_id"].strip(): r for r in read_csv(zf, "trips.txt") if r["route_id"].strip() in feed.routes}
    st = defaultdict(list)
    names = {os.path.basename(n): n for n in zf.namelist()}
    with zf.open(names["stop_times.txt"]) as fh:
        for r in csv.DictReader(io.TextIOWrapper(fh, encoding="utf-8-sig")):
            tid, sid = r["trip_id"].strip(), r["stop_id"].strip()
            if tid in trips and sid in feed.stops:
                t = tsec(r.get("departure_time") or r.get("arrival_time"))
                if t is not None:
                    st[tid].append((int(r["stop_sequence"]), sid, t))
    for tid, rows in st.items():
        rows.sort()
        if len(rows) < 2:
            continue
        tr = trips[tid]
        d = (tr.get("direction_id") or "0").strip()
        feed.trips.append((tr["route_id"].strip(), int(d) if d.isdigit() else 0, (tr.get("trip_headsign") or "").strip(),
                           tr["service_id"].strip(), [x[1] for x in rows], [x[2] for x in rows],
                           (tr.get("shape_id") or "").strip()))
    pts = defaultdict(list)
    for r in read_csv(zf, "shapes.txt"):
        try:
            pts[r["shape_id"].strip()].append((int(r["shape_pt_sequence"]), float(r["shape_pt_lat"]), float(r["shape_pt_lon"])))
        except (KeyError, ValueError):
            pass
    feed.shapes = {k: [(a, b) for _, a, b in sorted(v)] for k, v in pts.items()}
    return feed


# ================================================================ empacotar para o app
def pack(feed):
    if os.path.exists(ZONE_OVERRIDES):
        ov = json.load(open(ZONE_OVERRIDES, encoding="utf-8"))
        for sid, z in ov.get("zona_por_paragem", {}).items():
            for k, s in feed.stops.items():
                if k == sid or s[0] == sid:
                    s[4] = z
    else:
        ov = {}
    stop_ids = sorted(feed.stops)
    sidx = {s: i for i, s in enumerate(stop_ids)}
    rids = sorted(feed.routes, key=lambda r: (len(feed.routes[r][0]), feed.routes[r][0]))
    ridx = {r: i for i, r in enumerate(rids)}
    services = {}
    def svc(k):
        if k not in services:
            services[k] = len(services)
        return services[k]

    patterns = {}
    for (rid, d, head, skey, ids, secs, shk) in feed.trips:
        if rid not in ridx:
            continue
        seq = tuple(sidx[s] for s in ids)
        start = secs[0]
        offs = tuple(t - start for t in secs)
        key = (ridx[rid], d, seq)
        p = patterns.get(key)
        if p is None:
            p = patterns[key] = {"profiles": {}, "trips": [], "heads": Counter(), "shapes": Counter()}
        pi = p["profiles"].setdefault(offs, len(p["profiles"]))
        p["trips"].append((start, pi, svc(skey)))
        p["heads"][head] += 1
        if shk:
            p["shapes"][shk] += 1

    shape_idx, shapes_out = {}, []
    out_patterns, used = [], set()
    for (ri, d, seq), p in sorted(patterns.items(), key=lambda kv: kv[0][:2]):
        sh = -1
        if p["shapes"]:
            k = p["shapes"].most_common(1)[0][0]
            if k in feed.shapes and len(feed.shapes[k]) > 1:
                if k not in shape_idx:
                    shape_idx[k] = len(shapes_out)
                    shapes_out.append(encode_poly(simplify(feed.shapes[k])))
                sh = shape_idx[k]
        out_patterns.append({
            "r": ri, "d": d, "h": p["heads"].most_common(1)[0][0] or feed.stops[stop_ids[seq[-1]]][1],
            "s": list(seq), "sh": sh,
            "p": [list(o) for o, _ in sorted(p["profiles"].items(), key=lambda kv: kv[1])],
            "t": [x for trip in sorted(p["trips"]) for x in trip],
        })
        used.update(seq)

    adj = defaultdict(set)
    for pat in out_patterns:
        info = [feed.stops[stop_ids[i]] for i in pat["s"]]
        for x, y in zip(info, info[1:]):
            a, b = x[4], y[4]
            # servicos expresso saltam paragens: um salto longo nao prova fronteira
            if a and b and a != b and dist((x[2], x[3]), (y[2], y[3])) <= MAX_ADJ_M:
                adj[a].add(b)
                adj[b].add(a)
    for a, bs in ov.get("adjacencias_extra", {}).items():
        for b in bs:
            adj[a].add(b)
            adj[b].add(a)
    zone_dist = {}
    for k, v in (ov.get("distancias_oficiais") or {}).items():
        a, _, b = k.partition("|")
        if a and b and isinstance(v, int) and v >= 0:
            zone_dist["|".join(sorted((a, b)))] = v
            if v == 1:
                adj[a].add(b)
                adj[b].add(a)

    stops = [[sid] + feed.stops[sid] for sid in stop_ids]
    metro_z = metro_titles(stops)
    net = {
        "v": 2,  # tempos em segundos
        "tz": "Europe/Lisbon",
        "stops": stops,
        "routes": [feed.routes[r] for r in rids],
        "services": [k for k, _ in sorted(services.items(), key=lambda kv: kv[1])],
        "calendar": {d: sorted(services[k] for k in ks if k in services) for d, ks in sorted(feed.calendar.items())},
        "patterns": out_patterns,
        "zoneAdj": {k: sorted(v) for k, v in sorted(adj.items())},
        "zoneDist": dict(sorted(zone_dist.items())),
        **({"metroZ": metro_z} if metro_z else {}),
        "used": sorted(used),
    }
    days = service_days()
    meta = {
        "generated": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source": feed.source,
        "calendar_from": days[0].isoformat(),
        "calendar_to": days[-1].isoformat(),
        "stops": len(used),
        "stops_with_zone": sum(1 for i in used if stops[i][5]),
        "routes": len(rids),
        "patterns": len(out_patterns),
        "trips": sum(len(p["t"]) // 3 for p in out_patterns),
        "zones": len({stops[i][5] for i in used if stops[i][5]}),
        "metro_stops": sum(1 for i in used if stops[i][0].startswith(METRO_PREFIX)),
        "days_with_service": sum(1 for v in net["calendar"].values() if v),
        "failed_routes": [r for r, _ in getattr(feed, "failures", [])],
    }
    return net, shapes_out, meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gtfs", help="ficheiro GTFS local (zip)")
    ap.add_argument("--source", choices=["auto", "stcp", "gtfs"], default="auto")
    ap.add_argument("--metro", help="GTFS do Metro do Porto (URL ou ficheiro); vazio desliga")
    ap.add_argument("--out", default=OUT)
    ap.add_argument("--anterior", default=os.environ.get("META_ANTERIOR"),
                    help="meta.json ja publicado, para comparar tamanhos (ficheiro ou URL)")
    ap.add_argument("--sem-validacao", action="store_true",
                    help="escreve os ficheiros mesmo que as validacoes falhem (so para depurar)")
    a = ap.parse_args()

    feed, errors = None, []
    if a.gtfs:
        feed = load_gtfs(zipfile.ZipFile(a.gtfs), os.path.basename(a.gtfs))
    else:
        order = {"auto": ["stcp", "gtfs"], "stcp": ["stcp"], "gtfs": ["gtfs"]}[a.source]
        for src in order:
            try:
                if src == "stcp":
                    feed = load_stcp_api(os.environ.get("STCP_PROXY"))
                else:
                    url = latest_gtfs_url()
                    feed = load_gtfs(zipfile.ZipFile(io.BytesIO(http_get(url, 300))), url)
                if feed.trips:
                    break
                errors.append(f"{src}: sem viagens")
            except Exception as e:  # noqa: BLE001
                errors.append(f"{src}: {e}")
                print(f"Fonte {src} falhou: {e}", file=sys.stderr)
                feed = None
    if not feed or not feed.trips:
        raise SystemExit("Nenhuma fonte de horarios funcionou: " + " | ".join(errors))

    # Metro do Porto (opcional): mesma rede, mesmas zonas Andante
    metro_src = a.metro if a.metro is not None else (metro_gtfs_url() or METRO_GTFS)
    if metro_src:
        try:
            if os.path.exists(metro_src):
                blob, name = open(metro_src, "rb").read(), os.path.basename(metro_src)
            else:
                blob, name = http_get(metro_src, 120), metro_src
            m = load_gtfs(zipfile.ZipFile(io.BytesIO(blob)), "Metro do Porto (GTFS)")
            if m.trips:
                merge(feed, m, METRO_PREFIX)
                print(f"Metro do Porto: {len(m.stops)} estacoes, {len(m.routes)} linhas, {len(m.trips)} viagens ({name})")
            else:
                print("Aviso: GTFS do metro sem viagens para os proximos dias.", file=sys.stderr)
        except Exception as e:  # noqa: BLE001
            print(f"Aviso: metro nao incluido ({e})", file=sys.stderr)

    net, shapes, meta = pack(feed)
    print(json.dumps(meta, ensure_ascii=False, indent=1))

    # Validar ANTES de escrever: uns dados validos mas errados passariam sem isto,
    # e o app so mentiria a quem estivesse na paragem. Se falhar, nao se escreve
    # nada e o workflow republica a ultima versao boa.
    resultado = validar(net, shapes, meta, ler_anterior(a.anterior))
    resultado.imprimir()
    if not resultado.ok and not a.sem_validacao:
        raise SystemExit("Dados reprovados nas validacoes - nada foi escrito.")

    os.makedirs(a.out, exist_ok=True)
    json.dump(net, open(os.path.join(a.out, "net.json"), "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
    json.dump(shapes, open(os.path.join(a.out, "shapes.json"), "w", encoding="utf-8"), separators=(",", ":"))
    json.dump(meta, open(os.path.join(a.out, "meta.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
