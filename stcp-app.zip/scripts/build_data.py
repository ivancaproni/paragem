#!/usr/bin/env python3
"""
Constroi os dados compactos do app a partir do GTFS oficial da STCP
(Portal de Dados Abertos do Porto, licenca CC0).

Uso:
  python scripts/build_data.py                 # descarrega o GTFS mais recente
  python scripts/build_data.py --gtfs feed.zip # usa um ficheiro local

Saida (em site/data/):
  net.json     paragens, linhas, padroes de viagem, horarios, calendario, zonas
  shapes.json  tracados simplificados das linhas (para o mapa)
  meta.json    data de geracao, origem do feed, validade
"""
import argparse
import csv
import io
import json
import math
import os
import re
import sys
import urllib.request
import zipfile
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone

DATASET = "horarios-paragens-e-rotas-em-formato-gtfs-stcp"
CKAN = "https://opendata.porto.digital/api/3/action/package_show?id=" + DATASET
DATASET_PAGE = "https://opendata.porto.digital/dataset/" + DATASET
UA = {"User-Agent": "stcp-pwa-build/1.0 (+github actions)"}
DAYS_AHEAD = 21          # dias de calendario pre-calculados
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "site", "data")
ZONE_OVERRIDES = os.path.join(ROOT, "scripts", "zonas_ajustes.json")


# ---------------------------------------------------------------- download
def http_get(url, timeout=120):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def latest_gtfs_url():
    """Escolhe o recurso ZIP mais recente do conjunto de dados (API CKAN).
    Se a API falhar, recorre a pagina HTML (link 'Mais Recente')."""
    try:
        data = json.loads(http_get(CKAN, 60))
        res = [r for r in data["result"]["resources"]
               if (r.get("format") or "").lower() in ("zip", "gtfs", "application/zip")
               or (r.get("url") or "").lower().endswith(".zip")]
        res.sort(key=lambda r: r.get("created") or r.get("last_modified") or "")
        if res:
            return res[-1]["url"], res[-1].get("name") or ""
    except Exception as e:  # noqa: BLE001
        print("CKAN API falhou:", e, file=sys.stderr)
    html = http_get(DATASET_PAGE, 60).decode("utf-8", "replace")
    urls = re.findall(r'https://opendata\.porto\.digital/dataset/[^"\']+/download/[^"\']+\.zip', html)
    if not urls:
        raise SystemExit("Nao encontrei o GTFS da STCP no portal de dados.")
    return urls[-1], "html-scrape"


# ---------------------------------------------------------------- helpers
def read_csv(zf, name):
    names = {os.path.basename(n): n for n in zf.namelist()}
    if name not in names:
        return []
    raw = zf.read(names[name])
    text = raw.decode("utf-8-sig", "replace")
    return list(csv.DictReader(io.StringIO(text)))


def tmin(s):
    """'25:10:00' -> minutos desde o inicio do dia de servico."""
    if not s:
        return None
    p = s.strip().split(":")
    return int(p[0]) * 60 + int(p[1]) + (1 if len(p) > 2 and int(p[2]) >= 30 else 0)


def haversine(a, b):
    lat1, lon1, lat2, lon2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 6371000 * 2 * math.asin(math.sqrt(h))


def simplify(points, tol_m=8.0):
    """Douglas-Peucker (aproximacao planar local)."""
    if len(points) < 3:
        return points
    lat0 = math.radians(points[0][0])
    kx, ky = 111320 * math.cos(lat0), 110540
    xy = [(p[1] * kx, p[0] * ky) for p in points]
    keep = [False] * len(points)
    keep[0] = keep[-1] = True
    stack = [(0, len(points) - 1)]
    while stack:
        i, j = stack.pop()
        (x1, y1), (x2, y2) = xy[i], xy[j]
        dx, dy = x2 - x1, y2 - y1
        d2 = dx * dx + dy * dy
        best, idx = 0.0, -1
        for k in range(i + 1, j):
            x, y = xy[k]
            if d2 == 0:
                dist = math.hypot(x - x1, y - y1)
            else:
                t = max(0, min(1, ((x - x1) * dx + (y - y1) * dy) / d2))
                dist = math.hypot(x - (x1 + t * dx), y - (y1 + t * dy))
            if dist > best:
                best, idx = dist, k
        if best > tol_m and idx > 0:
            keep[idx] = True
            stack += [(i, idx), (idx, j)]
    return [p for p, k in zip(points, keep) if k]


def zone_of(row):
    z = (row.get("zone_id") or "").strip()
    return z


# ---------------------------------------------------------------- build
def build(zf, source_url):
    agency = read_csv(zf, "agency.txt")
    tz = agency[0].get("agency_timezone", "Europe/Lisbon") if agency else "Europe/Lisbon"

    # --- paragens
    stops_rows = read_csv(zf, "stops.txt")
    stop_idx, stops = {}, []
    parent_of = {}
    for r in stops_rows:
        lt = (r.get("location_type") or "0").strip() or "0"
        if lt not in ("0",):
            continue
        try:
            lat, lon = round(float(r["stop_lat"]), 6), round(float(r["stop_lon"]), 6)
        except (KeyError, ValueError):
            continue
        sid = r["stop_id"].strip()
        stop_idx[sid] = len(stops)
        code = (r.get("stop_code") or "").strip() or sid
        stops.append([sid, code, (r.get("stop_name") or sid).strip(), lat, lon, zone_of(r)])
        if r.get("parent_station"):
            parent_of[sid] = r["parent_station"]

    # --- linhas
    routes_rows = read_csv(zf, "routes.txt")
    route_idx, routes = {}, []
    for r in routes_rows:
        rid = r["route_id"].strip()
        route_idx[rid] = len(routes)
        color = (r.get("route_color") or "").strip()
        tcolor = (r.get("route_text_color") or "").strip()
        routes.append([
            (r.get("route_short_name") or rid).strip(),
            (r.get("route_long_name") or "").strip(),
            color, tcolor, int((r.get("route_type") or "3").strip() or 3),
        ])

    # --- servicos / calendario
    services = {}
    def svc(sid):
        if sid not in services:
            services[sid] = len(services)
        return services[sid]

    active = defaultdict(set)  # 'YYYY-MM-DD' -> {svc}
    today = datetime.now(timezone.utc).date()
    days = [today - timedelta(days=1) + timedelta(days=i) for i in range(DAYS_AHEAD + 1)]
    wd = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    for r in read_csv(zf, "calendar.txt"):
        s = r["service_id"].strip()
        a = datetime.strptime(r["start_date"].strip(), "%Y%m%d").date()
        b = datetime.strptime(r["end_date"].strip(), "%Y%m%d").date()
        for d in days:
            if a <= d <= b and r.get(wd[d.weekday()], "0").strip() == "1":
                active[d.isoformat()].add(svc(s))
    for r in read_csv(zf, "calendar_dates.txt"):
        s = r["service_id"].strip()
        d = datetime.strptime(r["date"].strip(), "%Y%m%d").date()
        if d not in days:
            continue
        k = d.isoformat()
        if r["exception_type"].strip() == "1":
            active[k].add(svc(s))
        elif r["exception_type"].strip() == "2":
            active[k].discard(services.get(s, -1))

    # --- viagens
    trips = {}
    for r in read_csv(zf, "trips.txt"):
        if r["route_id"].strip() not in route_idx:
            continue
        trips[r["trip_id"].strip()] = r

    st = defaultdict(list)
    names = {os.path.basename(n): n for n in zf.namelist()}
    with zf.open(names["stop_times.txt"]) as fh:
        reader = csv.DictReader(io.TextIOWrapper(fh, encoding="utf-8-sig"))
        for r in reader:
            tid = r["trip_id"].strip()
            if tid not in trips:
                continue
            sid = r["stop_id"].strip()
            if sid not in stop_idx:
                continue
            t = tmin(r.get("departure_time") or r.get("arrival_time"))
            if t is None:
                continue  # paragem sem hora (interpolada): ignorada
            st[tid].append((int(r["stop_sequence"]), stop_idx[sid], t))

    # --- padroes (sequencia de paragens) e perfis (tempos relativos)
    patterns = {}
    for tid, rows in st.items():
        rows.sort()
        if len(rows) < 2:
            continue
        tr = trips[tid]
        seq = tuple(x[1] for x in rows)
        start = rows[0][2]
        offs = tuple(x[2] - start for x in rows)
        key = (route_idx[tr["route_id"].strip()], (tr.get("direction_id") or "0").strip(), seq)
        p = patterns.get(key)
        if p is None:
            p = patterns[key] = {"profiles": {}, "trips": [], "heads": Counter(), "shapes": Counter()}
        pi = p["profiles"].setdefault(offs, len(p["profiles"]))
        p["trips"].append((start, pi, svc(tr["service_id"].strip())))
        p["heads"][(tr.get("trip_headsign") or "").strip()] += 1
        if tr.get("shape_id"):
            p["shapes"][tr["shape_id"].strip()] += 1

    # --- tracados
    shape_pts = defaultdict(list)
    for r in read_csv(zf, "shapes.txt"):
        try:
            shape_pts[r["shape_id"].strip()].append(
                (int(r["shape_pt_sequence"]), float(r["shape_pt_lat"]), float(r["shape_pt_lon"])))
        except (KeyError, ValueError):
            pass
    shape_idx, shapes_out = {}, []

    out_patterns = []
    used_stops = set()
    for (ri, d, seq), p in sorted(patterns.items(), key=lambda kv: (routes[kv[0][0]][0], kv[0][1])):
        sh = -1
        if p["shapes"]:
            sid = p["shapes"].most_common(1)[0][0]
            if sid in shape_pts:
                if sid not in shape_idx:
                    pts = [(la, lo) for _, la, lo in sorted(shape_pts[sid])]
                    pts = simplify(pts)
                    shape_idx[sid] = len(shapes_out)
                    shapes_out.append(encode_poly(pts))
                sh = shape_idx[sid]
        profiles = [list(o) for o, _ in sorted(p["profiles"].items(), key=lambda kv: kv[1])]
        tr = sorted(p["trips"])
        out_patterns.append({
            "r": ri, "d": int(d) if d.isdigit() else 0,
            "h": p["heads"].most_common(1)[0][0] or stops[seq[-1]][2],
            "s": list(seq), "sh": sh, "p": profiles,
            "t": [x for trip in tr for x in trip],  # achatado: start, perfil, servico
        })
        used_stops.update(seq)

    # --- zonas em falta no GTFS: tenta a API publica do site da STCP (com cache)
    missing = [i for i in used_stops if not stops[i][5]]
    if missing and len(missing) > len(used_stops) * 0.2 and not os.environ.get("NO_ZONE_FETCH"):
        fill_zones_from_stcp(stops, missing)

    # --- zonas: adjacencia observada entre paragens consecutivas
    adj = defaultdict(set)
    for pat in out_patterns:
        zs = [stops[i][5] for i in pat["s"]]
        for a, b in zip(zs, zs[1:]):
            if a and b and a != b:
                adj[a].add(b)
                adj[b].add(a)
    if os.path.exists(ZONE_OVERRIDES):
        ov = json.load(open(ZONE_OVERRIDES, encoding="utf-8"))
        for a, bs in ov.get("adjacencias_extra", {}).items():
            for b in bs:
                adj[a].add(b)
                adj[b].add(a)
        for sid, z in ov.get("zona_por_paragem", {}).items():
            for s in stops:
                if s[0] == sid or s[1] == sid:
                    s[5] = z

    with_zone = sum(1 for i in used_stops if stops[i][5])
    net = {
        "v": 1,
        "tz": tz,
        "stops": stops,
        "routes": routes,
        "services": [k for k, _ in sorted(services.items(), key=lambda kv: kv[1])],
        "calendar": {k: sorted(v) for k, v in sorted(active.items())},
        "patterns": out_patterns,
        "zoneAdj": {k: sorted(v) for k, v in sorted(adj.items())},
        "used": sorted(used_stops),
    }
    meta = {
        "generated": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source": source_url,
        "calendar_from": days[0].isoformat(),
        "calendar_to": days[-1].isoformat(),
        "stops": len(used_stops),
        "stops_with_zone": with_zone,
        "routes": len(routes),
        "patterns": len(out_patterns),
        "trips": sum(len(p["t"]) // 3 for p in out_patterns),
        "zones": len(adj),
    }
    return net, shapes_out, meta


ZONE_CACHE = os.path.join(ROOT, ".cache", "zonas.json")


def find_zone(obj):
    """Procura recursivamente um campo de zona (ex.: 'zone', 'zona', 'zone_id')."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if "zon" in k.lower() and isinstance(v, (str, int)) and str(v).strip():
                return str(v).strip()
        for v in obj.values():
            z = find_zone(v)
            if z:
                return z
    elif isinstance(obj, list):
        for v in obj:
            z = find_zone(v)
            if z:
                return z
    return ""


def fill_zones_from_stcp(stops, missing):
    from concurrent.futures import ThreadPoolExecutor
    cache = {}
    if os.path.exists(ZONE_CACHE):
        cache = json.load(open(ZONE_CACHE, encoding="utf-8"))
    todo = [stops[i][1] for i in missing if stops[i][1] not in cache]
    print(f"Zonas: {len(missing)} paragens sem zone_id; a consultar {len(todo)} na API STCP")

    def get(code):
        try:
            return code, find_zone(json.loads(http_get(f"https://stcp.pt/api/stops/{code}", 20)))
        except Exception:  # noqa: BLE001
            return code, None

    with ThreadPoolExecutor(6) as ex:
        for code, z in ex.map(get, todo):
            if z is not None:
                cache[code] = z
    for i in missing:
        if cache.get(stops[i][1]):
            stops[i][5] = cache[stops[i][1]]
    os.makedirs(os.path.dirname(ZONE_CACHE), exist_ok=True)
    json.dump(cache, open(ZONE_CACHE, "w", encoding="utf-8"), ensure_ascii=False)


def encode_poly(pts):
    """Polyline do Google (precisao 1e5) - compacto e facil de descodificar."""
    out, plat, plon = [], 0, 0
    for la, lo in pts:
        ila, ilo = int(round(la * 1e5)), int(round(lo * 1e5))
        for v in (ila - plat, ilo - plon):
            v = ~(v << 1) if v < 0 else (v << 1)
            while v >= 0x20:
                out.append(chr((0x20 | (v & 0x1f)) + 63))
                v >>= 5
            out.append(chr(v + 63))
        plat, plon = ila, ilo
    return "".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gtfs", help="ficheiro GTFS local (zip)")
    ap.add_argument("--out", default=OUT)
    a = ap.parse_args()
    if a.gtfs:
        blob, src = open(a.gtfs, "rb").read(), os.path.basename(a.gtfs)
    else:
        url, name = latest_gtfs_url()
        print("GTFS:", name, url)
        blob, src = http_get(url, 300), url
    zf = zipfile.ZipFile(io.BytesIO(blob))
    net, shapes, meta = build(zf, src)
    os.makedirs(a.out, exist_ok=True)
    json.dump(net, open(os.path.join(a.out, "net.json"), "w", encoding="utf-8"),
              ensure_ascii=False, separators=(",", ":"))
    json.dump(shapes, open(os.path.join(a.out, "shapes.json"), "w", encoding="utf-8"),
              separators=(",", ":"))
    json.dump(meta, open(os.path.join(a.out, "meta.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(json.dumps(meta, ensure_ascii=False, indent=1))
    if meta["stops"] == 0 or meta["trips"] == 0:
        raise SystemExit("GTFS sem viagens validas - abortado para nao publicar dados vazios.")
    if meta["stops_with_zone"] < meta["stops"] * 0.5:
        print("AVISO: menos de metade das paragens tem zona Andante (zone_id) no GTFS. "
              "Preencha scripts/zonas_ajustes.json.", file=sys.stderr)


if __name__ == "__main__":
    main()
