#!/usr/bin/env python3
"""
VALIDACOES DE SANIDADE dos dados gerados.

O risco que isto cobre nao e o script rebentar: e o script correr bem e produzir
um net.json valido mas errado (uma fonte que mudou um campo, um GTFS truncado,
uma linha que desapareceu sem ninguem dar por isso). Nesse caso a publicacao
segue em frente e o app passa a mentir.

Aqui verificam-se tres coisas:
  1. coerencia interna  - os indices apontam para sitios que existem, os horarios
                          nao andam para tras, as coordenadas sao do Grande Porto;
  2. plausibilidade     - a rede tem o tamanho de uma rede a serio;
  3. comparacao         - nao encolheu nem inchou face a ultima publicacao.

Cada verificacao devolve um "erro" (bloqueia a publicacao) ou um "aviso" (fica
registado no log do GitHub Actions). Os limites estao todos em LIMITES, para se
afinarem sem ler o resto.

Uso avulso:
    python scripts/validar.py site/data
    python scripts/validar.py site/data --anterior https://<user>.github.io/<repo>/data/meta.json
"""
import json
import sys

# ---------------------------------------------------------------- limites
LIMITES = {
    # chao absoluto: abaixo disto nao e a rede do Porto, e um erro
    "min_paragens": 500,
    "min_linhas": 20,
    "min_padroes": 50,
    "min_viagens": 2000,
    "min_dias_com_servico": 3,

    # a area coberta pela STCP e pelo Metro, com folga
    "caixa": {"lat": (40.85, 41.65), "lon": (-8.95, -8.30)},

    # zonas Andante: sem zona nao se consegue dizer o titulo
    "min_paragens_com_zona": 0.98,

    # variacao aceitavel face a ultima publicacao
    "queda_maxima": {"stops": 0.25, "routes": 0.25, "patterns": 0.30},
    "subida_maxima": {"stops": 0.50, "routes": 0.50, "patterns": 0.75},
    "queda_aviso_viagens": 0.40,   # ferias e greves mexem muito nas viagens: so aviso

    # tabela oficial de titulos do Metro (85 estacoes)
    "min_estacoes_metro_na_tabela": 80,

    # linhas que a fonte nao conseguiu dar
    "max_linhas_falhadas": 5,
}


class Resultado:
    """Lista de problemas encontrados, separados por gravidade."""

    def __init__(self):
        self.erros = []
        self.avisos = []

    def erro(self, msg):
        self.erros.append(msg)

    def aviso(self, msg):
        self.avisos.append(msg)

    def exigir(self, condicao, msg):
        if not condicao:
            self.erro(msg)
        return condicao

    @property
    def ok(self):
        return not self.erros

    def imprimir(self, saida=sys.stderr):
        for a in self.avisos:
            print(f"::warning::{a}", file=saida)
        for e in self.erros:
            print(f"::error::{e}", file=saida)
        if self.ok:
            print(f"Validacoes: tudo bem ({len(self.avisos)} aviso(s)).", file=saida)
        else:
            print(f"Validacoes: {len(self.erros)} erro(s), {len(self.avisos)} aviso(s).", file=saida)


# ---------------------------------------------------------------- 1. coerencia interna
def coerencia(net, shapes, r):
    stops = net.get("stops") or []
    routes = net.get("routes") or []
    pats = net.get("patterns") or []
    servicos = net.get("services") or []
    if not r.exigir(stops and routes and pats, "net.json sem paragens, linhas ou padroes"):
        return

    # paragens
    ids = [s[0] for s in stops]
    repetidos = len(ids) - len(set(ids))
    r.exigir(repetidos == 0, f"{repetidos} identificador(es) de paragem repetido(s)")
    lat0, lat1 = LIMITES["caixa"]["lat"]
    lon0, lon1 = LIMITES["caixa"]["lon"]
    fora = [s[0] for s in stops if not (lat0 <= s[3] <= lat1 and lon0 <= s[4] <= lon1)]
    r.exigir(not fora, f"{len(fora)} paragem(ns) fora do Grande Porto, p.ex. {fora[:3]}")
    sem_nome = sum(1 for s in stops if not str(s[2]).strip())
    r.exigir(sem_nome == 0, f"{sem_nome} paragem(ns) sem nome")

    # padroes
    n = len(stops)
    for i, p in enumerate(pats):
        onde = f"padrao {i} (linha {routes[p['r']][0] if 0 <= p.get('r', -1) < len(routes) else '?'})"
        if not r.exigir(0 <= p.get("r", -1) < len(routes), f"{onde}: indice de linha invalido"):
            continue
        seq = p.get("s") or []
        if not r.exigir(len(seq) >= 2, f"{onde}: so tem {len(seq)} paragem(ns)"):
            continue
        if not r.exigir(all(0 <= s < n for s in seq), f"{onde}: aponta para paragens que nao existem"):
            continue
        perfis = p.get("p") or []
        if not r.exigir(perfis, f"{onde}: sem horarios"):
            continue
        maus = [k for k, perfil in enumerate(perfis) if len(perfil) != len(seq)]
        r.exigir(not maus, f"{onde}: perfil(s) {maus[:3]} com numero de horas diferente do numero de paragens")
        andam_atras = [k for k, perfil in enumerate(perfis)
                       if any(b < a for a, b in zip(perfil, perfil[1:]))]
        r.exigir(not andam_atras, f"{onde}: perfil(s) {andam_atras[:3]} com horas a andar para tras")
        t = p.get("t") or []
        if not r.exigir(len(t) % 3 == 0 and t, f"{onde}: tabela de viagens malformada"):
            continue
        for j in range(0, len(t), 3):
            if not (0 <= t[j + 1] < len(perfis)):
                r.erro(f"{onde}: viagem {j // 3} com perfil inexistente")
                break
            if not (0 <= t[j + 2] < len(servicos)):
                r.erro(f"{onde}: viagem {j // 3} com servico inexistente")
                break
        sh = p.get("sh", -1)
        r.exigir(sh == -1 or 0 <= sh < len(shapes), f"{onde}: desenho do percurso inexistente ({sh})")

    # calendario
    dias = net.get("calendar") or {}
    maus = [d for d, ks in dias.items() if any(not (0 <= k < len(servicos)) for k in ks)]
    r.exigir(not maus, f"calendario aponta para servicos que nao existem: {maus[:3]}")

    # paragens com linhas
    used = net.get("used") or []
    r.exigir(used and all(0 <= i < n for i in used), "lista de paragens com linhas vazia ou invalida")

    # zonas: a vizinhanca tem de ser simetrica, senao o titulo muda com o sentido
    adj = net.get("zoneAdj") or {}
    torto = [(a, b) for a, bs in adj.items() for b in bs if a not in adj.get(b, [])]
    r.exigir(not torto, f"vizinhanca de zonas assimetrica, p.ex. {torto[:3]}")

    # tabela oficial do metro
    mz = net.get("metroZ")
    if mz:
        linhas, indices = mz.get("z") or [], mz.get("i") or []
        r.exigir(len(linhas) == len(indices),
                 f"tabela do metro com {len(linhas)} linhas para {len(indices)} estacoes")
        r.exigir(all(len(x) == len(indices) for x in linhas), "tabela do metro nao e quadrada")
        r.exigir(all(0 <= i < n for i in indices), "tabela do metro aponta para paragens que nao existem")
        r.exigir(all(c.isdigit() for x in linhas for c in x), "tabela do metro com valores que nao sao numeros")


# ---------------------------------------------------------------- 2. plausibilidade
def plausibilidade(net, meta, r):
    L = LIMITES
    r.exigir(meta.get("stops", 0) >= L["min_paragens"],
             f"so {meta.get('stops')} paragens com linhas (minimo {L['min_paragens']})")
    r.exigir(meta.get("routes", 0) >= L["min_linhas"],
             f"so {meta.get('routes')} linhas (minimo {L['min_linhas']})")
    r.exigir(meta.get("patterns", 0) >= L["min_padroes"],
             f"so {meta.get('patterns')} padroes (minimo {L['min_padroes']})")
    r.exigir(meta.get("trips", 0) >= L["min_viagens"],
             f"so {meta.get('trips')} viagens (minimo {L['min_viagens']})")
    r.exigir(meta.get("days_with_service", 0) >= L["min_dias_com_servico"],
             f"so {meta.get('days_with_service')} dias com servico (minimo {L['min_dias_com_servico']})")

    total, com_zona = meta.get("stops", 0), meta.get("stops_with_zone", 0)
    if total:
        fracao = com_zona / total
        r.exigir(fracao >= L["min_paragens_com_zona"],
                 f"so {fracao:.1%} das paragens tem zona Andante "
                 f"(minimo {L['min_paragens_com_zona']:.0%}); o app nao conseguiria dizer o titulo")

    falhadas = meta.get("failed_routes") or []
    if len(falhadas) > L["max_linhas_falhadas"]:
        r.erro(f"{len(falhadas)} linhas sem horarios: {falhadas[:8]}")
    elif falhadas:
        r.aviso(f"linhas sem horarios: {falhadas}")

    mz = net.get("metroZ")
    if meta.get("metro_stops"):
        if not mz:
            r.aviso("o metro entrou na rede mas a tabela oficial de titulos nao foi gerada")
        elif len(mz.get("i") or []) < L["min_estacoes_metro_na_tabela"]:
            r.aviso(f"so {len(mz.get('i') or [])} estacoes de metro na tabela oficial "
                    f"(esperadas {L['min_estacoes_metro_na_tabela']}+); "
                    "os titulos do metro passam a ser estimados")
    else:
        r.aviso("sem estacoes de metro: o app fica so com a STCP")


# ---------------------------------------------------------------- 3. comparacao
def comparacao(meta, anterior, r):
    """Compara com a ultima publicacao. E aqui que se apanha a corrupcao silenciosa."""
    if not anterior:
        r.aviso("sem dados da publicacao anterior: nao se comparou o tamanho da rede")
        return
    for campo in ("stops", "routes", "patterns", "trips"):
        velho, novo = anterior.get(campo), meta.get(campo)
        if not isinstance(velho, int) or not velho or not isinstance(novo, int):
            continue
        var = (novo - velho) / velho
        if var < 0:
            limite = LIMITES["queda_maxima"].get(campo)
            if limite is None:   # viagens variam com ferias e greves
                if -var >= LIMITES["queda_aviso_viagens"]:
                    r.aviso(f"{campo}: {velho} -> {novo} ({var:+.0%}); confirme se e mesmo ferias")
            elif -var >= limite:
                r.erro(f"{campo} caiu de {velho} para {novo} ({var:+.0%}); "
                       "parece dados truncados, nao uma mudanca de horarios")
        else:
            limite = LIMITES["subida_maxima"].get(campo)
            if limite is not None and var >= limite:
                r.erro(f"{campo} subiu de {velho} para {novo} ({var:+.0%}); "
                       "parece duplicacao de dados")

    numero = lambda x: x if isinstance(x, int) and x >= 0 else 0  # noqa: E731
    ant_total, ant_zona = numero(anterior.get("stops")), numero(anterior.get("stops_with_zone"))
    novo_total, nova_zona = numero(meta.get("stops")), numero(meta.get("stops_with_zone"))
    if ant_total and novo_total:
        antes, agora = ant_zona / ant_total, nova_zona / novo_total
        if agora < antes - 0.02:
            r.erro(f"paragens com zona caiu de {antes:.1%} para {agora:.1%}")


# ---------------------------------------------------------------- entrada
def validar(net, shapes, meta, anterior=None):
    r = Resultado()
    coerencia(net, shapes, r)
    plausibilidade(net, meta, r)
    comparacao(meta, anterior, r)
    return r


def ler_anterior(origem):
    """Le o meta.json da publicacao anterior (ficheiro ou URL). Nunca rebenta."""
    if not origem:
        return None
    try:
        if origem.startswith("http"):
            import urllib.request
            with urllib.request.urlopen(origem, timeout=30) as f:
                return json.load(f)
        with open(origem, encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:  # noqa: BLE001
        print(f"Aviso: nao consegui ler a publicacao anterior ({e})", file=sys.stderr)
        return None


def main(argv):
    import argparse
    import os
    ap = argparse.ArgumentParser(description="Valida os dados gerados em site/data.")
    ap.add_argument("pasta", nargs="?", default=os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "site", "data"))
    ap.add_argument("--anterior", help="meta.json da publicacao anterior (ficheiro ou URL)")
    a = ap.parse_args(argv)
    ler = lambda nome: json.load(open(os.path.join(a.pasta, nome), encoding="utf-8"))  # noqa: E731
    r = validar(ler("net.json"), ler("shapes.json"), ler("meta.json"), ler_anterior(a.anterior))
    r.imprimir()
    return 0 if r.ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
