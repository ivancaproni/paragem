import test from 'node:test';
import assert from 'node:assert/strict';
import { condicoes, avisos, mostrarSensacao, forTrip, limparCache } from '../site/js/weather.js';
import { AVISOS, MOSTRAR_SENSACAO_DIF } from '../site/js/rules.js';
import { respostaFalsa } from './ajuda.js';

/** Condições neutras: nenhum aviso dispara. */
const calmo = () => ({ temp: 19, feels: 19, rain: 0, prob: 5, snow: 0, wind: 8, gust: 12, uv: 2, code: 1 });
const com = (mudancas) => ({ ...calmo(), ...mudancas });

test('cada regra de aviso dispara quando deve', () => {
  const casos = {
    trovoada: { code: 95 },
    neve: { snow: 0.4 },
    chuva: { rain: 0.5 },
    ventania: { gust: 60 },
    frio: { feels: 5 },
    cortavento: { feels: 15, wind: 30 },
    calor: { feels: 30 },
    sol: { uv: 8 },
  };
  for (const r of AVISOS) {
    assert.ok(casos[r.id], 'falta caso de teste para o aviso ' + r.id);
    assert.equal(r.teste(com(casos[r.id])), true, r.id + ' devia disparar');
    assert.equal(r.teste(calmo()), false, r.id + ' não devia disparar com tempo calmo');
  }
});

test('os caminhos alternativos de cada regra também disparam', () => {
  const id = (x) => AVISOS.find((r) => r.id === x);
  assert.equal(id('neve').teste(com({ code: 73 })), true, 'código de neve sem acumulação');
  assert.equal(id('chuva').teste(com({ prob: 40 })), true, 'só pela probabilidade');
  assert.equal(id('ventania').teste(com({ wind: 40 })), true, 'vento médio alto, sem rajada');
  assert.equal(id('cortavento').teste(com({ feels: 15, gust: 45, wind: 5 })), true, 'só pela rajada');
});

test('tempo calmo não gera avisos', () => {
  assert.deepEqual(avisos(calmo(), calmo()), []);
});

test('diz onde é o problema: origem, destino ou ambos', () => {
  assert.equal(avisos(com({ rain: 1 }), calmo())[0].where, 'origem');
  assert.equal(avisos(calmo(), com({ rain: 1 }))[0].where, 'destino');
  assert.equal(avisos(com({ rain: 1 }), com({ rain: 1 }))[0].where, 'ambos');
});

test('não mostra dois avisos do mesmo grupo', () => {
  // frio e corta-vento são ambos "casaco": só o primeiro passa
  const gelado = com({ feels: 5, wind: 35, gust: 50 });
  const ids = avisos(gelado, gelado).map((t) => t.id);
  assert.ok(ids.includes('frio'));
  assert.ok(!ids.includes('cortavento'));
});

test('nunca mostra mais do que dois avisos', () => {
  const horrivel = com({ code: 95, snow: 1, rain: 5, gust: 70, feels: 2, uv: 9 });
  assert.equal(avisos(horrivel, horrivel).length, 2);
});

test('a ordem das regras manda: o mais grave aparece primeiro', () => {
  const mau = com({ code: 95, rain: 5 });
  assert.equal(avisos(mau, mau)[0].id, 'trovoada');
});

test('a sensação térmica só se mostra quando difere mesmo', () => {
  assert.equal(mostrarSensacao({ temp: 18, feels: 18 }), false);
  assert.equal(mostrarSensacao({ temp: 18, feels: 18 - MOSTRAR_SENSACAO_DIF }), true);
  assert.equal(mostrarSensacao({ temp: 18, feels: null }), false);
  assert.equal(mostrarSensacao({ temp: null, feels: 10 }), false);
});

// ---------------------------------------------------------------- leitura da resposta
const respostaOpenMeteo = (horas) => ({
  current: { temperature_2m: 15, apparent_temperature: 14, precipitation: 0, weather_code: 1, wind_speed_10m: 9, wind_gusts_10m: 14 },
  hourly: {
    time: horas,
    temperature_2m: horas.map((_, i) => 18 + i),
    apparent_temperature: horas.map((_, i) => 18 + i),
    precipitation: horas.map(() => 0),
    precipitation_probability: horas.map(() => 10),
    snowfall: horas.map(() => 0),
    weather_code: horas.map(() => 1),
    wind_speed_10m: horas.map(() => 8),
    wind_gusts_10m: horas.map(() => 12),
    uv_index: horas.map(() => 3),
  },
});

test('condicoes escolhe a hora certa da previsão', () => {
  const loc = respostaOpenMeteo(['2026-09-22T08:00', '2026-09-22T09:00', '2026-09-22T10:00']);
  assert.equal(condicoes(loc, '2026-09-22', 9 * 60 + 40).temp, 19, 'as 09:40 usam a hora das 09:00');
  assert.equal(condicoes(loc, '2026-09-22', 10 * 60).temp, 20);
});

test('condicoes cai para a primeira hora quando a pedida não existe', () => {
  const loc = respostaOpenMeteo(['2026-09-22T08:00']);
  assert.equal(condicoes(loc, '2026-09-25', 9 * 60).temp, 18);
});

test('condicoes usa o "agora" quando não há série horária', () => {
  const loc = { current: { temperature_2m: 21, apparent_temperature: 20, wind_speed_10m: 5 } };
  const c = condicoes(loc, '2026-09-22', 9 * 60);
  assert.equal(c.temp, 21);
  assert.equal(c.feels, 20);
  assert.equal(c.rain, 0, 'o que falta fica a zero em vez de indefinido');
  assert.equal(c.prob, null);
});

test('condicoes aguenta uma resposta completamente vazia', () => {
  const c = condicoes(null, '2026-09-22', 0);
  assert.equal(c.temp, undefined);
  assert.equal(c.uv, 0);
});

test('forTrip junta origem, destino e avisos', async () => {
  limparCache();
  const horas = ['2026-09-22T08:00', '2026-09-22T09:00'];
  const dois = [respostaOpenMeteo(horas), respostaOpenMeteo(horas)];
  dois[1].hourly.precipitation = [2, 2];   // chove no destino
  const r = await forTrip({ lat: 41.1, lon: -8.6 }, { lat: 41.2, lon: -8.7 },
    '2026-09-22', 8 * 60, 9 * 60, async () => respostaFalsa(dois));
  assert.equal(r.tips.length, 1);
  assert.equal(r.tips[0].id, 'chuva');
  assert.equal(r.tips[0].where, 'destino');
});

test('forTrip aceita uma só coordenada devolvida como objeto', async () => {
  limparCache();
  const um = respostaOpenMeteo(['2026-09-22T08:00']);
  const r = await forTrip({ lat: 41.15, lon: -8.61 }, { lat: 41.15, lon: -8.61 },
    '2026-09-22', 8 * 60, 8 * 60, async () => respostaFalsa(um));
  assert.equal(r.origin.temp, r.dest.temp);
});

test('forTrip não repete o pedido para as mesmas coordenadas', async () => {
  limparCache();
  let contas = 0;
  const f = async () => { contas++; return respostaFalsa([respostaOpenMeteo(['2026-09-22T08:00'])]); };
  const args = [{ lat: 41.3, lon: -8.3 }, { lat: 41.4, lon: -8.4 }, '2026-09-22', 480, 540];
  await forTrip(...args, f);
  await forTrip(...args, f);
  assert.equal(contas, 1);
});

test('forTrip deixa passar o erro da API, para quem chama decidir', async () => {
  limparCache();
  await assert.rejects(
    () => forTrip({ lat: 1, lon: 1 }, { lat: 2, lon: 2 }, '2026-09-22', 0, 0,
      async () => respostaFalsa(null, { ok: false, status: 503 })),
    /HTTP 503/);
  limparCache();
  await assert.rejects(
    () => forTrip({ lat: 3, lon: 3 }, { lat: 4, lon: 4 }, '2026-09-22', 0, 0,
      async () => { throw new Error('sem rede'); }),
    /sem rede/);
});
