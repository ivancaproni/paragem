import test from 'node:test';
import assert from 'node:assert/strict';
import { criarStore, criarRecentes } from '../site/js/store.js';
import { INTERFACE } from '../site/js/rules.js';

/** Armazenamento de mentira, para não depender do browser. */
function memoria({ falharAoLer = false, falharAoEscrever = false, lixo = null } = {}) {
  const dados = new Map();
  return {
    dados,
    getItem(k) {
      if (falharAoLer) throw new Error('bloqueado');
      if (lixo && k === lixo) return '{isto não é json';
      return dados.has(k) ? dados.get(k) : null;
    },
    setItem(k, v) {
      if (falharAoEscrever) throw new Error('sem espaço');
      dados.set(k, v);
    },
  };
}

test('guarda e lê valores', () => {
  const s = criarStore(memoria());
  assert.equal(s.set('a', { x: 1 }), true);
  assert.deepEqual(s.get('a'), { x: 1 });
});

test('devolve o valor por omissão quando não há nada guardado', () => {
  const s = criarStore(memoria());
  assert.equal(s.get('nada', 'omissao'), 'omissao');
  assert.equal(s.get('nada'), undefined);
});

test('sobrevive a armazenamento bloqueado (navegação privada)', () => {
  const s = criarStore(memoria({ falharAoLer: true }));
  assert.equal(s.get('a', 'omissao'), 'omissao');
});

test('sobrevive a armazenamento cheio, e diz que não guardou', () => {
  const s = criarStore(memoria({ falharAoEscrever: true }));
  assert.equal(s.set('a', 1), false);
});

test('sobrevive a conteúdo corrompido', () => {
  const s = criarStore(memoria({ lixo: 'a' }));
  assert.equal(s.get('a', 'omissao'), 'omissao');
});

test('sem localStorage nenhum, não rebenta', () => {
  const s = criarStore(null);
  assert.equal(s.get('a', 'omissao'), 'omissao');
  assert.equal(s.set('a', 1), false);
});

test('recentes guardam no máximo o limite das regras', () => {
  const r = criarRecentes(criarStore(memoria()));
  for (let i = 0; i < INTERFACE.recentes + 3; i++) r.juntar('origin', { key: 'k' + i, label: 'L' + i });
  const l = r.lista('origin');
  assert.equal(l.length, INTERFACE.recentes);
  assert.equal(l[0].label, 'L' + (INTERFACE.recentes + 2), 'o mais recente fica à frente');
});

test('recentes não duplicam a mesma paragem', () => {
  const r = criarRecentes(criarStore(memoria()));
  r.juntar('dest', { key: 'BCM1', label: 'Bom Sucesso' });
  r.juntar('dest', { key: 'X', label: 'Outro' });
  r.juntar('dest', { key: 'BCM1', label: 'Bom Sucesso' });
  const l = r.lista('dest');
  assert.equal(l.length, 2);
  assert.equal(l[0].key, 'BCM1');
});

test('recentes ignoram entradas estragadas', () => {
  const bd = memoria();
  bd.setItem('recent_origin', JSON.stringify([null, { label: '' }, { key: 'a', label: 'A' }, 5]));
  const r = criarRecentes(criarStore(bd));
  assert.deepEqual(r.lista('origin').map((x) => x.key), ['a']);
});

test('recentes aguentam um valor guardado que não é lista', () => {
  const bd = memoria();
  bd.setItem('recent_dest', JSON.stringify({ nao: 'lista' }));
  const r = criarRecentes(criarStore(bd));
  assert.deepEqual(r.lista('dest'), []);
});

test('limpar apaga os dois lados', () => {
  const r = criarRecentes(criarStore(memoria()));
  r.juntar('origin', { key: 'a', label: 'A' });
  r.juntar('dest', { key: 'b', label: 'B' });
  r.limpar();
  assert.deepEqual(r.lista('origin'), []);
  assert.deepEqual(r.lista('dest'), []);
});
