/**
 * As zonas Andante contra a tabela oficial do planeador do Metro do Porto.
 *
 * É o teste que apanha erros que custam dinheiro (título a mais) ou uma multa
 * (título a menos). A tabela está em scripts/metro_titulos.json e tem os títulos
 * de todos os pares de estações do metro.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { Network, norm, dist } from '../site/js/engine.js';
import { redeCrua, datas, destinoEm } from './ajuda.js';

const raiz = join(dirname(fileURLToPath(import.meta.url)), '..');
const tabela = JSON.parse(readFileSync(join(raiz, 'scripts/metro_titulos.json'), 'utf8'));
const N = new Network(redeCrua());
const DIA = datas().primeira;

/** Liga cada estação da tabela à paragem correspondente na rede (por coordenadas). */
function ligar() {
  const metro = [];
  for (let i = 0; i < N.n; i++) if (N.stopId[i].startsWith('M:')) metro.push(i);
  return tabela.estacoes.map(([, lat, lon]) => {
    let melhor = -1, menor = 400;
    for (const i of metro) {
      const d = dist(lat, lon, N.lat[i], N.lon[i]);
      if (d < menor) { menor = d; melhor = i; }
    }
    return melhor;
  });
}
const ix = ligar();

test('a tabela oficial está completa e bem formada', () => {
  assert.equal(tabela.titulos.length, tabela.estacoes.length);
  for (const linha of tabela.titulos) {
    assert.equal(linha.length, tabela.estacoes.length);
    for (const c of linha) assert.ok(+c >= 2 && +c <= 9, 'título fora do intervalo Z2..Z9: ' + c);
  }
});

test('as estações da rede de exemplo estão todas na tabela', () => {
  const semPar = tabela.estacoes.filter((_, k) => ix[k] < 0).length;
  const naRede = ix.filter((i) => i >= 0).length;
  assert.ok(naRede >= 30, 'só ' + naRede + ' estações ligadas; a rede de exemplo devia ter mais');
  assert.ok(semPar > 0 || naRede === tabela.estacoes.length);
});

test('o título de cada par de estações é o oficial', () => {
  let iguais = 0, diferentes = 0;
  const erros = [];
  for (let a = 0; a < ix.length; a++) {
    if (ix[a] < 0) continue;
    for (let b = 0; b < ix.length; b++) {
      if (ix[b] < 0 || a === b) continue;
      const oficial = +tabela.titulos[a][b];
      const its = N.plan({ origin: ix[a], dest: destinoEm(N, ix[b]), date: DIA, time: 9 * 60 });
      const zs = its.map((it) => it.fare && it.fare.z).filter(Boolean).map((z) => +z.slice(1));
      if (!zs.length) continue;
      const calculado = Math.min(...zs);
      if (calculado === oficial) iguais++;
      else {
        diferentes++;
        if (erros.length < 5) {
          erros.push(`${tabela.estacoes[a][0]} → ${tabela.estacoes[b][0]}: app Z${calculado}, oficial Z${oficial}`);
        }
      }
    }
  }
  assert.ok(iguais > 100, 'poucos pares comparados: ' + iguais);
  assert.equal(diferentes, 0, 'pares com título errado:\n  ' + erros.join('\n  '));
});

test('as zonas do ficheiro de ajustes batem certo com a rede', () => {
  const ajustes = JSON.parse(readFileSync(join(raiz, 'scripts/zonas_ajustes.json'), 'utf8'));
  const zonasDaRede = new Set(N.zone.filter(Boolean));
  for (const chave of Object.keys(ajustes.distancias_oficiais || {})) {
    const [a, b] = chave.split('|');
    assert.ok(a && b, 'chave mal formada em distancias_oficiais: ' + chave);
    assert.equal(chave, [a, b].sort().join('|'), 'as chaves têm de estar por ordem alfabética: ' + chave);
  }
  for (const [a, vizinhas] of Object.entries(ajustes.adjacencias_extra || {})) {
    for (const b of vizinhas) {
      assert.ok((ajustes.adjacencias_extra[b] || []).includes(a),
        `vizinhança só num sentido: ${a} tem ${b}, mas ${b} não tem ${a}`);
    }
  }
  assert.ok(zonasDaRede.size > 0);
});

test('o mesmo par de zonas dá sempre o mesmo número de anéis', () => {
  const zonas = [...new Set(N.zone.filter(Boolean))];
  for (const z of zonas) {
    const d = N.zoneDistances(z);
    for (const outra of zonas) {
      if (!(outra in d)) continue;
      const volta = N.zoneDistances(outra);
      assert.equal(d[outra], volta[z], `anéis diferentes entre ${z} e ${outra}`);
    }
  }
});

test('norm é o mesmo dos dois lados, senão as estações não casavam', () => {
  assert.equal(norm('Câmara de Gaia'), norm('CAMARA DE GAIA'));
});
