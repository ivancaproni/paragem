"""
Testes das validacoes de sanidade dos dados (scripts/validar.py).

O pipeline nao tinha testes nenhuns, e e ele que pode estragar tudo em silencio.
Cada teste aqui parte os dados de uma maneira plausivel (um campo que a fonte
mudou, um GTFS truncado, uma zona que se perdeu) e confirma que a validacao
apanha o problema em vez de deixar publicar.

Correr:
    python3 testes/testar_validacoes.py

Nao precisa de internet nem de nada instalado.
"""
import copy
import json
import os
import sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, 'scripts'))
from validar import LIMITES, comparacao, ler_anterior, validar, Resultado  # noqa: E402

falhas, passou = [], []


def verificar(condicao, descricao):
    (passou if condicao else falhas).append(descricao)
    print(('  ok   ' if condicao else '  FALHA ') + descricao)


def grupo(titulo):
    print('\n# ' + titulo)


# ---------------------------------------------------------------- dados de exemplo
def rede_boa():
    """A rede de exemplo, esticada ate parecer uma rede a serio.

    A fixture e um recorte pequeno do Porto; os minimos absolutos sao para a rede
    inteira. Em vez de baixar os minimos (que e o que se quer testar), inventa-se
    um meta com os numeros de uma rede completa.
    """
    net = json.load(open(os.path.join(RAIZ, 'testes', 'fixtures', 'rede.json'), encoding='utf-8'))
    shapes = json.load(open(os.path.join(RAIZ, 'testes', 'fixtures', 'shapes.json'), encoding='utf-8'))
    meta = {
        'stops': 2400, 'stops_with_zone': 2400, 'routes': 80, 'patterns': 400,
        'trips': 60000, 'days_with_service': 8, 'zones': 60, 'metro_stops': 85,
        'failed_routes': [],
    }
    return net, shapes, meta


def erros_de(net, shapes, meta, anterior=None):
    return validar(net, shapes, meta, anterior).erros


# ---------------------------------------------------------------- base
grupo('a rede de exemplo passa')
NET, SHAPES, META = rede_boa()
r = validar(NET, SHAPES, META, META)
verificar(r.ok, 'dados bons nao dao erro nenhum: ' + '; '.join(r.erros))
# a fixture e um recorte da rede, com 39 das 85 estacoes de metro: o unico aviso
# esperado e esse. Qualquer outro seria uma validacao a disparar sem razao.
inesperados = [a for a in r.avisos if 'tabela oficial' not in a]
verificar(not inesperados, 'sem avisos inesperados: ' + '; '.join(inesperados))

# ---------------------------------------------------------------- coerencia interna
grupo('coerencia interna')

net = copy.deepcopy(NET)
net['patterns'][0]['s'][1] = 99999
verificar(any('nao existem' in e for e in erros_de(net, SHAPES, META)),
          'um padrao a apontar para uma paragem inexistente e apanhado')

net = copy.deepcopy(NET)
net['patterns'][0]['r'] = 99
verificar(any('indice de linha invalido' in e for e in erros_de(net, SHAPES, META)),
          'um padrao a apontar para uma linha inexistente e apanhado')

net = copy.deepcopy(NET)
net['patterns'][0]['p'][0] = list(reversed(net['patterns'][0]['p'][0]))
verificar(any('para tras' in e for e in erros_de(net, SHAPES, META)),
          'horas a andar para tras dentro da viagem sao apanhadas')

net = copy.deepcopy(NET)
net['patterns'][0]['p'][0] = net['patterns'][0]['p'][0][:-1]
verificar(any('numero de horas diferente' in e for e in erros_de(net, SHAPES, META)),
          'um perfil com menos horas do que paragens e apanhado')

net = copy.deepcopy(NET)
net['patterns'][0]['t'] = net['patterns'][0]['t'][:-1]
verificar(any('malformada' in e for e in erros_de(net, SHAPES, META)),
          'a tabela de viagens truncada e apanhada')

net = copy.deepcopy(NET)
net['patterns'][0]['t'][1] = 77
verificar(any('perfil inexistente' in e for e in erros_de(net, SHAPES, META)),
          'uma viagem com perfil inexistente e apanhada')

net = copy.deepcopy(NET)
net['patterns'][0]['t'][2] = 7777
verificar(any('servico inexistente' in e for e in erros_de(net, SHAPES, META)),
          'uma viagem com servico inexistente e apanhada')

net = copy.deepcopy(NET)
net['patterns'][0]['sh'] = 9999
verificar(any('desenho do percurso' in e for e in erros_de(net, SHAPES, META)),
          'um desenho de percurso inexistente e apanhado')

net = copy.deepcopy(NET)
net['patterns'][0]['s'] = net['patterns'][0]['s'][:1]
verificar(any('so tem 1 paragem' in e for e in erros_de(net, SHAPES, META)),
          'um padrao com uma so paragem e apanhado')

net = copy.deepcopy(NET)
net['stops'][0][3] = 38.72   # Lisboa
verificar(any('fora do Grande Porto' in e for e in erros_de(net, SHAPES, META)),
          'uma paragem fora da area coberta e apanhada')

net = copy.deepcopy(NET)
net['stops'][1][0] = net['stops'][0][0]
verificar(any('repetido' in e for e in erros_de(net, SHAPES, META)),
          'identificadores de paragem repetidos sao apanhados')

net = copy.deepcopy(NET)
net['stops'][0][2] = '   '
verificar(any('sem nome' in e for e in erros_de(net, SHAPES, META)),
          'uma paragem sem nome e apanhada')

net = copy.deepcopy(NET)
alguma = sorted(net['zoneAdj'])[0]
net['zoneAdj'][alguma] = net['zoneAdj'][alguma] + ['ZONA_SO_NUM_SENTIDO']
verificar(any('assimetrica' in e for e in erros_de(net, SHAPES, META)),
          'vizinhanca de zonas so num sentido e apanhada')

net = copy.deepcopy(NET)
net['calendar'][sorted(net['calendar'])[0]] = [9999]
verificar(any('servicos que nao existem' in e for e in erros_de(net, SHAPES, META)),
          'o calendario a apontar para servicos inexistentes e apanhado')

net = copy.deepcopy(NET)
net['used'] = []
verificar(any('paragens com linhas' in e for e in erros_de(net, SHAPES, META)),
          'ficar sem paragens com linhas e apanhado')

net = copy.deepcopy(NET)
net['metroZ']['z'] = net['metroZ']['z'][:-1]
verificar(any('tabela do metro' in e for e in erros_de(net, SHAPES, META)),
          'a tabela do metro truncada e apanhada')

net = copy.deepcopy(NET)
net['metroZ']['z'][0] = net['metroZ']['z'][0][:-1]
verificar(any('quadrada' in e for e in erros_de(net, SHAPES, META)),
          'a tabela do metro nao quadrada e apanhada')

net = copy.deepcopy(NET)
net['metroZ']['i'][0] = 99999
verificar(any('tabela do metro aponta' in e for e in erros_de(net, SHAPES, META)),
          'a tabela do metro a apontar para paragens inexistentes e apanhada')

net = copy.deepcopy(NET)
net['metroZ']['z'][0] = 'x' * len(net['metroZ']['i'])
verificar(any('nao sao numeros' in e for e in erros_de(net, SHAPES, META)),
          'valores nao numericos na tabela do metro sao apanhados')

verificar(any('sem paragens' in e for e in erros_de({}, SHAPES, META)),
          'um net.json vazio nao rebenta, da erro')

# ---------------------------------------------------------------- plausibilidade
grupo('plausibilidade')

for campo, texto in [('stops', 'paragens'), ('routes', 'linhas'),
                     ('patterns', 'padroes'), ('trips', 'viagens')]:
    meta = dict(META, **{campo: 1})
    verificar(any(texto in e and 'minimo' in e for e in erros_de(NET, SHAPES, meta)),
              f'uma rede com uma so das suas {texto} e recusada')

meta = dict(META, days_with_service=1)
verificar(any('dias com servico' in e for e in erros_de(NET, SHAPES, meta)),
          'um calendario quase vazio e recusado')

meta = dict(META, stops_with_zone=int(META['stops'] * 0.90))
verificar(any('zona Andante' in e for e in erros_de(NET, SHAPES, meta)),
          '10% das paragens sem zona e recusado (o app nao diria o titulo)')

meta = dict(META, stops_with_zone=int(META['stops'] * 0.99))
verificar(not any('zona Andante' in e for e in erros_de(NET, SHAPES, meta)),
          '1% sem zona passa: ha sempre paragens novas por classificar')

meta = dict(META, failed_routes=['1', '2', '3', '4', '5', '6', '7'])
verificar(any('sem horarios' in e for e in erros_de(NET, SHAPES, meta)),
          'muitas linhas sem horarios sao recusadas')

meta = dict(META, failed_routes=['ZC'])
r = validar(NET, SHAPES, meta, meta)
verificar(r.ok and any('ZC' in a for a in r.avisos),
          'uma linha sem horarios e so aviso (a ZC e um caso conhecido)')

meta = dict(META, metro_stops=0)
r = validar(NET, SHAPES, meta, meta)
verificar(r.ok and any('metro' in a for a in r.avisos),
          'ficar sem metro avisa mas nao bloqueia (a STCP sozinha ainda serve)')

net = copy.deepcopy(NET)
net['metroZ']['i'] = net['metroZ']['i'][:10]
net['metroZ']['z'] = [x[:10] for x in net['metroZ']['z'][:10]]
r = validar(net, SHAPES, META, META)
verificar(any('tabela oficial' in a for a in r.avisos),
          'poucas estacoes na tabela oficial avisa: os titulos passam a estimados')

# ---------------------------------------------------------------- comparacao
grupo('comparacao com a ultima publicacao')


def comparar(novo, velho):
    r = Resultado()
    comparacao(novo, velho, r)
    return r


ANTES = dict(META)
verificar(comparar(dict(ANTES, stops=int(ANTES['stops'] * 0.5)), ANTES).erros,
          'metade das paragens a desaparecer bloqueia a publicacao')
verificar(not comparar(dict(ANTES, stops=int(ANTES['stops'] * 0.95)), ANTES).erros,
          '5% a menos passa: e uma mudanca normal de horarios')
verificar(comparar(dict(ANTES, routes=int(ANTES['routes'] * 0.5)), ANTES).erros,
          'metade das linhas a desaparecer bloqueia')
verificar(comparar(dict(ANTES, patterns=ANTES['patterns'] * 3), ANTES).erros,
          'os padroes a triplicar bloqueia (parece dados duplicados)')

r = comparar(dict(ANTES, trips=int(ANTES['trips'] * 0.5)), ANTES)
verificar(not r.erros and r.avisos,
          'metade das viagens e so aviso: em agosto acontece mesmo')

r = comparar(dict(ANTES, stops_with_zone=int(ANTES['stops'] * 0.90)), ANTES)
verificar(r.erros, 'perder zonas face a ultima publicacao bloqueia')

r = comparar(ANTES, None)
verificar(not r.erros and r.avisos,
          'sem publicacao anterior nao bloqueia, so avisa')

r = comparar(ANTES, {'stops': 'nao e um numero'})
verificar(not r.erros, 'um meta anterior estragado nao bloqueia a publicacao')

verificar(ler_anterior(None) is None, 'sem origem, nao se le nada')
verificar(ler_anterior('/nao/existe/meta.json') is None,
          'um ficheiro anterior que nao existe nao rebenta')
verificar(ler_anterior('http://127.0.0.1:1/meta.json') is None,
          'nao conseguir descarregar o anterior nao rebenta')

# ---------------------------------------------------------------- limites
grupo('os limites fazem sentido entre si')
verificar(0 < LIMITES['min_paragens_com_zona'] <= 1, 'a fracao de zonas esta entre 0 e 1')
verificar(all(0 < v < 1 for v in LIMITES['queda_maxima'].values()), 'as quedas maximas sao fracoes')
verificar(all(v > 0 for v in LIMITES['subida_maxima'].values()), 'as subidas maximas sao positivas')
lat0, lat1 = LIMITES['caixa']['lat']
lon0, lon1 = LIMITES['caixa']['lon']
verificar(lat0 < 41.15 < lat1 and lon0 < -8.61 < lon1, 'a caixa contem a Baixa do Porto')

# ---------------------------------------------------------------- fim
print(f'\n{len(passou)} passaram, {len(falhas)} falharam')
if falhas:
    for f in falhas:
        print('  - ' + f)
sys.exit(1 if falhas else 0)
