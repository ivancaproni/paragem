/**
 * Tarifário Andante: os casos normais estão no engine.test.js (percursos a
 * sério). Aqui ficam os casos em que não se consegue dizer o título, que são
 * os que dão erro silencioso se ninguém os testar.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { Network } from '../site/js/engine.js';
import { distanciasDeZona, tituloMetro, titulo } from '../site/js/tarifario.js';
import { redeCrua, datas, destinoEm } from './ajuda.js';

const N = new Network(redeCrua());
const DIA = datas().primeira;

/** Um percurso real da rede de exemplo, para depois lhe mexer nas zonas. */
function umPercurso() {
  const usadas = [];
  for (let i = 0; i < N.n; i++) if (N.used[i]) usadas.push(i);
  for (const o of usadas) {
    for (const d of usadas) {
      if (o === d) continue;
      const its = N.plan({ origin: o, dest: destinoEm(N, d), date: DIA, time: 9 * 60 });
      const it = its.find((x) => x.complete && x.legs.filter((l) => l.type === 'ride').length >= 1);
      if (it) return it;
    }
  }
  throw new Error('a rede de exemplo devia dar pelo menos um percurso de transporte');
}

test('ir a pé não precisa de título', () => {
  assert.equal(titulo(N, { legs: [{ type: 'walk', dur: 5 }] }), null);
});

test('sem zona na paragem de embarque, não se inventa título', () => {
  const it = umPercurso();
  const rides = it.legs.filter((l) => l.type === 'ride');
  const guardado = N.zone[rides[0].from];
  N.zone[rides[0].from] = '';
  try {
    const f = titulo(N, it);
    assert.equal(f.z, null);
    assert.equal(f.reason, 'zona desconhecida');
    assert.ok(!f.zones.includes(''), 'a zona vazia não deve aparecer na lista');
  } finally { N.zone[rides[0].from] = guardado; }
});

test('com uma zona que a rede não conhece, avisa em vez de arriscar', () => {
  const it = umPercurso();
  const rides = it.legs.filter((l) => l.type === 'ride');
  const meio = rides[0].stops[Math.floor(rides[0].stops.length / 2)];
  const guardado = N.zone[meio];
  N.zone[meio] = 'ZONA_INVENTADA';
  try {
    const f = titulo(N, it);
    assert.equal(f.z, null);
    assert.equal(f.reason, 'adjacencia de zonas desconhecida');
    assert.ok(f.zones.includes('ZONA_INVENTADA'));
  } finally { N.zone[meio] = guardado; }
});

test('um título fora do tarifário não traz preço nem validade', () => {
  const it = umPercurso();
  const rides = it.legs.filter((l) => l.type === 'ride');
  const z0 = N.zone[rides[0].from];
  // distância absurda entre zonas: o anel calculado passa do Z9
  const chave = z0 + '|' + N.zone[rides[rides.length - 1].to];
  const guardado = N.zoneDist[chave];
  N.zoneDist[chave] = 20;
  try {
    const f = titulo(N, it);
    if (f.fonte === 'estimativa') {
      assert.equal(f.z, 'Z21');
      assert.equal(f.preco, null);
      assert.equal(f.dur, null);
      assert.equal(f.overTime, false);
    }
  } finally {
    if (guardado === undefined) delete N.zoneDist[chave]; else N.zoneDist[chave] = guardado;
  }
});

test('a tabela do metro só vale para percursos feitos só de metro', () => {
  assert.equal(tituloMetro(N, []), null, 'sem viagens não há título de metro');
  const it = umPercurso();
  const rides = it.legs.filter((l) => l.type === 'ride');
  const soAutocarro = rides.filter((r) => N.routes[N.patterns[r.pi].r].type !== 1);
  if (soAutocarro.length) assert.equal(tituloMetro(N, soAutocarro), null);
});

test('sem tabela do metro carregada, devolve null em vez de rebentar', () => {
  const guardado = N.metroZ;
  N.metroZ = null;
  try { assert.equal(tituloMetro(N, [{ from: 0, to: 1, pi: 0 }]), null); }
  finally { N.metroZ = guardado; }
});

test('uma estação fora da tabela oficial não dá título de metro', () => {
  const metro = [];
  for (let i = 0; i < N.n && metro.length < 2; i++) {
    const r = N.routeAt(i);
    if (r && r.type === 1 && N.metroZi.has(i)) metro.push(i);
  }
  if (metro.length < 2) return;   // a rede de exemplo pode não ter metro
  const pi = N.stopPatterns[metro[0]][0];
  assert.equal(tituloMetro(N, [{ from: metro[0], to: -999, pi }]), null);
  assert.equal(tituloMetro(N, [{ from: -999, to: metro[1], pi }]), null);
});

test('distanciasDeZona conta zero para a própria zona', () => {
  const z = N.zone.find(Boolean);
  assert.equal(distanciasDeZona(N, z)[z], 0);
});

test('uma zona isolada só se conhece a si própria', () => {
  const d = distanciasDeZona(N, 'ZONA_QUE_NAO_EXISTE');
  assert.equal(d.ZONA_QUE_NAO_EXISTE, 0);
});
