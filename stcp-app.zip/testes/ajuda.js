/** Apoio aos testes: carrega a rede de exemplo e dá datas que não envelhecem. */
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const aqui = dirname(fileURLToPath(import.meta.url));

export const redeCrua = () => JSON.parse(readFileSync(join(aqui, 'fixtures/rede.json'), 'utf8'));

/**
 * Datas do calendário da rede de exemplo. Os testes usam estas em vez de datas
 * escritas à mão, senão deixavam de passar quando o calendário ficasse velho.
 */
export function datas() {
  const cal = Object.keys(redeCrua().calendar).sort();
  return { primeira: cal[0], ultima: cal[cal.length - 1], todas: cal };
}

/** Índice da paragem cujo nome contém o texto (sem acentos nem maiúsculas). */
export function acharParagem(N, texto, norm) {
  const alvo = norm(texto);
  const i = N.stopName.findIndex((x) => norm(x).includes(alvo));
  if (i < 0) throw new Error('paragem não encontrada na rede de exemplo: ' + texto);
  return i;
}

/** Destino no formato que o motor espera, a partir de um índice de paragem. */
export const destinoEm = (N, i) => ({ lat: N.lat[i], lon: N.lon[i], stop: i });

/** Resposta de fetch falsa, para testar sem rede. */
export function respostaFalsa(corpo, { ok = true, status = 200, atirarNoJson = false } = {}) {
  return {
    ok, status,
    json: async () => {
      if (atirarNoJson) throw new SyntaxError('JSON inválido');
      return corpo;
    },
  };
}
