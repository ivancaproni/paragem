"""
Testes do pipeline de dados (scripts/build_data.py), de ponta a ponta.

Constroi um GTFS pequeno em memoria, passa-o pelo mesmo caminho que os dados a
serio percorrem (load_gtfs -> merge -> pack) e confirma que o net.json que sai
esta coerente. Nao toca na rede: o GTFS e inventado aqui.

Correr:
    python3 testes/testar_pipeline.py
"""
import datetime
import io
import json
import os
import sys
import zipfile

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, 'scripts'))
import build_data as B  # noqa: E402
from validar import coerencia, Resultado  # noqa: E402

falhas, passou = [], []


def verificar(condicao, descricao):
    (passou if condicao else falhas).append(descricao)
    print(('  ok   ' if condicao else '  FALHA ') + descricao)


def grupo(titulo):
    print('\n# ' + titulo)


# ---------------------------------------------------------------- GTFS de brincar
def gtfs(paragens, linhas, viagens, horas, calendario=None, formas=None):
    """Monta um zip GTFS valido a partir de listas de tuplos."""
    hoje = datetime.date.today()
    ficheiros = {
        'stops.txt': ['stop_id,stop_code,stop_name,stop_lat,stop_lon,zone_id'] +
                     [','.join(map(str, p)) for p in paragens],
        'routes.txt': ['route_id,route_short_name,route_long_name,route_type'] +
                      [','.join(map(str, r)) for r in linhas],
        'trips.txt': ['route_id,service_id,trip_id,trip_headsign,direction_id,shape_id'] +
                     [','.join(map(str, t)) for t in viagens],
        'stop_times.txt': ['trip_id,arrival_time,departure_time,stop_id,stop_sequence'] +
                          [','.join(map(str, h)) for h in horas],
        'calendar.txt': ['service_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,start_date,end_date'] +
                        (calendario or [f'S1,1,1,1,1,1,1,1,{hoje:%Y%m%d},'
                                        f'{hoje + datetime.timedelta(days=60):%Y%m%d}']),
        'calendar_dates.txt': ['service_id,date,exception_type'],
        'shapes.txt': ['shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence'] + (formas or []),
    }
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        for nome, linhas_txt in ficheiros.items():
            z.writestr(nome, '\n'.join(linhas_txt) + '\n')
    buf.seek(0)
    return zipfile.ZipFile(buf)


def rede_simples():
    """Uma linha com quatro paragens na Baixa do Porto, duas viagens por sentido."""
    paragens = [
        ('A', 'AAA1', 'ALIADOS', 41.1490, -8.6110, 'PRT1'),
        ('B', 'BBB1', 'BOLHAO', 41.1500, -8.6070, 'PRT1'),
        ('C', 'CCC1', 'CAMPANHA', 41.1490, -8.5850, 'PRT2'),
        ('D', 'DDD1', 'DRAGAO', 41.1620, -8.5830, 'PRT2'),
    ]
    linhas = [('L1', '205', 'Aliados - Dragao', 3)]
    viagens = [('L1', 'S1', 'T1', 'DRAGAO', 0, 'SH1'), ('L1', 'S1', 'T2', 'DRAGAO', 0, 'SH1')]
    horas = []
    for tid, base in (('T1', 8), ('T2', 9)):
        for k, sid in enumerate('ABCD'):
            h = f'{base:02d}:{k * 7:02d}:00'
            horas.append((tid, h, h, sid, k + 1))
    formas = [f'SH1,{lat},{lon},{k}' for k, (_, _, _, lat, lon, _) in enumerate(paragens)]
    return gtfs(paragens, linhas, viagens, horas, formas=formas)


# ---------------------------------------------------------------- caminho completo
grupo('um GTFS simples atravessa o pipeline inteiro')
feed = B.load_gtfs(rede_simples(), 'teste')
verificar(len(feed.stops) == 4, f'as 4 paragens foram lidas (leu {len(feed.stops)})')
verificar(len(feed.trips) == 2, f'as 2 viagens foram lidas (leu {len(feed.trips)})')

net, shapes, meta = B.pack(feed)
r = Resultado()
coerencia(net, shapes, r)
verificar(r.ok, 'o net.json gerado esta coerente: ' + '; '.join(r.erros))

verificar(net['v'] == 2, 'a versao do formato e a 2 (tempos em segundos)')
verificar(len(net['patterns']) == 1, f"as duas viagens deram um so padrao (deu {len(net['patterns'])})")
verificar(len(net['patterns'][0]['t']) == 6, 'o padrao tem as duas viagens')
verificar(meta['stops'] == 4 and meta['routes'] == 1, 'o meta conta o que existe')
verificar(meta['trips'] == 2, f"o meta conta 2 viagens (contou {meta['trips']})")
verificar(sorted(net['used']) == [0, 1, 2, 3], 'as quatro paragens ficam marcadas como servidas')

grupo('zonas')
# pack() junta sempre o scripts/zonas_ajustes.json real, por isso o mapa tem mais
# zonas do que as duas desta rede: o que se verifica e a fronteira inferida daqui.
verificar('PRT2' in net['zoneAdj'].get('PRT1', []) and 'PRT1' in net['zoneAdj'].get('PRT2', []),
          'a fronteira PRT1/PRT2 foi inferida nos dois sentidos')
verificar(meta['zones'] == 2, f"contou 2 zonas nas paragens servidas (contou {meta['zones']})")

grupo('paragens distantes nao provam fronteira de zona')
# a mesma rede, mas com a paragem C em Espinho: e um expresso, nao uma fronteira
longe = [
    ('A', 'AAA1', 'ALIADOS', 41.1490, -8.6110, 'PRT1'),
    ('B', 'BBB1', 'BOLHAO', 41.1500, -8.6070, 'PRT1'),
    ('C', 'CCC1', 'ESPINHO', 41.0070, -8.6410, 'ESP1'),
]
horas = []
for k, sid in enumerate('ABC'):
    h = f'08:{k * 10:02d}:00'
    horas.append(('T1', h, h, sid, k + 1))
feed2 = B.load_gtfs(gtfs(longe, [('L1', '906', 'Expresso', 3)],
                         [('L1', 'S1', 'T1', 'ESPINHO', 0, '')], horas), 'teste')
net2, _, _ = B.pack(feed2)
verificar('ESP1' not in net2['zoneAdj'].get('PRT1', []) and 'ESP1' not in net2['zoneAdj'],
          'um salto de 16 km nao cria fronteira de zona')

grupo('juntar o metro a rede da STCP')
metro = [
    ('M1', 'TRD', 'TRINDADE', 41.1520, -8.6090, 'PRT1'),
    ('M2', 'CSM', 'CASA DA MUSICA', 41.1590, -8.6300, 'PRT1'),
]
horas_m = []
for k, sid in enumerate(('M1', 'M2')):
    h = f'08:{k * 4:02d}:00'
    horas_m.append(('MT1', h, h, sid, k + 1))
fm = B.load_gtfs(gtfs(metro, [('ML', 'D', 'Linha Amarela', 1)],
                      [('ML', 'S1', 'MT1', 'HOSPITAL', 0, '')], horas_m), 'metro')
base = B.load_gtfs(rede_simples(), 'teste')
B.merge(base, fm, B.METRO_PREFIX)
net3, _, meta3 = B.pack(base)
r3 = Resultado()
coerencia(net3, shapes, r3)
verificar(r3.ok, 'a rede com metro continua coerente: ' + '; '.join(r3.erros))
verificar(meta3['stops'] == 6, f"as 6 paragens estao la (ficaram {meta3['stops']})")
verificar(meta3['metro_stops'] == 2, f"duas sao de metro (contou {meta3['metro_stops']})")
ids = [s[0] for s in net3['stops']]
verificar(all(i.startswith(B.METRO_PREFIX) for i in ids if 'M1' in i or 'M2' in i),
          'as estacoes de metro ficam com prefixo, para nao chocarem com a STCP')
tipos = {r[0]: r[4] for r in net3['routes']}
verificar(tipos.get('D') == 1 and tipos.get('205') == 3,
          f'o metro fica com tipo 1 e o autocarro com tipo 3 ({tipos})')

grupo('entradas estragadas nao rebentam o pipeline')
sem_coords = [('A', 'A', 'SEM COORDENADAS', 'x', 'y', 'PRT1'),
              ('B', 'B', 'BOA', 41.15, -8.61, 'PRT1')]
f4 = B.load_gtfs(gtfs(sem_coords, [('L1', '1', 'x', 3)], [], []), 'teste')
verificar(list(f4.stops) == ['B'], 'uma paragem com coordenadas invalidas e ignorada')

horas_curtas = [('T1', '08:00:00', '08:00:00', 'A', 1)]
f5 = B.load_gtfs(gtfs([('A', 'A', 'SO UMA', 41.15, -8.61, 'PRT1')], [('L1', '1', 'x', 3)],
                      [('L1', 'S1', 'T1', 'x', 0, '')], horas_curtas), 'teste')
verificar(f5.trips == [], 'uma viagem com uma so paragem e ignorada')

grupo('horas depois da meia-noite')
madrugada = [('T1', '23:50:00', '23:50:00', 'A', 1), ('T1', '24:10:00', '24:10:00', 'B', 2)]
f6 = B.load_gtfs(gtfs([('A', 'A', 'A', 41.15, -8.61, 'PRT1'), ('B', 'B', 'B', 41.16, -8.60, 'PRT1')],
                      [('L1', '1', 'x', 3)], [('L1', 'S1', 'T1', 'x', 0, '')], madrugada), 'teste')
verificar(f6.trips and f6.trips[0][5] == [23 * 3600 + 50 * 60, 24 * 3600 + 10 * 60],
          'as 24:10 ficam como 24:10, nao voltam a zero')

print(f'\n{len(passou)} passaram, {len(falhas)} falharam')
if falhas:
    for f in falhas:
        print('  - ' + f)
sys.exit(1 if falhas else 0)
