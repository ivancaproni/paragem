import test from 'node:test';
import assert from 'node:assert/strict';
import { esc, hhmm, fmtDist, fmtDur, euro, deg, dataPt, lisbonNow, lisbonParts } from '../site/js/format.js';

test('esc protege todos os caracteres que podem fechar uma etiqueta HTML', () => {
  assert.equal(esc('<script>'), '&lt;script&gt;');
  assert.equal(esc('a & b'), 'a &amp; b');
  assert.equal(esc('diz "olá"'), 'diz &quot;olá&quot;');
  assert.equal(esc("d'Este"), 'd&#39;Este');
  assert.equal(esc('<img src=x onerror="alert(1)">'),
    '&lt;img src=x onerror=&quot;alert(1)&quot;&gt;');
});

test('esc aguenta valores que não são texto', () => {
  assert.equal(esc(null), '');
  assert.equal(esc(undefined), '');
  assert.equal(esc(0), '0');
  assert.equal(esc(false), 'false');
  assert.equal(esc(['<a>']), '&lt;a&gt;');
});

test('hhmm formata e dá a volta ao relógio', () => {
  assert.equal(hhmm(0), '00:00');
  assert.equal(hhmm(485), '08:05');
  assert.equal(hhmm(1439), '23:59');
  assert.equal(hhmm(1440), '00:00');       // meia-noite do dia seguinte
  assert.equal(hhmm(1500), '01:00');       // horário 25:00 (serviço da madrugada)
  assert.equal(hhmm(-30), '23:30');        // antes da meia-noite
  assert.equal(hhmm(485.4), '08:05');      // arredonda
});

test('fmtDist muda de metros para quilómetros', () => {
  assert.equal(fmtDist(0), '0 m');
  assert.equal(fmtDist(244), '240 m');
  assert.equal(fmtDist(949), '950 m');
  assert.equal(fmtDist(950), '1,0 km');
  assert.equal(fmtDist(1234), '1,2 km');
});

test('fmtDur muda de minutos para horas', () => {
  assert.equal(fmtDur(0), '0 min');
  assert.equal(fmtDur(59), '59 min');
  assert.equal(fmtDur(60), '1 h 00');
  assert.equal(fmtDur(65), '1 h 05');
  assert.equal(fmtDur(125), '2 h 05');
});

test('euro usa vírgula e cai para vazio sem valor', () => {
  assert.equal(euro(1.4), '1,40 €');
  assert.equal(euro(0), '0,00 €');
  assert.equal(euro(null), '');
  assert.equal(euro(undefined), '');
});

test('deg arredonda e marca a falta de leitura', () => {
  assert.equal(deg(18.6), '19°');
  assert.equal(deg(0), '0°');
  assert.equal(deg(null), '—');
  assert.equal(deg(undefined), '—');
});

test('dataPt inverte a data ISO', () => {
  assert.equal(dataPt('2026-09-22'), '22/09/2026');
});

test('lisbonNow devolve a hora de Lisboa, não a do sistema', () => {
  // 12:30 UTC em setembro = 13:30 em Lisboa (hora de verão)
  const r = lisbonNow(new Date('2026-09-22T12:30:00Z'));
  assert.equal(r.date, '2026-09-22');
  assert.equal(r.min, 13 * 60 + 30);
  // e em janeiro não há hora de verão
  const inverno = lisbonNow(new Date('2026-01-15T12:30:00Z'));
  assert.equal(inverno.min, 12 * 60 + 30);
});

test('lisbonNow sem argumento usa o momento atual', () => {
  const r = lisbonNow();
  assert.match(r.date, /^\d{4}-\d{2}-\d{2}$/);
  assert.ok(r.min >= 0 && r.min < 1440);
});

test('lisbonParts dá os segundos, para comparar com horários ao segundo', () => {
  const r = lisbonParts(new Date('2026-09-22T12:30:45Z'));
  assert.equal(r.date, '2026-09-22');
  assert.equal(r.sec, 13 * 3600 + 30 * 60 + 45);
});

test('lisbonParts vira o dia antes da meia-noite de Lisboa', () => {
  // 23:30 UTC = 00:30 do dia seguinte em Lisboa
  const r = lisbonParts(new Date('2026-09-22T23:30:00Z'));
  assert.equal(r.date, '2026-09-23');
  assert.equal(r.sec, 30 * 60);
});
