/**
 * O modelo de custo é o sítio onde se muda o comportamento do app sem tocar no
 * algoritmo. Como agora está separado, dá para o testar sem rede nenhuma:
 * cada decisão é uma função pura com entradas óbvias.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { CUSTO, horaDeSair } from '../site/js/custo.js';
import { A_PE, PERCURSO } from '../site/js/rules.js';

// ---------------------------------------------------------------- a pé
test('minutos a pé nunca ficam abaixo do mínimo', () => {
  assert.equal(CUSTO.minutosAPe(0), A_PE.minimo_min);
  assert.equal(CUSTO.minutosAPe(1), A_PE.minimo_min);
  assert.equal(CUSTO.minutosDeRua(0), A_PE.minimo_min);
});

test('a pé cresce com a distância e aplica o desvio das ruas uma só vez', () => {
  assert.ok(CUSTO.minutosAPe(1000) > CUSTO.minutosAPe(400));
  // a mesma distância, já medida pela rua, dá menos tempo do que em linha reta
  assert.ok(CUSTO.minutosDeRua(1000) < CUSTO.minutosAPe(1000));
  assert.equal(CUSTO.minutosDeRua(CUSTO.metrosDeRua(1000)), CUSTO.minutosAPe(1000));
});

test('metrosDeRua devolve inteiros maiores do que a linha reta', () => {
  const m = CUSTO.metrosDeRua(800);
  assert.ok(Number.isInteger(m) && m > 800);
});

test('o troço de carro é mais rápido do que o mesmo troço a pé', () => {
  assert.ok(CUSTO.minutosDeCarro(5000) < CUSTO.minutosAPe(5000));
});

// ---------------------------------------------------------------- transbordos
test('só se espera tempo de transbordo quando se vem de um transporte', () => {
  assert.equal(CUSTO.esperaNoTransbordo(true), PERCURSO.troca_na_mesma_paragem_min);
  assert.equal(CUSTO.esperaNoTransbordo(false), 0);
});

// ---------------------------------------------------------------- embarque
test('entre paragens do mesmo autocarro ganha a que dá menos caminhada', () => {
  const perto = { m: 100, dep: 500 }, longe = { m: 400, dep: 520 };
  assert.equal(CUSTO.melhorEmbarque(perto, longe), true);
  assert.equal(CUSTO.melhorEmbarque(longe, perto), false);
});

test('com a mesma caminhada, ganha a paragem onde se apanha mais tarde', () => {
  assert.equal(CUSTO.melhorEmbarque({ m: 200, dep: 520 }, { m: 200, dep: 500 }), true);
  assert.equal(CUSTO.melhorEmbarque({ m: 200, dep: 500 }, { m: 200, dep: 520 }), false);
});

test('o primeiro candidato é sempre aceite', () => {
  assert.equal(CUSTO.melhorEmbarque({ m: 999, dep: 0 }, null), true);
});

// ---------------------------------------------------------------- filtros
const ride = (short, from, to) => ({ type: 'ride', route: { short }, from, to });
const walk = (dur) => ({ type: 'walk', dur });
const it = (legs, extra = {}) => ({ legs, last: { type: 'walk', dur: 0 }, arrive: 100, ...extra });

test('apanhar a mesma linha duas vezes seguidas é descartado', () => {
  assert.equal(CUSTO.saiEVoltaAEntrar(it([ride('205', 1, 2), ride('205', 2, 3)])), true);
  assert.equal(CUSTO.saiEVoltaAEntrar(it([ride('205', 1, 2), ride('300', 2, 3)])), false);
  assert.equal(CUSTO.saiEVoltaAEntrar(it([])), false);
});

test('minutosAPeTotal soma os troços a pé e o último troço', () => {
  const x = it([walk(5), ride('205', 1, 2), walk(3)]);
  x.last = { type: 'walk', dur: 7 };
  assert.equal(CUSTO.minutosAPeTotal(x), 15);
  const y = it([walk(5)]);
  y.last = { type: 'uncovered', dur: 20 };
  assert.equal(CUSTO.minutosAPeTotal(y), 5, 'o troço de carro não conta como caminhada');
});

test('a chave da viagem junta as mesmas linhas à mesma hora', () => {
  const a = it([ride('205', 1, 9)], { arrive: 800 });
  const b = it([ride('205', 4, 9)], { arrive: 800 });
  const c = it([ride('205', 1, 9)], { arrive: 815 });
  assert.equal(CUSTO.chaveDaViagem(a), CUSTO.chaveDaViagem(b));
  assert.notEqual(CUSTO.chaveDaViagem(a), CUSTO.chaveDaViagem(c));
  assert.equal(CUSTO.chaveDaViagem(it([], { walkOnly: true })), 'walk');
});

test('a assinatura distingue onde se apanha e onde se sai', () => {
  assert.notEqual(CUSTO.assinatura(it([ride('205', 1, 9)])), CUSTO.assinatura(it([ride('205', 4, 9)])));
  assert.equal(CUSTO.assinatura(it([])), '');
});

// ---------------------------------------------------------------- percursos incompletos
test('só aproxima do destino quem encurta mesmo a distância', () => {
  assert.equal(CUSTO.aproximaDoDestino(500, 10000), true);
  assert.equal(CUSTO.aproximaDoDestino(9000, 10000), false);
});

test('o custo de um percurso incompleto sobe com o que falta e com os transbordos', () => {
  const base = CUSTO.custoIncompleto(600, 1000, 1);
  assert.ok(CUSTO.custoIncompleto(600, 5000, 1) > base, 'faltar mais caminho tem de custar mais');
  assert.ok(CUSTO.custoIncompleto(600, 1000, 3) > base, 'mais transbordos tem de custar mais');
});

// ---------------------------------------------------------------- hora de sair
test('a hora de sair desconta a caminhada inicial, e só essa', () => {
  assert.equal(horaDeSair({ depart: 500, legs: [walk(8), ride('205', 1, 2)] }), 492);
  assert.equal(horaDeSair({ depart: 500, legs: [ride('205', 1, 2), walk(8)] }), 500);
  assert.equal(horaDeSair({ depart: 500, legs: [] }), 500);
});

test('porta a porta conta a caminhada inicial', () => {
  const x = { depart: 500, arrive: 530, legs: [walk(10), ride('205', 1, 2)] };
  assert.equal(CUSTO.portaAPorta(x), 40);
});

// ---------------------------------------------------------------- ordem
const op = (o) => ({ complete: true, transfers: 0, legs: [], depart: 0, arrive: 0, ...o });

test('por hora de partida: primeiro quem chega mais cedo', () => {
  const lista = [op({ arrive: 900 }), op({ arrive: 830 }), op({ arrive: 860 })];
  assert.deepEqual(lista.sort(CUSTO.ordenar).map((x) => x.arrive), [830, 860, 900]);
});

test('percursos incompletos vão sempre para o fim', () => {
  const lista = [op({ arrive: 800, complete: false }), op({ arrive: 900 })];
  assert.deepEqual(lista.sort(CUSTO.ordenar).map((x) => x.complete), [true, false]);
});

test('com a mesma chegada, menos transbordos primeiro', () => {
  const lista = [op({ arrive: 900, transfers: 2 }), op({ arrive: 900, transfers: 0 })];
  assert.deepEqual(lista.sort(CUSTO.ordenar).map((x) => x.transfers), [0, 2]);
});

test('em "chegar até": primeiro quem deixa sair mais tarde', () => {
  const lista = [
    op({ depart: 800, arrive: 900, legs: [walk(10)] }),   // sai às 790
    op({ depart: 850, arrive: 900, legs: [walk(5)] }),    // sai às 845
  ];
  assert.deepEqual(lista.sort(CUSTO.ordenarChegarAte).map(horaDeSair), [845, 790]);
});

// ---------------------------------------------------------------- coerência
test('os raios do modelo de custo são coerentes entre si', () => {
  const r = CUSTO.raio;
  assert.ok(r.transbordo < r.acesso && r.acesso <= r.destino);
  assert.ok(r.acessoMax > r.acesso && r.acessoPasso > 0 && r.acessoMinParagens >= 1);
});
