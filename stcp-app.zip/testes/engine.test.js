import test from 'node:test';
import assert from 'node:assert/strict';
import { Network, dist, walkMin, norm, decodePoly, ANDANTE } from '../site/js/engine.js';
import { A_PE, PERCURSO } from '../site/js/rules.js';
import { redeCrua, datas, acharParagem, destinoEm } from './ajuda.js';

const N = new Network(redeCrua());
const DIA = datas().primeira;
const p = (nome) => acharParagem(N, nome, norm);
const MANHA = 9 * 60;

const planear = (origem, destino, extra = {}) =>
  N.plan({ origin: origem, dest: destinoEm(N, destino), date: DIA, time: MANHA, ...extra });

// ---------------------------------------------------------------- utilitários
test('dist mede em metros e é simétrica', () => {
  const d = dist(41.1496, -8.6109, 41.1796, -8.6109);   // 0,03° de latitude
  assert.ok(Math.abs(d - 3336) < 20, 'deu ' + d);
  assert.equal(Math.round(d), Math.round(dist(41.1796, -8.6109, 41.1496, -8.6109)));
  assert.equal(dist(41, -8, 41, -8), 0);
});

test('walkMin aplica o desvio das ruas e tem mínimo de um minuto', () => {
  assert.equal(walkMin(0), A_PE.minimo_min);
  assert.equal(walkMin(10), A_PE.minimo_min, 'dez metros ainda contam como um minuto');
  const esperado = Math.round((1000 * A_PE.desvio) / A_PE.velocidade_ms / 60);
  assert.equal(walkMin(1000), esperado);
});

test('norm ignora acentos, maiúsculas e espaços a mais', () => {
  assert.equal(norm('  Câmara   de   Gaia '), 'camara de gaia');
  assert.equal(norm('SÃO BENTO'), 'sao bento');
  assert.equal(norm(null), '');
  assert.equal(norm(undefined), '');
});

test('decodePoly devolve as coordenadas que foram codificadas', () => {
  // exemplo da documentação do formato da Google
  const pts = decodePoly('_p~iF~ps|U_ulLnnqC_mqNvxq`@');
  assert.equal(pts.length, 3);
  assert.ok(Math.abs(pts[0][0] - 38.5) < 1e-5);
  assert.ok(Math.abs(pts[0][1] + 120.2) < 1e-5);
  assert.deepEqual(decodePoly(''), []);
});

// ---------------------------------------------------------------- rede
test('a rede de exemplo carrega com o que os testes precisam', () => {
  assert.ok(N.n > 50);
  assert.ok(N.hasService(DIA));
  assert.equal(N.hasService('1999-01-01'), false);
});

test('procurar paragens por nome e por código', () => {
  const i = p('trindade');
  assert.ok(N.search('trindade', 5).includes(i));
  const codigo = N.stopCode[p('coriscos')];
  if (codigo) assert.ok(N.search(codigo, 5).length > 0);
  assert.deepEqual(N.search('', 5), []);
  assert.deepEqual(N.search('xpto que nao existe', 5), []);
});

test('as paragens mais perto vêm por ordem de distância', () => {
  const i = p('trindade');
  const perto = N.nearest(N.lat[i], N.lon[i], 4);
  assert.equal(perto.length, 4);
  assert.equal(perto[0].i, i);
  for (let k = 1; k < perto.length; k++) assert.ok(perto[k].m >= perto[k - 1].m);
});

test('linesAt diz que linhas passam na paragem', () => {
  const linhas = N.linesAt(p('trindade')).map((r) => r.short);
  assert.ok(linhas.length > 0);
  assert.ok(linhas.includes('E') || linhas.includes('D'));
});

// ---------------------------------------------------------------- percursos
test('percurso direto de metro', () => {
  const its = planear(p('trindade'), p('aeroporto'));
  assert.ok(its.length > 0);
  const melhor = its[0];
  assert.equal(melhor.complete, true);
  assert.ok(melhor.arrive > melhor.depart);
  assert.equal(melhor.legs.filter((l) => l.type === 'ride').length, 1);
});

test('percurso com transbordo', () => {
  const its = planear(p('aeroporto'), p('hospital sao joao'));
  assert.ok(its.length > 0);
  assert.ok(its[0].transfers >= 1, 'do Aeroporto ao Hospital São João muda-se de linha na Trindade');
});

test('nenhuma opção tem dois troços a pé seguidos', () => {
  const pares = [['trindade', 'aeroporto'], ['coriscos', 'codiceira'], ['aeroporto', 'hospital sao joao']];
  for (const [a, b] of pares) {
    for (const it of planear(p(a), p(b))) {
      for (let i = 1; i < it.legs.length; i++) {
        assert.ok(!(it.legs[i - 1].type === 'walk' && it.legs[i].type === 'walk'),
          `${a} -> ${b} tem dois troços a pé seguidos`);
      }
    }
  }
});

test('quando o percurso acaba a pé, não passa por uma paragem sem uso', () => {
  const b = p('aeroporto');
  // destino ao lado da paragem, para forçar o último troço a pé
  const its = N.plan({
    origin: p('trindade'),
    dest: { lat: N.lat[b] + 0.002, lon: N.lon[b] + 0.002 },
    date: DIA, time: MANHA,
  });
  for (const it of its) {
    const ultimo = it.legs[it.legs.length - 1];
    assert.ok(!(ultimo && ultimo.type === 'walk' && !ultimo.access),
      'o troço final a pé devia partir de onde se sai do transporte');
  }
});

test('nenhuma opção apanha a mesma linha duas vezes seguidas', () => {
  for (const it of planear(p('coriscos'), p('codiceira'))) {
    const linhas = it.legs.filter((l) => l.type === 'ride').map((l) => l.route.short);
    for (let i = 1; i < linhas.length; i++) assert.notEqual(linhas[i], linhas[i - 1]);
  }
});

test('partir de uma morada (sem paragem) usa as paragens a pé', () => {
  const i = p('trindade');
  const its = N.plan({
    origin: { lat: N.lat[i] + 0.001, lon: N.lon[i] + 0.001 },
    dest: destinoEm(N, p('aeroporto')), date: DIA, time: MANHA,
  });
  assert.ok(its.length > 0);
  assert.equal(its[0].legs[0].type, 'walk');
  assert.equal(its[0].legs[0].access, true);
});

test('origem e destino muito perto dão a opção de ir a pé', () => {
  const i = p('trindade');
  const its = N.plan({
    origin: i, dest: { lat: N.lat[i] + 0.001, lon: N.lon[i] + 0.001 }, date: DIA, time: MANHA,
  });
  assert.ok(its.some((x) => x.walkOnly));
});

test('sem serviço nessa data, não há opções', () => {
  const its = N.plan({ origin: p('trindade'), dest: destinoEm(N, p('aeroporto')), date: '1999-01-01', time: MANHA });
  assert.deepEqual(its, []);
});

test('o número de opções respeita o limite das regras', () => {
  const its = planear(p('trindade'), p('aeroporto'));
  assert.ok(its.length <= PERCURSO.opcoes_max);
});

// ---------------------------------------------------------------- horas
test('as opções estão ordenadas por chegada', () => {
  const its = planear(p('trindade'), p('aeroporto')).filter((x) => x.complete);
  for (let i = 1; i < its.length; i++) assert.ok(its[i].arrive >= its[i - 1].arrive);
});

test('nenhuma partida é anterior à hora pedida', () => {
  for (const it of planear(p('trindade'), p('aeroporto'))) {
    if (it.walkOnly) continue;
    assert.ok(it.depart >= MANHA, 'partida às ' + it.depart + ', pedido às ' + MANHA);
  }
});

test('leaveAt desconta a caminhada inicial', () => {
  const i = p('trindade');
  const its = N.plan({
    origin: { lat: N.lat[i] + 0.001, lon: N.lon[i] + 0.001 },
    dest: destinoEm(N, p('aeroporto')), date: DIA, time: MANHA,
  });
  const it = its[0];
  assert.equal(Network.leaveAt(it), it.depart - it.legs[0].dur);
});

test('partidas seguintes e anteriores da mesma linha', () => {
  const it = planear(p('trindade'), p('aeroporto'))[0];
  const leg = it.legs.find((l) => l.type === 'ride');
  const seguintes = N.nextDepartures(leg, DIA, leg.dep, 3);
  assert.ok(seguintes.length > 0);
  for (const x of seguintes) assert.ok(x >= leg.dep);
  for (let i = 1; i < seguintes.length; i++) assert.ok(seguintes[i] > seguintes[i - 1]);

  const anteriores = N.prevDepartures(leg, DIA, leg.dep, 2);
  for (const x of anteriores) assert.ok(x < leg.dep);
  assert.ok(anteriores.length <= 2);
});

// ---------------------------------------------------------------- chegar até
test('chegar até: chega a horas e não se pode sair mais tarde', () => {
  const limite = 11 * 60;
  const its = planear(p('trindade'), p('aeroporto'), { arriveBy: limite });
  assert.ok(its.length > 0);
  for (const it of its) assert.ok(it.arrive <= limite, 'chega às ' + it.arrive);
  // a primeira é a que permite sair mais tarde
  for (let i = 1; i < its.length; i++) {
    assert.ok(Network.leaveAt(its[0]) >= Network.leaveAt(its[i]));
  }
});

test('chegar até: sair mais tarde do que a melhor opção faz falhar a hora', () => {
  const limite = 11 * 60;
  const melhor = planear(p('trindade'), p('aeroporto'), { arriveBy: limite })[0];
  const depois = N.plan({
    origin: p('trindade'), dest: destinoEm(N, p('aeroporto')),
    date: DIA, time: Network.leaveAt(melhor) + 1,
  });
  assert.ok(depois.every((x) => x.arrive > limite || !x.complete),
    'se houvesse uma partida mais tarde que chegasse a horas, a pesquisa binária estava errada');
});

test('chegar até uma hora impossível não devolve nada', () => {
  const its = planear(p('trindade'), p('aeroporto'), { arriveBy: 1 });
  assert.deepEqual(its, []);
});

// ---------------------------------------------------------------- zonas e preços
test('o título Andante sai da tabela de preços', () => {
  const it = planear(p('trindade'), p('aeroporto'))[0];
  assert.ok(it.fare.z in ANDANTE);
  assert.equal(it.fare.preco, ANDANTE[it.fare.z].preco);
  assert.equal(it.fare.dur, ANDANTE[it.fare.z].dur);
});

test('as zonas atravessadas incluem a da origem e a do destino', () => {
  const it = planear(p('trindade'), p('aeroporto'))[0];
  const rides = it.legs.filter((l) => l.type === 'ride');
  assert.ok(it.fare.zones.includes(N.zone[rides[0].from]));
  assert.ok(it.fare.zones.includes(N.zone[rides[rides.length - 1].to]));
  assert.equal(it.fare.origin, N.zone[rides[0].from]);
});

test('o título nunca é inferior a Z2', () => {
  const i = p('trindade'), j = p('bolhao');
  const its = N.plan({ origin: i, dest: destinoEm(N, j), date: DIA, time: MANHA });
  for (const it of its) if (it.fare && it.fare.z) assert.ok(+it.fare.z.slice(1) >= 2);
});

test('percursos só de metro usam a tabela oficial do Metro', () => {
  const it = planear(p('trindade'), p('aeroporto'))[0];
  assert.equal(it.fare.fonte, 'metro');
});

test('zoneDistances conta anéis a partir da zona de origem', () => {
  const d = N.zoneDistances('PRT1');
  assert.equal(d.PRT1, 0);
  for (const v of Object.values(d)) assert.ok(Number.isInteger(v) && v >= 0);
});

test('ir só a pé não tem título nenhum', () => {
  const i = p('trindade');
  const its = N.plan({ origin: i, dest: { lat: N.lat[i] + 0.001, lon: N.lon[i] + 0.001 }, date: DIA, time: MANHA });
  const aPe = its.find((x) => x.walkOnly);
  assert.equal(aPe.fare, null);
});

// ---------------------------------------------------------------- casos menos comuns
test('routeAt diz que tipo de transporte serve a paragem', () => {
  const metro = N.routeAt(p('trindade'));
  assert.equal(metro.type, 1, 'a Trindade é metro');
  const bus = N.routeAt(p('coriscos'));
  assert.ok(bus && bus.type !== 1, 'Coriscos é autocarro');
});

test('longe da rede, o raio de procura vai crescendo', () => {
  const i = p('aeroporto');
  // 6 km a norte do aeroporto: já não há paragens no raio inicial
  const perto = N.accessStops(N.lat[i] + 0.055, N.lon[i]);
  assert.ok(Array.isArray(perto));
  for (const x of perto) assert.ok(x.w >= A_PE.minimo_min);
});

test('destino fora do alcance devolve o troço que falta, marcado', () => {
  const a = p('aeroporto');
  // 2 km para lá do aeroporto: o metro aproxima, mas não chega
  const its = N.plan({
    origin: p('trindade'), dest: { lat: N.lat[a] + 0.02, lon: N.lon[a] }, date: DIA, time: MANHA,
  });
  assert.ok(its.length > 0, 'devia mostrar até onde o transporte leva');
  assert.ok(its.every((x) => !x.complete), 'nenhuma opção devia estar completa');
  assert.equal(its[0].last.type, 'uncovered');
  assert.ok(its[0].last.m > 1000);
  assert.ok(its[0].last.dur > 0, 'o troço em falta traz uma estimativa de tempo');
  assert.ok(its.length <= 3, 'não vale a pena mostrar muitas opções incompletas');
});

test('num destino inalcançável não se inventa nada', () => {
  // no meio do Atlântico: nenhuma paragem aproxima o suficiente
  const its = N.plan({ origin: p('trindade'), dest: { lat: 41.15, lon: -9.9 }, date: DIA, time: MANHA });
  assert.deepEqual(its, []);
});

test('scheduledSecsAt devolve horários ao segundo, e vazio para linha errada', () => {
  const it = planear(p('trindade'), p('aeroporto'))[0];
  const leg = it.legs.find((l) => l.type === 'ride');
  const segs = N.scheduledSecsAt(leg.from, leg.route.short, DIA);
  assert.ok(segs.length > 0);
  for (const s of segs) assert.ok(Number.isInteger(s) && s >= 0);
  assert.deepEqual(N.scheduledSecsAt(leg.from, 'LINHA-QUE-NAO-EXISTE', DIA), []);
});

test('scheduledSecsAt não distingue maiúsculas de minúsculas', () => {
  const it = planear(p('trindade'), p('aeroporto'))[0];
  const leg = it.legs.find((l) => l.type === 'ride');
  assert.deepEqual(
    N.scheduledSecsAt(leg.from, leg.route.short.toLowerCase(), DIA),
    N.scheduledSecsAt(leg.from, leg.route.short.toUpperCase(), DIA));
});

test('tripTime e tripSec concordam entre si', () => {
  const it = planear(p('trindade'), p('aeroporto'))[0];
  const leg = it.legs.find((l) => l.type === 'ride');
  const min = N.tripTime(leg.pi, leg.trip, leg.shift, leg.boardPos);
  const seg = N.tripSec(leg.pi, leg.trip, leg.shift, leg.boardPos);
  assert.equal(min, Math.floor(seg / 60));
});

// ---------------------------------------------------------------- partidas já passadas
test('chegar até: não sugere partidas que já passaram', () => {
  const limite = 12 * 60;
  const todas = planear(p('coriscos'), p('codiceira'), { arriveBy: limite });
  assert.ok(todas.length > 0, 'o caso de teste precisa de pelo menos uma opção');
  const maisCedo = Math.min(...todas.map((it) => Network.leaveAt(it)));

  // passa a ser "agora" um instante depois da partida mais cedo
  const agora = maisCedo + 1;
  const its = planear(p('coriscos'), p('codiceira'), { arriveBy: limite, notBefore: agora });
  assert.ok(!its.some((it) => Network.leaveAt(it) === maisCedo),
    'a partida que já passou devia ter desaparecido');
  for (const it of its) {
    assert.ok(Network.leaveAt(it) >= agora,
      'sugeriu sair às ' + Network.leaveAt(it) + ', que já passou (agora ' + agora + ')');
    assert.ok(it.arrive <= limite);
  }
});

test('chegar até: se a hora pedida já passou, não há nada a fazer', () => {
  const its = planear(p('trindade'), p('aeroporto'), { arriveBy: 10 * 60, notBefore: 11 * 60 });
  assert.deepEqual(its, []);
});

test('chegar até: sem notBefore, nada muda (pesquisa para outro dia)', () => {
  const limite = 12 * 60;
  const a = planear(p('coriscos'), p('codiceira'), { arriveBy: limite });
  const b = planear(p('coriscos'), p('codiceira'), { arriveBy: limite, notBefore: null });
  assert.deepEqual(a.map((x) => Network.leaveAt(x)), b.map((x) => Network.leaveAt(x)));
});

test('chegar até: a opção a pé também não sai antes de agora', () => {
  const i = p('trindade');
  const limite = 12 * 60;
  const agora = limite - 2;   // só faltam dois minutos
  const its = N.plan({
    origin: i, dest: { lat: N.lat[i] + 0.001, lon: N.lon[i] + 0.001 },
    date: DIA, time: limite, arriveBy: limite, notBefore: agora,
  });
  for (const it of its) assert.ok(Network.leaveAt(it) >= agora);
});

// ---------------------------------------------------------------- onde se apanha o transporte
test('apanha o transporte na paragem mais perto, não na primeira da linha', () => {
  const pat = N.patterns.find((x) => N.routes[x.r].short === '701');
  const meio = pat.s[5];                       // uma paragem a meio do percurso
  const antes = pat.s.slice(0, 5);             // paragens anteriores da mesma linha
  const origem = { lat: N.lat[meio] + 0.0004, lon: N.lon[meio] + 0.0004 };

  // há paragens anteriores ao alcance, para a escolha ser mesmo uma escolha
  const aoAlcance = antes.filter((s) => dist(origem.lat, origem.lon, N.lat[s], N.lon[s]) <= A_PE.ate_a_paragem_m);
  assert.ok(aoAlcance.length > 0, 'o caso de teste precisa de paragens anteriores ao alcance');

  const its = N.plan({ origin: origem, dest: destinoEm(N, pat.s[pat.s.length - 1]), date: DIA, time: MANHA });
  assert.ok(its.length > 0);
  for (const it of its) {
    const ride = it.legs.find((l) => l.type === 'ride');
    if (!ride || N.routes[N.patterns[ride.pi].r].short !== '701') continue;
    const daOrigem = dist(origem.lat, origem.lon, N.lat[ride.from], N.lon[ride.from]);
    for (const s of antes) {
      assert.ok(dist(origem.lat, origem.lon, N.lat[s], N.lon[s]) >= daOrigem - 1,
        `apanhou em ${N.stopName[ride.from]}, mas ${N.stopName[s]} era mais perto`);
    }
  }
});

test('afinar o embarque não atrasa a chegada nem faz perder a viagem', () => {
  const pat = N.patterns.find((x) => N.routes[x.r].short === '701');
  const meio = pat.s[5];
  const origem = { lat: N.lat[meio] + 0.0004, lon: N.lon[meio] + 0.0004 };
  const its = N.plan({ origin: origem, dest: destinoEm(N, pat.s[pat.s.length - 1]), date: DIA, time: MANHA });
  for (const it of its) {
    const aPeAntes = it.legs[0].type === 'walk' ? it.legs[0].dur : 0;
    const ride = it.legs.find((l) => l.type === 'ride');
    if (!ride) continue;
    assert.ok(MANHA + aPeAntes <= ride.dep, 'não dá tempo de chegar à paragem');
    assert.equal(ride.from, ride.stops[0], 'a lista de paragens tem de começar onde se entra');
    assert.equal(ride.to, ride.stops[ride.stops.length - 1], 'e acabar onde se sai');
    assert.ok(it.arrive >= ride.arr, 'a chegada não pode ser anterior à saída do transporte');
  }
});

test('em "chegar até", ir a pé sai à hora certa para chegar mesmo a horas', () => {
  // duas paragens perto uma da outra: ir a pé é uma das opções
  let a = -1, b = -1;
  for (let i = 0; i < N.n && a < 0; i++) {
    if (!N.used[i]) continue;
    for (const j of N.near(N.lat[i], N.lon[i], 600)) {
      if (j !== i && N.used[j]) { a = i; b = j; break; }
    }
  }
  assert.ok(a >= 0, 'a rede de exemplo devia ter duas paragens perto uma da outra');

  const chegarAs = 10 * 60;
  const its = N.plan({ origin: a, dest: destinoEm(N, b), date: DIA, time: 8 * 60,
    arriveBy: chegarAs, notBefore: 8 * 60 });
  const aPe = its.find((it) => it.walkOnly);
  assert.ok(aPe, 'devia haver a opção de ir a pé');
  assert.equal(aPe.arrive, chegarAs, 'a pé chega-se à hora pedida, não antes');
  assert.equal(aPe.depart, chegarAs - aPe.last.dur);
  for (const it of its) {
    assert.ok(it.arrive <= chegarAs, 'nenhuma opção pode chegar depois da hora pedida');
  }
});

test('em "chegar até", não se propõe sair antes da hora atual nem para ir a pé', () => {
  let a = -1, b = -1;
  for (let i = 0; i < N.n && a < 0; i++) {
    if (!N.used[i]) continue;
    for (const j of N.near(N.lat[i], N.lon[i], 600)) {
      if (j !== i && N.used[j]) { a = i; b = j; break; }
    }
  }
  const chegarAs = 10 * 60, agora = chegarAs - 2;   // falta menos tempo do que a caminhada
  const its = N.plan({ origin: a, dest: destinoEm(N, b), date: DIA, time: agora,
    arriveBy: chegarAs, notBefore: agora });
  for (const it of its) {
    assert.ok(Network.leaveAt(it) >= agora, 'sugeriu sair às ' + Network.leaveAt(it) + ', que já passou');
  }
});

test('não sobra caminhada de uma paragem para ela própria', () => {
  // o afinarEmbarque pode recuar o embarque até à paragem onde já se está.
  // Quando isso acontece, a caminhada que lá ia dar deixa de existir, e não
  // pode ficar no percurso como "a pé até X, 1 min, 0 m" a partir de X.
  const usadas = [];
  for (let i = 0; i < N.n; i++) if (N.used[i]) usadas.push(i);
  const maus = [];
  let total = 0;
  for (const o of usadas) {
    for (const d of usadas) {
      if (o === d) continue;
      for (const it of planear(o, d)) {
        for (const l of it.legs) {
          if (l.type !== 'walk') continue;
          total++;
          if (l.from === l.to) maus.push(`${N.stopName[o]} -> ${N.stopName[d]}: ${N.stopName[l.from]}`);
        }
      }
    }
  }
  assert.ok(total > 0, 'a rede de exemplo devia ter troços a pé');
  assert.deepEqual(maus.slice(0, 3), [], `${maus.length} de ${total} troços a pé começam e acabam na mesma paragem`);
});

test('nenhum troço a pé fica com distância negativa ou tempo zero', () => {
  const usadas = [];
  for (let i = 0; i < N.n; i++) if (N.used[i]) usadas.push(i);
  for (const o of usadas.slice(0, 20)) {
    for (const d of usadas.slice(0, 20)) {
      if (o === d) continue;
      for (const it of planear(o, d)) {
        for (const l of it.legs) {
          if (l.type !== 'walk') continue;
          assert.ok(l.m >= 0, 'distância negativa a pé');
          assert.ok(l.dur >= A_PE.minimo_min, 'troço a pé com menos do que o mínimo');
        }
      }
    }
  }
});
