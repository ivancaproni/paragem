/**
 * As regras são o sítio onde se mexe sem perceber o resto do código.
 * Estes testes evitam que uma mudança distraída deixe o app incoerente.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { A_PE, PERCURSO, ANDANTE, TEMPO_REAL, INTERFACE, AVISOS, AVISOS_GRAVES, MOSTRAR_SENSACAO_DIF }
  from '../site/js/rules.js';

test('os valores a pé fazem sentido físico', () => {
  assert.ok(A_PE.velocidade_ms > 0.8 && A_PE.velocidade_ms < 2, 'velocidade a pé irrealista');
  assert.ok(A_PE.desvio >= 1, 'a distância pela rua nunca é menor do que a linha reta');
  assert.ok(A_PE.transbordo_m < A_PE.ate_a_paragem_m, 'aceitar mais a pé no transbordo do que no início é estranho');
  assert.ok(A_PE.ate_a_paragem_m <= A_PE.ate_ao_destino_m);
});

test('os limites de percurso são inteiros positivos', () => {
  for (const [k, v] of Object.entries(PERCURSO)) {
    assert.ok(Number.isFinite(v) && v > 0, `PERCURSO.${k} devia ser um número positivo`);
  }
  assert.ok(PERCURSO.chegar_ate_recuo_min >= 60, 'procurar menos de uma hora para trás deixaria de fora percursos longos');
});

test('o tarifário está completo e sobe com a zona', () => {
  const zonas = Object.keys(ANDANTE);
  assert.deepEqual(zonas, ['Z2', 'Z3', 'Z4', 'Z5', 'Z6', 'Z7', 'Z8', 'Z9']);
  for (let i = 1; i < zonas.length; i++) {
    const a = ANDANTE[zonas[i - 1]], b = ANDANTE[zonas[i]];
    assert.ok(b.preco > a.preco, `${zonas[i]} devia custar mais do que ${zonas[i - 1]}`);
    assert.ok(b.dur >= a.dur, `${zonas[i]} devia valer pelo menos tanto tempo como ${zonas[i - 1]}`);
  }
});

test('os limiares do tempo real são coerentes entre si', () => {
  assert.ok(TEMPO_REAL.tolerancia_min < TEMPO_REAL.vizinhas_recuo_min,
    'olhar menos horários à volta do que a tolerância deixaria passar trocas de autocarro');
  assert.ok(TEMPO_REAL.horizonte_min > TEMPO_REAL.tolerancia_min);
  assert.ok(TEMPO_REAL.previsao_seg > 0 && TEMPO_REAL.previsao_seg < 120,
    'a margem para distinguir previsão de tempo real tem de ser pequena');
  assert.ok(TEMPO_REAL.cache_seg > 0 && TEMPO_REAL.cache_seg <= 60,
    'cache longa de mais faz o tempo real parecer parado');
});

test('os valores da interface são plausíveis', () => {
  assert.ok(INTERFACE.recentes >= 1 && INTERFACE.recentes <= 10);
  assert.ok(INTERFACE.letras_min_morada >= 2, 'procurar moradas com uma letra enche o geocodificador');
  assert.ok(INTERFACE.gps_espera_ms <= INTERFACE.gps_espera_fundo_ms,
    'o botão atualizar não deve esperar mais do que a leitura em segundo plano');
});

test('cada aviso tem id único, ícone e texto', () => {
  const ids = new Set();
  for (const r of AVISOS) {
    assert.ok(r.id && !ids.has(r.id), 'id repetido ou em falta: ' + r.id);
    ids.add(r.id);
    assert.ok(r.icone, r.id + ' sem ícone');
    assert.ok(r.texto && r.texto.length < 30, r.id + ' com texto em falta ou comprido de mais para o crachá');
    assert.equal(typeof r.teste, 'function');
  }
});

test('os avisos graves existem mesmo na lista de avisos', () => {
  const ids = new Set(AVISOS.map((r) => r.id));
  for (const g of AVISOS_GRAVES) assert.ok(ids.has(g), 'aviso grave desconhecido: ' + g);
});

test('nenhum aviso rebenta com condições em falta', () => {
  const vazio = { temp: null, feels: null, rain: 0, prob: null, snow: 0, wind: 0, gust: 0, uv: 0, code: undefined };
  for (const r of AVISOS) {
    assert.doesNotThrow(() => r.teste(vazio), r.id + ' rebenta sem dados');
    assert.equal(r.teste(vazio), false, r.id + ' dispara sem dados nenhuns');
  }
});

test('a diferença para mostrar a sensação térmica é positiva', () => {
  assert.ok(MOSTRAR_SENSACAO_DIF > 0);
});
