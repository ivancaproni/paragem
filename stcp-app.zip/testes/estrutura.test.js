/**
 * Guardas de estrutura.
 *
 * O service worker tem a lista dos ficheiros do app escrita à mão: se ficar um
 * módulo de fora, o app deixa de abrir sem rede e ninguém dá por isso até
 * alguém entrar no metro. Estes testes tratam disso e do contrato do motor.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import * as E from '../site/js/engine.js';

const JS = '../site/js/';
const dir = new URL(JS, import.meta.url).pathname;

test('o service worker lista todos os módulos do app', () => {
  const sw = readFileSync(new URL('../site/sw.js', import.meta.url), 'utf8');
  const shell = sw.slice(sw.indexOf('const SHELL'), sw.indexOf('];', sw.indexOf('const SHELL')));
  const emFalta = readdirSync(dir).filter((f) => f.endsWith('.js') && !shell.includes("'js/" + f + "'"));
  assert.deepEqual(emFalta, [], 'módulos fora do SHELL do sw.js (o app não abriria offline)');
});

test('a versão do service worker muda quando o SHELL muda', () => {
  const sw = readFileSync(new URL('../site/sw.js', import.meta.url), 'utf8');
  assert.match(sw, /const VERSION = 'v\d+';/, 'sem versão não há limpeza da cache antiga');
});

test('o motor continua a exportar o que o ecrã usa', () => {
  for (const nome of ['Network', 'dist', 'walkMin', 'norm', 'decodePoly', 'ANDANTE', 'EGRESS_RADIUS']) {
    assert.ok(nome in E, 'engine.js deixou de exportar ' + nome);
  }
  assert.equal(typeof E.Network.leaveAt, 'function');
  assert.equal(typeof E.Network.addDays, 'function');
});

test('as camadas do motor não se importam ao contrário', () => {
  // geo não conhece ninguém; custo só conhece as regras; timetable não conhece
  // o algoritmo. Assim cada camada pode ser lida e testada sozinha.
  const importa = (f) => [...readFileSync(dir + f, 'utf8').matchAll(/from '\.\/([\w-]+)\.js'/g)].map((m) => m[1]);
  assert.deepEqual(importa('geo.js'), []);
  assert.deepEqual(importa('custo.js'), ['rules']);
  assert.deepEqual(importa('tarifario.js'), ['rules']);
  for (const proibido of ['raptor', 'itinerario', 'engine']) {
    assert.ok(!importa('timetable.js').includes(proibido), 'timetable.js não deve depender de ' + proibido);
    assert.ok(!importa('custo.js').includes(proibido), 'custo.js não deve depender de ' + proibido);
  }
  assert.ok(!importa('raptor.js').includes('engine'), 'o algoritmo não deve depender da fachada');
});
