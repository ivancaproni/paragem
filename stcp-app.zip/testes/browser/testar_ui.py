"""
Testes do ecrã, no browser a sério.

Os testes em `testes/*.test.js` cobrem o que é lógica pura. Estes cobrem o que só
existe com ecrã: campos, lista de resultados, detalhe, mapa, GPS e definições.

Correr:
    pip install playwright && playwright install chromium
    python3 testes/browser/testar_ui.py

Sai com código 0 se passar tudo. Não precisa de internet: todos os pedidos de fora
(mapas, moradas, meteorologia, tempo real) são respondidos aqui.
"""
import asyncio
import datetime
import http.server
import json
import os
import socketserver
import sys
import threading

RAIZ = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SITE = os.path.join(RAIZ, 'site')
FIXTURES = os.path.join(RAIZ, 'testes', 'fixtures')
PORTA = 8813

falhas = []
passou = []


def verificar(condicao, descricao):
    (passou if condicao else falhas).append(descricao)
    print(('  ok   ' if condicao else '  FALHA ') + descricao)


# ----------------------------------------------------------------- servidor local
def servir():
    """Serve o site com os dados da rede de exemplo em data/."""
    class Handler(http.server.SimpleHTTPRequestHandler):
        def translate_path(self, path):
            limpo = path.split('?', 1)[0].split('#', 1)[0].lstrip('/')
            if limpo.startswith('data/'):
                nome = limpo[len('data/'):]
                if nome == 'net.json':
                    return os.path.join(FIXTURES, 'rede.json')
                if nome == 'shapes.json':
                    return os.path.join(FIXTURES, 'shapes.json')
                return os.path.join(FIXTURES, nome)
            return os.path.join(SITE, limpo or 'index.html')

        def log_message(self, *a):
            pass

    socketserver.TCPServer.allow_reuse_address = True
    servidor = socketserver.TCPServer(('127.0.0.1', PORTA), Handler)
    threading.Thread(target=servidor.serve_forever, daemon=True).start()
    return servidor


# ----------------------------------------------------------------- respostas falsas
def calendario_da_rede():
    with open(os.path.join(FIXTURES, 'rede.json'), encoding='utf-8') as f:
        return sorted(json.load(f)['calendar'].keys())


def meteorologia(temp=18, sensacao=18, chuva=0.0, prob=5, vento=10, rajada=16, uv=2, codigo=1):
    agora = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=1)))
    base = agora.replace(minute=0, second=0, microsecond=0)
    horas = [(base + datetime.timedelta(hours=i)).strftime('%Y-%m-%dT%H:00') for i in range(-12, 48)]
    n = len(horas)
    return {
        "current": {"temperature_2m": temp, "apparent_temperature": sensacao, "precipitation": chuva,
                    "weather_code": codigo, "wind_speed_10m": vento, "wind_gusts_10m": rajada},
        "hourly": {"time": horas, "temperature_2m": [temp] * n, "apparent_temperature": [sensacao] * n,
                   "precipitation": [chuva] * n, "precipitation_probability": [prob] * n,
                   "snowfall": [0] * n, "weather_code": [codigo] * n, "wind_speed_10m": [vento] * n,
                   "wind_gusts_10m": [rajada] * n, "uv_index": [uv] * n}}


CORS = {'Access-Control-Allow-Origin': '*'}


async def preparar(ctx, tempo_real=None, wx=None, moradas=None):
    pg = await ctx.new_page()
    erros = []
    pg.on('pageerror', lambda e: erros.append('erro de página: ' + str(e)))
    await pg.route('**/tile.openstreetmap.org/**', lambda r: r.abort())
    await pg.route('**photon.komoot.io/**', lambda r: r.fulfill(
        json=moradas if moradas is not None else {"features": []}, headers=CORS))
    await pg.route('**nominatim.openstreetmap.org/**', lambda r: r.fulfill(json=[], headers=CORS))
    await pg.route('**api.open-meteo.com/**', lambda r: r.fulfill(
        json=wx if wx is not None else meteorologia(), headers=CORS))
    await pg.route('**workers.dev/**', lambda r: r.fulfill(
        json=tempo_real if tempo_real is not None else {"arrivals": []}, headers=CORS))
    return pg, erros


async def escolher(pg, campo, texto):
    await pg.fill('#in-' + campo, texto)
    await pg.wait_for_timeout(700)
    await pg.click(f'#dd-{campo} [data-stop]')


async def procurar(pg, origem='trindade', destino='aeroporto', quando=None, hora=None):
    await pg.goto(f'http://127.0.0.1:{PORTA}/')
    await pg.wait_for_timeout(1500)
    await escolher(pg, 'origin', origem)
    await escolher(pg, 'dest', destino)
    if quando:
        await pg.select_option('#sel-when', quando)
        await pg.wait_for_timeout(200)
        if hora:
            await pg.fill('#in-when', hora)
    await pg.click('#btn-search')
    await pg.wait_for_timeout(2200)
    return [' '.join((await el.inner_text()).split()) for el in await pg.locator('#res-list .opt').all()]


# ----------------------------------------------------------------- os testes
async def teste_pesquisa_basica(b):
    print('\n# pesquisa e lista de resultados')
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    cartoes = await procurar(pg)
    verificar(len(cartoes) > 0, 'mostra pelo menos uma opção')
    verificar('Andante Z' in cartoes[0], 'o cartão traz o título Andante')
    verificar('chega' in cartoes[0], 'o cartão traz a hora de chegada')
    verificar('Metro E' in cartoes[0] or 'Metro' in cartoes[0], 'o crachá do metro diz "Metro"')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_detalhe(b):
    print('\n# ecrã de detalhe')
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    await procurar(pg)
    await pg.locator('#res-list .opt').first.click()
    await pg.wait_for_timeout(1500)
    texto = ' '.join((await pg.locator('#detail-sheet').inner_text()).split())
    verificar('Zonas atravessadas' in texto, 'o detalhe explica as zonas')
    verificar('Sair em' in texto, 'a linha do tempo diz onde sair')
    verificar('tabela oficial do Metro' in texto, 'num percurso só de metro, diz que o título é o oficial')
    verificar(await pg.locator('#map').count() == 1, 'o mapa está no ecrã')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_troco_a_pe(b):
    print('\n# troço a pé até ao destino')
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    await pg.goto(f'http://127.0.0.1:{PORTA}/')
    await pg.wait_for_timeout(1500)
    await escolher(pg, 'origin', 'trindade')
    # destino ao lado de uma paragem, para obrigar a acabar a pé
    await pg.evaluate("""() => {
      const i = document.querySelector('#in-dest');
      i.value = 'ponto'; i.dispatchEvent(new Event('input', {bubbles: true}));
    }""")
    await escolher(pg, 'dest', 'botica')
    await pg.click('#btn-search')
    await pg.wait_for_timeout(2200)
    await pg.locator('#res-list .opt').first.click()
    await pg.wait_for_timeout(1400)
    texto = await pg.locator('#detail-sheet').inner_text()
    aPe = texto.count('A pé até')
    verificar(aPe <= 1, f'o percurso a pé aparece num bloco só (encontrados {aPe})')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_chegar_ate(b):
    print('\n# modo "chegar até"')
    dia = calendario_da_rede()[0]
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    cartoes = await procurar(pg, quando='by', hora=f'{dia}T18:30')
    titulo = ' '.join((await pg.locator('#res-title').inner_text()).split())
    verificar('Chegar até' in titulo, 'o cabeçalho diz que é por hora de chegada')
    verificar(len(cartoes) > 0, 'encontra opções que chegam a horas')
    verificar('sair' in cartoes[0], 'o número grande é a hora a que se deve sair')
    verificar('folga' in cartoes[0], 'o cartão diz a folga')
    verificar('seguintes' not in cartoes[0], 'não mostra partidas seguintes, que já chegariam tarde')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_chegar_ate_nao_manda_ao_passado(b):
    print('\n# "chegar até" não sugere partidas passadas')
    hoje = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=1)))
    dia = hoje.date().isoformat()
    agora = hoje.hour * 60 + hoje.minute
    if agora > 20 * 60:
        print('  (saltado: já é tarde de mais para o horário da rede de exemplo)')
        return
    limite = min(agora + 90, 23 * 60 + 59)
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    cartoes = await procurar(pg, origem='coriscos', destino='codiceira',
                             quando='by', hora=f'{dia}T{limite // 60:02d}:{limite % 60:02d}')
    horas = []
    for c in cartoes:
        import re
        m = re.search(r'(\d{2}):(\d{2}) sair', c)
        if m:
            horas.append(int(m.group(1)) * 60 + int(m.group(2)))
    verificar(all(h >= agora - 1 for h in horas),
              f'nenhuma opção manda sair antes de agora ({agora // 60:02d}:{agora % 60:02d}); deu {horas}')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_chegar_ate_impossivel(b):
    print('\n# "chegar até" a uma hora impossível')
    dia = calendario_da_rede()[0]
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    cartoes = await procurar(pg, quando='by', hora=f'{dia}T00:05')
    texto = ' '.join((await pg.locator('#res-list').inner_text()).split())
    verificar(len(cartoes) == 0, 'não inventa opções')
    verificar('Não há forma de chegar' in texto, 'explica porquê, em vez de ficar em branco')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_detalhe_concorda_com_o_cartao(b):
    """Com atraso ao vivo, o detalhe tem de mostrar as mesmas horas do cartão."""
    print('\n# detalhe e cartão com o mesmo atraso')
    import re
    hoje = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=1)))
    dia = hoje.date().isoformat()
    agora = hoje.hour * 60 + hoje.minute
    if agora > 20 * 60:
        print('  (saltado: já é tarde de mais para o horário da rede de exemplo)')
        return
    limite = min(agora + 60, 23 * 60 + 59)
    ctx = await b.new_context(viewport={'width': 390, 'height': 1000}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    cartoes = await procurar(pg, origem='coriscos', destino='codiceira',
                             quando='by', hora=f'{dia}T{limite // 60:02d}:{limite % 60:02d}')
    if not cartoes:
        print('  (saltado: sem opções a esta hora)')
        await ctx.close()
        return
    m = re.search(r'às (\d{2}):(\d{2})', cartoes[0])
    previsto = int(m.group(1)) * 60 + int(m.group(2))

    # o mesmo autocarro, seis minutos atrasado
    await pg.unroute('**workers.dev/**')
    await pg.route('**workers.dev/**', lambda r: r.fulfill(json={"arrivals": [
        {"line": "701", "destination": "Codiceira", "arrival_minutes": previsto - agora + 6,
         "data_source": "realtime"}]}, headers=CORS))
    await pg.click('#btn-refresh')
    await pg.wait_for_timeout(3000)
    cartao = ' '.join((await pg.locator('#res-list .opt').first.inner_text()).split())
    await pg.locator('#res-list .opt').first.click()
    await pg.wait_for_timeout(1600)
    detalhe = ' '.join((await pg.locator('#detail-sheet').inner_text()).split())

    chegadaCartao = re.search(r'chega ≈? ?(\d{2}:\d{2})', cartao)
    chegadaDetalhe = re.search(r'chega ≈? ?(\d{2}:\d{2})', detalhe)
    verificar(bool(chegadaCartao and chegadaDetalhe), 'ambos mostram uma hora de chegada')
    if chegadaCartao and chegadaDetalhe:
        verificar(chegadaCartao.group(1) == chegadaDetalhe.group(1),
                  f'a chegada é a mesma nos dois ({chegadaCartao.group(1)} e {chegadaDetalhe.group(1)})')
    verificar('-' not in detalhe.split('chega')[0], f'a duração no detalhe não é negativa ({detalhe[:30]})')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_tempo_real(b):
    print('\n# tempo real')
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    # a viagem seguinte da linha, atrasada: qualquer valor cai na tolerância ou vira nota
    pg, erros = await preparar(ctx, tempo_real={"arrivals": [
        {"line": "E", "destination": "Aeroporto", "arrival_minutes": 3, "data_source": "realtime"}]})
    cartoes = await procurar(pg)
    tem_marca = any(('Tempo real' in c) or ('Previsão' in c) or ('tempo real desta linha' in c) for c in cartoes)
    verificar(tem_marca, 'cada opção diz se a hora é previsão ou tempo real')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_api_tempo_real_estragada(b):
    print('\n# API de tempo real a falhar')
    for nome, rota in [
        ('erro 500', lambda r: r.fulfill(status=500, body='erro', headers=CORS)),
        ('resposta vazia', lambda r: r.fulfill(body='', headers=CORS)),
        ('json inválido', lambda r: r.fulfill(body='{isto não é json', headers=CORS)),
        ('ligação cortada', lambda r: r.abort()),
        ('formato inesperado', lambda r: r.fulfill(json={"outra_coisa": 1}, headers=CORS)),
    ]:
        ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
        pg, erros = await preparar(ctx)
        await pg.unroute('**workers.dev/**')
        await pg.route('**workers.dev/**', rota)
        cartoes = await procurar(pg)
        verificar(len(cartoes) > 0 and not erros, f'{nome}: o app continua a funcionar com o horário')
        await ctx.close()


async def teste_meteorologia_estragada(b):
    print('\n# API de meteorologia a falhar')
    for nome, rota in [
        ('erro 503', lambda r: r.fulfill(status=503, body='', headers=CORS)),
        ('json inválido', lambda r: r.fulfill(body='nada disto', headers=CORS)),
        ('ligação cortada', lambda r: r.abort()),
    ]:
        ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
        pg, erros = await preparar(ctx)
        await pg.unroute('**api.open-meteo.com/**')
        await pg.route('**api.open-meteo.com/**', rota)
        cartoes = await procurar(pg)
        escondido = await pg.locator('#wx.hidden').count() == 1
        verificar(len(cartoes) > 0 and escondido and not erros,
                  f'{nome}: a tira de meteorologia fica escondida e o resto funciona')
        await ctx.close()


async def teste_avisos_meteorologia(b):
    print('\n# avisos de meteorologia')
    casos = [
        ('chuva', meteorologia(temp=15, sensacao=15, chuva=2.0, prob=90, codigo=61), 'guarda-chuva'),
        ('calor', meteorologia(temp=31, sensacao=32, uv=9), 'leva água'),
        ('frio com vento', meteorologia(temp=8, sensacao=4, vento=35, rajada=50), 'casaco'),
        ('nada de especial', meteorologia(), None),
    ]
    for nome, wx, esperado in casos:
        ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
        pg, erros = await preparar(ctx, wx=wx)
        await procurar(pg)
        texto = ' '.join((await pg.locator('#wx').inner_text()).split())
        if esperado:
            verificar(esperado in texto, f'{nome}: mostra o aviso ({texto[:60]})')
        else:
            verificar('°' in texto, f'{nome}: mostra a temperatura e nenhum aviso ({texto[:60]})')
        verificar(not erros, f'{nome}: sem erros de JavaScript')
        await ctx.close()


async def teste_dados_em_falta(b):
    print('\n# horários que não carregam')
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    await pg.route('**/data/net.json', lambda r: r.fulfill(status=404, body='', headers=CORS))
    await pg.goto(f'http://127.0.0.1:{PORTA}/')
    await pg.wait_for_timeout(1500)
    aviso = ' '.join((await pg.locator('#data-status').inner_text()).split())
    verificar('Não foi possível carregar' in aviso, 'explica que os horários não carregaram')
    verificar(await pg.locator('#btn-search').is_disabled(), 'o botão Buscar fica desligado')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_gps(b):
    print('\n# localização atual e botão atualizar')
    ctx = await b.new_context(
        viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True,
        geolocation={'latitude': 41.1522, 'longitude': -8.6093}, permissions=['geolocation'])
    pg, erros = await preparar(ctx)
    await pg.goto(f'http://127.0.0.1:{PORTA}/')
    await pg.wait_for_timeout(1800)
    origem = await pg.input_value('#in-origin')
    verificar(origem == 'A minha localização', f'a origem começa na posição atual (deu "{origem}")')
    await escolher(pg, 'dest', 'aeroporto')
    await pg.click('#btn-search')
    await pg.wait_for_timeout(2200)
    antes = ' '.join((await pg.locator('#res-list .opt').first.inner_text()).split())
    # o utilizador andou até outra paragem
    await ctx.set_geolocation({'latitude': 41.1881, 'longitude': -8.6545})
    await pg.click('#btn-refresh')
    await pg.wait_for_timeout(3000)
    depois = ' '.join((await pg.locator('#res-list .opt').first.inner_text()).split())
    verificar(antes != depois, 'o botão atualizar lê uma posição nova do GPS')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_gps_recusado(b):
    print('\n# localização recusada')
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    await pg.goto(f'http://127.0.0.1:{PORTA}/')
    await pg.wait_for_timeout(1500)
    await pg.click('#in-origin')
    await pg.wait_for_timeout(400)
    dd = ' '.join((await pg.locator('#dd-origin').inner_text()).split())
    verificar('localização' in dd.lower() or 'Escolher no mapa' in dd,
              'sem GPS continua a dar alternativas')
    cartoes = await procurar(pg)
    verificar(len(cartoes) > 0, 'pesquisar por nome funciona sem GPS')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_escapes(b):
    print('\n# texto perigoso vindo de fora')
    maligno = "<img src=x onerror=\"window.__invadido=1\">"
    moradas = {"features": [{
        "properties": {"name": maligno, "city": "<b>Porto</b>", "street": "'; alert(1); '"},
        "geometry": {"coordinates": [-8.61, 41.15]},
    }]}
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx, moradas=moradas)
    await pg.goto(f'http://127.0.0.1:{PORTA}/')
    await pg.wait_for_timeout(1500)
    await pg.fill('#in-dest', 'uma morada qualquer')
    await pg.wait_for_timeout(1200)
    verificar(await pg.evaluate("() => !window.__invadido"), 'o HTML da morada não é executado')
    verificar(await pg.locator('#dd-dest img').count() == 0, 'nenhuma etiqueta injetada foi criada')
    texto = await pg.locator('#dd-dest').inner_text()
    verificar('onerror' in texto, 'o texto aparece tal e qual, escapado')

    # o mesmo texto como nome da paragem de origem, para chegar ao título dos resultados
    await pg.evaluate("""() => {
      const i = document.querySelector('#in-origin');
      i.value = 'trindade'; i.dispatchEvent(new Event('input', {bubbles: true}));
    }""")
    await pg.wait_for_timeout(700)
    await pg.click('#dd-origin [data-stop]')
    await pg.click('#dd-dest [data-geo]')
    await pg.click('#btn-search')
    await pg.wait_for_timeout(2200)
    verificar(await pg.evaluate("() => !window.__invadido"), 'nem depois de pesquisar')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_definicoes(b):
    print('\n# definições')
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx, tempo_real={"arrivals": [{"line": "701", "arrival_minutes": 4}]})
    await pg.goto(f'http://127.0.0.1:{PORTA}/')
    await pg.wait_for_timeout(1500)
    await pg.click('#btn-settings')
    await pg.wait_for_timeout(400)
    info = ' '.join((await pg.locator('#data-info').inner_text()).split())
    verificar(await pg.locator('#settings:not(.hidden)').count() == 1, 'as definições abrem')
    verificar(len(info) > 0, 'mostra a data e os números dos horários')
    await pg.evaluate("() => document.querySelectorAll('details').forEach(d => d.open = true)")
    await pg.wait_for_timeout(200)
    await pg.fill('#in-proxy', 'https://exemplo.workers.dev')
    await pg.click('#btn-test-proxy')
    await pg.wait_for_timeout(1500)
    saida = await pg.locator('#proxy-out').inner_text()
    verificar('OK' in saida or 'Sem resposta' in saida, f'o teste do proxy responde ({saida[:40]})')
    await pg.click('#btn-settings-close')
    await pg.wait_for_timeout(300)
    verificar(await pg.locator('#settings.hidden').count() == 1, 'as definições fecham')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_trocar_e_limpar(b):
    print('\n# trocar origem/destino e limpar')
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    await pg.goto(f'http://127.0.0.1:{PORTA}/')
    await pg.wait_for_timeout(1500)
    await escolher(pg, 'origin', 'trindade')
    await escolher(pg, 'dest', 'aeroporto')
    o1 = await pg.input_value('#in-origin')
    d1 = await pg.input_value('#in-dest')
    await pg.click('#btn-swap')
    await pg.wait_for_timeout(500)
    verificar(await pg.input_value('#in-origin') == d1 and await pg.input_value('#in-dest') == o1,
              'o botão trocar inverte os dois campos')
    await pg.click('[data-clear="origin"]')
    await pg.wait_for_timeout(300)
    verificar(await pg.input_value('#in-origin') == '', 'o botão limpar esvazia o campo')
    verificar(await pg.locator('#btn-search').is_disabled(), 'sem origem, o botão Buscar desliga')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_recentes(b):
    print('\n# recentes')
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    await pg.goto(f'http://127.0.0.1:{PORTA}/')
    await pg.wait_for_timeout(1500)
    for nome in ['trindade', 'bolhao', 'campanha', 'aeroporto']:
        await escolher(pg, 'dest', nome)
        await pg.wait_for_timeout(200)
    escolhido = await pg.input_value('#in-dest')
    verificar('M:' not in escolhido,
              f'o campo não mostra identificadores internos do metro ({escolhido})')
    await pg.click('[data-clear="dest"]')
    await pg.wait_for_timeout(500)
    dd = await pg.locator('#dd-dest').inner_text()
    verificar('Recentes' in dd, 'a lista de recentes aparece')
    verificar(await pg.locator('#dd-dest [data-stop]').count() <= 4,
              'mostra no máximo três recentes (mais o que estiver perto)')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_limpar_recentes(b):
    print('\n# limpar recentes')
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    await pg.goto(f'http://127.0.0.1:{PORTA}/')
    await pg.wait_for_timeout(1500)
    for nome in ['trindade', 'bolhao']:
        await escolher(pg, 'dest', nome)
        await pg.wait_for_timeout(200)

    # 1. cancelar não apaga nada
    pg.once('dialog', lambda d: asyncio.ensure_future(d.dismiss()))
    await pg.click('#btn-settings')
    await pg.wait_for_timeout(400)
    info = await pg.locator('#recent-info').inner_text()
    verificar('guardados' in info, f'diz quantos recentes há ({info})')
    await pg.click('#btn-clear-recent')
    await pg.wait_for_timeout(600)
    guardados = await pg.evaluate("() => JSON.parse(localStorage.getItem('recent_dest') || '[]').length")
    verificar(guardados > 0, 'cancelar a confirmação não apaga nada')

    # 2. confirmar apaga os dois lados
    pg.once('dialog', lambda d: asyncio.ensure_future(d.accept()))
    await pg.click('#btn-clear-recent')
    await pg.wait_for_timeout(600)
    origem = await pg.evaluate("() => JSON.parse(localStorage.getItem('recent_origin') || '[]').length")
    destino = await pg.evaluate("() => JSON.parse(localStorage.getItem('recent_dest') || '[]').length")
    verificar(origem == 0 and destino == 0, 'confirmar apaga origem e destino')
    verificar('Nenhum' in await pg.locator('#recent-info').inner_text(), 'o texto passa a dizer que não há nenhum')

    # 3. sem recentes, não pergunta nada
    perguntou = []
    pg.once('dialog', lambda d: (perguntou.append(1), asyncio.ensure_future(d.dismiss())))
    await pg.click('#btn-clear-recent')
    await pg.wait_for_timeout(500)
    verificar(not perguntou, 'sem recentes, não faz pergunta nenhuma')

    # 4. o botão está separado do Guardar
    mesmaLinha = await pg.evaluate("""() => {
      const a = document.querySelector('#btn-clear-recent').closest('div');
      return a.contains(document.querySelector('#btn-settings-close'));
    }""")
    verificar(not mesmaLinha, 'o botão de apagar não está na mesma linha do Guardar')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def teste_voltar(b):
    print('\n# navegação para trás')
    ctx = await b.new_context(viewport={'width': 390, 'height': 900}, is_mobile=True, has_touch=True)
    pg, erros = await preparar(ctx)
    await procurar(pg)
    await pg.locator('#res-list .opt').first.click()
    await pg.wait_for_timeout(1200)
    await pg.go_back()
    await pg.wait_for_timeout(600)
    verificar(await pg.locator('#view-results.active').count() == 1, 'voltar do detalhe dá nos resultados')
    await pg.go_back()
    await pg.wait_for_timeout(600)
    verificar(await pg.locator('#view-search.active').count() == 1, 'voltar dos resultados dá na pesquisa')
    verificar(not erros, 'sem erros de JavaScript: ' + '; '.join(erros[:2]))
    await ctx.close()


async def main():
    from playwright.async_api import async_playwright
    servidor = servir()
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch()
            for teste in [
                teste_pesquisa_basica, teste_detalhe, teste_troco_a_pe,
                teste_chegar_ate, teste_chegar_ate_nao_manda_ao_passado,
                teste_chegar_ate_impossivel,
                teste_tempo_real, teste_detalhe_concorda_com_o_cartao,
                teste_api_tempo_real_estragada,
                teste_meteorologia_estragada, teste_avisos_meteorologia,
                teste_dados_em_falta, teste_gps, teste_gps_recusado,
                teste_escapes, teste_definicoes, teste_trocar_e_limpar,
                teste_recentes, teste_limpar_recentes, teste_voltar,
            ]:
                await teste(b)
            await b.close()
    finally:
        servidor.shutdown()

    print(f'\n{len(passou)} passaram, {len(falhas)} falharam')
    if falhas:
        for f in falhas:
            print('  FALHA ' + f)
        sys.exit(1)


if __name__ == '__main__':
    asyncio.run(main())
