import test from 'node:test';
import assert from 'node:assert/strict';
import {
  lerChegadas, escolherChegada, ehTempoReal, decidirChegada,
  dentroDoHorizonte, criarClienteTempoReal,
} from '../site/js/realtime.js';
import { TEMPO_REAL } from '../site/js/rules.js';
import { norm } from '../site/js/engine.js';
import { lisbonParts } from '../site/js/format.js';
import { respostaFalsa } from './ajuda.js';

const troco = (short = '701', head = 'Codiceira', dep = 600) => ({
  route: { short }, head, from: 3, dep,
});

// ---------------------------------------------------------------- formatos da resposta
test('lerChegadas aceita todos os formatos que a STCP já devolveu', () => {
  const uma = [{ line: '701' }];
  assert.deepEqual(lerChegadas(uma), uma);
  assert.deepEqual(lerChegadas({ arrivals: uma }), uma);
  assert.deepEqual(lerChegadas({ results: uma }), uma);
  assert.deepEqual(lerChegadas({ data: uma }), uma);
});

test('lerChegadas devolve lista vazia perante lixo', () => {
  for (const mau of [null, undefined, 0, '', 'texto', {}, { arrivals: null }, { arrivals: 'x' }]) {
    assert.deepEqual(lerChegadas(mau), [], 'entrada: ' + JSON.stringify(mau));
  }
});

test('lerChegadas deita fora entradas que não são objetos', () => {
  assert.deepEqual(lerChegadas({ arrivals: [null, 'x', 3, { line: '1' }] }), [{ line: '1' }]);
});

// ---------------------------------------------------------------- escolher a chegada certa
test('escolhe a chegada da linha pedida e ignora as outras', () => {
  const data = { arrivals: [{ line: '200', arrival_minutes: 2 }, { line: '701', arrival_minutes: 9 }] };
  assert.equal(escolherChegada(data, troco(), { norm }).min, 9);
});

test('reconhece o nome da linha em qualquer dos campos', () => {
  for (const campo of ['line', 'route', 'route_short_name']) {
    const data = { arrivals: [{ [campo]: '701', arrival_minutes: 5 }] };
    assert.equal(escolherChegada(data, troco(), { norm }).min, 5, 'campo ' + campo);
  }
  const longo = { arrivals: [{ route_long_name: '701', arrival_minutes: 5 }] };
  assert.equal(escolherChegada(longo, troco(), { norm }).min, 5);
});

test('conhece o par de nomes 107 / ZC', () => {
  const data = { arrivals: [{ line: 'ZC', arrival_minutes: 4 }] };
  assert.equal(escolherChegada(data, troco('107'), { norm }).min, 4);
});

test('"a chegar" (-1) vira 0 minutos', () => {
  const data = { arrivals: [{ line: '701', arrival_minutes: -1 }] };
  assert.equal(escolherChegada(data, troco(), { norm }).min, 0);
});

test('ignora chegadas sem minutos utilizáveis', () => {
  const data = { arrivals: [{ line: '701' }, { line: '701', arrival_minutes: 'depois' }] };
  assert.equal(escolherChegada(data, troco(), { norm }), null);
});

test('respeita o mínimo de minutos (não dá para apanhar o que chega antes de lá estar)', () => {
  const data = { arrivals: [{ line: '701', arrival_minutes: 2 }, { line: '701', arrival_minutes: 12 }] };
  assert.equal(escolherChegada(data, troco(), { norm, minimoMin: 5 }).min, 12);
});

test('prefere o mesmo sentido quando há dois', () => {
  const data = { arrivals: [
    { line: '701', arrival_minutes: 3, destination: 'Cordoaria' },
    { line: '701', arrival_minutes: 8, destination: 'Codiceira' },
  ] };
  assert.equal(escolherChegada(data, troco(), { norm }).min, 8);
});

test('se nenhum sentido bate, aceita a que há', () => {
  const data = { arrivals: [{ line: '701', arrival_minutes: 3, destination: 'Outro Sítio' }] };
  assert.equal(escolherChegada(data, troco(), { norm }).min, 3);
});

test('sem alvo escolhe a mais próxima no tempo', () => {
  const data = { arrivals: [{ line: '701', arrival_minutes: 20 }, { line: '701', arrival_minutes: 4 }] };
  assert.equal(escolherChegada(data, troco(), { norm }).min, 4);
});

test('com alvo escolhe a da viagem planeada, não a primeira', () => {
  const data = { arrivals: [{ line: '701', arrival_minutes: 4 }, { line: '701', arrival_minutes: 44 }] };
  assert.equal(escolherChegada(data, troco(), { norm, alvoMin: 40 }).min, 44);
});

test('sem norm, não filtra por sentido mas continua a funcionar', () => {
  const data = { arrivals: [{ line: '701', arrival_minutes: 7, destination: 'Outro' }] };
  assert.equal(escolherChegada(data, troco(), {}).min, 7);
});

test('devolve null sem dados, sem troço ou sem linha', () => {
  assert.equal(escolherChegada(null, troco(), { norm }), null);
  assert.equal(escolherChegada({ arrivals: [{ line: '701', arrival_minutes: 1 }] }, null, { norm }), null);
  assert.equal(escolherChegada({ arrivals: [{ line: '701', arrival_minutes: 1 }] }, {}, { norm }), null);
});

// ---------------------------------------------------------------- previsão ou tempo real
test('um campo booleano explícito manda em tudo o resto', () => {
  for (const k of ['realtime', 'is_realtime', 'real_time', 'live']) {
    assert.equal(ehTempoReal({ [k]: true }, ''), true, k);
    assert.equal(ehTempoReal({ [k]: false }, ''), false, k);
  }
});

test('uma fonte que se diz horário é previsão', () => {
  assert.equal(ehTempoReal({ data_source: 'scheduled' }, ''), false);
  assert.equal(ehTempoReal({}, 'timetable'), false);
  assert.equal(ehTempoReal({ data_source: 'horário' }, ''), false);
  assert.equal(ehTempoReal({ data_source: 'static' }, ''), false);
});

test('com hora estimada e hora de horário, compara-as', () => {
  const base = '2026-09-22T10:00:00Z';
  const igual = { estimated_arrival_time: base, scheduled_arrival_time: base };
  assert.equal(ehTempoReal(igual, 'realtime'), false, 'igual ao horário = previsão');
  const tarde = { estimated_arrival_time: '2026-09-22T10:02:00Z', scheduled_arrival_time: base };
  assert.equal(ehTempoReal(tarde, 'realtime'), true, 'diferente do horário = ao vivo');
});

test('sem contexto suficiente, assume previsão em vez de inventar', () => {
  assert.equal(ehTempoReal({ data_source: 'realtime' }, ''), false);
  assert.equal(ehTempoReal({ estimated_arrival_time: '2026-09-22T10:00:00Z' }, 'realtime'), false);
});

test('com a rede, compara a hora ao vivo com os horários da paragem', () => {
  const dez = 10 * 3600;                      // 10:00:00 em segundos
  const rede = { scheduledSecsAt: () => [dez] };
  const leg = troco();
  const ctx = { net: rede, leg, dataServico: '2026-09-22', lisbonParts };
  // 10:00:10 de Lisboa = 09:00:10 UTC em setembro
  const quaseIgual = { data_source: 'realtime', estimated_arrival_time: '2026-09-22T09:00:10Z' };
  assert.equal(ehTempoReal(quaseIgual, '', ctx), false, 'dentro dos 20 s = previsão');
  const diferente = { data_source: 'realtime', estimated_arrival_time: '2026-09-22T09:03:00Z' };
  assert.equal(ehTempoReal(diferente, '', ctx), true, 'fora dos 20 s = tempo real');
});

test('depois da meia-noite continua a ser o dia de serviço anterior', () => {
  // horário 24:10 = 86400 + 600 segundos
  const rede = { scheduledSecsAt: () => [86400 + 600] };
  const ctx = { net: rede, leg: troco(), dataServico: '2026-09-22', lisbonParts };
  // 00:10 de dia 23 em Lisboa = 23:10Z de dia 22
  const a = { data_source: 'realtime', estimated_arrival_time: '2026-09-22T23:10:05Z' };
  assert.equal(ehTempoReal(a, '', ctx), false, 'bate certo com o 24:10 do dia anterior');
});

// ---------------------------------------------------------------- é desta viagem?
test('um desvio pequeno é a mesma viagem', () => {
  const d = decidirChegada({ depMin: 600, chegadaMin: 14, agoraMin: 590, vizinhas: [560, 600, 640] });
  assert.equal(d.tipo, 'usar');
  assert.equal(d.quando, 604);
  assert.equal(d.desvio, 4);
});

test('um desvio maior do que a tolerância vira nota', () => {
  const fora = TEMPO_REAL.tolerancia_min + 1;
  const d = decidirChegada({ depMin: 600, chegadaMin: fora, agoraMin: 600, vizinhas: [] });
  assert.equal(d.tipo, 'nota');
  assert.match(d.motivo, /horário/);
});

test('adiantamento grande também vira nota', () => {
  const d = decidirChegada({ depMin: 600, chegadaMin: 0, agoraMin: 580, vizinhas: [] });
  assert.equal(d.tipo, 'nota');
});

test('se outra passagem da linha fica mais perto, o autocarro é esse', () => {
  // 10 min para as 10:10; a viagem planeada é 10:00 mas há outra às 10:12
  const d = decidirChegada({ depMin: 600, chegadaMin: 10, agoraMin: 600, vizinhas: [600, 612] });
  assert.equal(d.tipo, 'nota');
  assert.match(d.motivo, /outra passagem/);
});

test('empate a favor da viagem planeada', () => {
  const d = decidirChegada({ depMin: 600, chegadaMin: 5, agoraMin: 600, vizinhas: [600, 610] });
  assert.equal(d.tipo, 'usar', '605 está à mesma distância de 600 e 610: fica o planeado');
});

test('sem vizinhas conhecidas, decide só pela tolerância', () => {
  assert.equal(decidirChegada({ depMin: 600, chegadaMin: 3, agoraMin: 600 }).tipo, 'usar');
});

test('o horizonte respeita as regras', () => {
  assert.equal(dentroDoHorizonte(0), true);
  assert.equal(dentroDoHorizonte(TEMPO_REAL.horizonte_min), true);
  assert.equal(dentroDoHorizonte(TEMPO_REAL.horizonte_min + 1), false);
  assert.equal(dentroDoHorizonte(-TEMPO_REAL.atraso_max_min), true);
  assert.equal(dentroDoHorizonte(-TEMPO_REAL.atraso_max_min - 1), false);
});

// ---------------------------------------------------------------- cliente HTTP
test('usa o proxy quando há, e a STCP quando não há', async () => {
  const pedidos = [];
  const fetchFalso = async (u) => { pedidos.push(u); return respostaFalsa({ arrivals: [] }); };
  const comProxy = criarClienteTempoReal({ proxy: () => 'https://x.workers.dev/', fetchImpl: fetchFalso });
  await comProxy.obter('CORI1');
  assert.equal(pedidos[0], 'https://x.workers.dev/rt/CORI1');

  const semProxy = criarClienteTempoReal({ proxy: () => '', fetchImpl: fetchFalso });
  await semProxy.obter('CORI1');
  assert.match(pedidos[1], /^https:\/\/stcp\.pt\/api\/stops\/CORI1\/realtime$/);
});

test('o código da paragem é sempre escapado no endereço', async () => {
  const pedidos = [];
  const c = criarClienteTempoReal({
    proxy: () => 'https://x.workers.dev',
    fetchImpl: async (u) => { pedidos.push(u); return respostaFalsa({}); },
  });
  await c.obter('A/B?c=1');
  assert.equal(pedidos[0], 'https://x.workers.dev/rt/A%2FB%3Fc%3D1');
});

test('não repete o pedido dentro da validade da cache', async () => {
  let contas = 0;
  let agora = 0;
  const c = criarClienteTempoReal({
    proxy: () => '', agora: () => agora,
    fetchImpl: async () => { contas++; return respostaFalsa({ arrivals: [] }); },
  });
  await c.obter('A'); await c.obter('A');
  assert.equal(contas, 1);
  agora += TEMPO_REAL.cache_seg * 1000 + 1;
  await c.obter('A');
  assert.equal(contas, 2, 'passada a validade, pede outra vez');
});

test('limpar a cache força novo pedido', async () => {
  let contas = 0;
  const c = criarClienteTempoReal({ proxy: () => '', fetchImpl: async () => { contas++; return respostaFalsa({}); } });
  await c.obter('A');
  c.limpar();
  await c.obter('A');
  assert.equal(contas, 2);
});

test('erros da API não rebentam nem ficam a repetir', async () => {
  const casos = {
    'rede em baixo': async () => { throw new Error('offline'); },
    'erro 500': async () => respostaFalsa(null, { ok: false, status: 500 }),
    'erro 404': async () => respostaFalsa(null, { ok: false, status: 404 }),
    'json estragado': async () => respostaFalsa(null, { atirarNoJson: true }),
    'resposta vazia': async () => null,
  };
  for (const [nome, fetchImpl] of Object.entries(casos)) {
    const c = criarClienteTempoReal({ proxy: () => '', fetchImpl });
    assert.equal(await c.obter('A'), null, nome);
  }
});

test('sem fetch injetado, usa o global (e aguenta não existir)', async () => {
  const guardado = globalThis.fetch;
  globalThis.fetch = async () => { throw new Error('sem rede'); };
  try {
    const c = criarClienteTempoReal({ proxy: () => '' });
    assert.equal(await c.obter('A'), null);
  } finally {
    globalThis.fetch = guardado;
  }
});
