/**
 * Leitura das respostas dos geocodificadores e deteção do número de porta.
 *
 * O que está aqui é a parte pura: o que se faz com o texto escrito e com o JSON
 * que volta. O encadeamento dos pedidos vive em fields.js, que precisa de ecrã,
 * e está coberto pelos testes de browser.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { numeroDePorta, lerPhoton, lerNominatim, temNumero } from '../site/js/moradas.js';

// ---------------------------------------------------------------- número de porta
test('reconhece o número no fim, como se escreve em Portugal', () => {
  assert.equal(numeroDePorta('Rua Dom Afonso Henriques, 2469'), '2469');
  assert.equal(numeroDePorta('Rua Dom Afonso Henriques 2469'), '2469');
  assert.equal(numeroDePorta('Avenida da Boavista 1837'), '1837');
  assert.equal(numeroDePorta('Rua do Ouro, 12'), '12');
});

test('reconhece o número à frente, como se escreve noutros sítios', () => {
  assert.equal(numeroDePorta('2469 Rua Dom Afonso Henriques'), '2469');
  assert.equal(numeroDePorta('12, Rua do Ouro'), '12');
});

test('aceita a letra que às vezes acompanha o número', () => {
  assert.equal(numeroDePorta('Rua do Campo Alegre 1021 A'), '1021');
  assert.equal(numeroDePorta('Rua do Campo Alegre 1021A'), '1021');
});

test('não confunde código postal com número de porta', () => {
  assert.equal(numeroDePorta('Rua Dom Afonso Henriques, 4445-512'), null);
  assert.equal(numeroDePorta('4445-512 Águas Santas'), null);
});

test('sem número, não inventa', () => {
  assert.equal(numeroDePorta('Rua Dom Afonso Henriques'), null);
  assert.equal(numeroDePorta('Câmara de Gaia'), null);
  assert.equal(numeroDePorta(''), null);
  assert.equal(numeroDePorta(null), null);
  assert.equal(numeroDePorta(undefined), null);
});

// ---------------------------------------------------------------- Photon
const feature = (props, lon = -8.6, lat = 41.2) => ({
  properties: props, geometry: { coordinates: [lon, lat] },
});

test('lê uma morada com número de porta', () => {
  const r = lerPhoton({ features: [feature({
    street: 'Rua Dom Afonso Henriques', housenumber: '2469', city: 'Maia', postcode: '4445-512',
  })] }, 'x');
  assert.equal(r[0].label, 'Rua Dom Afonso Henriques 2469');
  assert.equal(r[0].numero, '2469');
  assert.equal(r[0].lat, 41.2);
  assert.equal(r[0].lon, -8.6);
});

test('lê uma rua sem número, e marca-a como tal', () => {
  const r = lerPhoton({ features: [feature({
    name: 'Rua Dom Afonso Henriques', district: 'Ardegães', city: 'Águas Santas', postcode: '4445-512',
  })] }, 'x');
  assert.equal(r[0].label, 'Rua Dom Afonso Henriques');
  assert.equal(r[0].numero, null);
  assert.equal(r[0].sub, 'Ardegães, Águas Santas, 4445-512');
});

test('não repete a mesma palavra na linha de baixo', () => {
  const r = lerPhoton({ features: [feature({ name: 'Porto', city: 'Porto', district: 'Porto' })] }, 'x');
  assert.equal(r[0].sub, 'Porto');
});

test('sem nome nem rua, usa a cidade e depois o que foi escrito', () => {
  assert.equal(lerPhoton({ features: [feature({ city: 'Maia' })] }, 'x')[0].label, 'Maia');
  assert.equal(lerPhoton({ features: [feature({})] }, 'escrito')[0].label, 'escrito');
});

test('respostas estragadas do Photon não rebentam', () => {
  for (const mau of [null, undefined, {}, { features: null }, { features: [] }, { features: [null] },
    { features: [{ properties: {} }] }]) {
    assert.deepEqual(lerPhoton(mau, 'x'), [], JSON.stringify(mau));
  }
});

// ---------------------------------------------------------------- Nominatim
test('lê o número de porta do Nominatim', () => {
  const r = lerNominatim([{
    lat: '41.21', lon: '-8.61', name: 'Rua Dom Afonso Henriques 2469',
    display_name: 'Rua Dom Afonso Henriques 2469, Ardegães, Maia, Porto',
    address: { house_number: '2469' },
  }]);
  assert.equal(r[0].numero, '2469');
  assert.equal(r[0].lat, 41.21);
  assert.equal(r[0].sub, 'Ardegães, Maia, Porto');
});

test('sem nome, usa a primeira parte do nome completo', () => {
  const r = lerNominatim([{ lat: '41', lon: '-8', display_name: 'Rua X, Maia, Porto' }]);
  assert.equal(r[0].label, 'Rua X');
  assert.equal(r[0].numero, null);
});

test('respostas estragadas do Nominatim não rebentam', () => {
  for (const mau of [null, undefined, {}, [], [null], [{}], 'texto']) {
    assert.deepEqual(lerNominatim(mau), [], JSON.stringify(mau));
  }
});

// ---------------------------------------------------------------- decisão
test('temNumero diz se alguma morada tem porta', () => {
  assert.equal(temNumero([{ numero: null }, { numero: '12' }]), true);
  assert.equal(temNumero([{ numero: null }, { numero: null }]), false);
  assert.equal(temNumero([]), false);
});
