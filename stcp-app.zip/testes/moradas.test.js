/**
 * Leitura das respostas dos geocodificadores e deteção do número de porta.
 *
 * O que está aqui é a parte pura: o que se faz com o texto escrito e com o JSON
 * que volta. O encadeamento dos pedidos vive em fields.js, que precisa de ecrã,
 * e está coberto pelos testes de browser.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { numeroDePorta, lerPhoton, lerNominatim, temNumero, partesDaMorada, numeroNoNome, semNumero }
  from '../site/js/moradas.js';

// ---------------------------------------------------------------- número de porta
test('reconhece o número no fim, como se escreve em Portugal', () => {
  assert.equal(numeroDePorta('Rua Dom Afonso Henriques, 2469'), '2469');
  assert.equal(numeroDePorta('Rua Dom Afonso Henriques 2469'), '2469');
  assert.equal(numeroDePorta('Avenida da Boavista 1837'), '1837');
  assert.equal(numeroDePorta('Rua do Ouro, 12'), '12');
});

test('reconhece o número à frente, como se escreve noutros sítios', () => {
  assert.equal(numeroDePorta('2469 Rua Dom Afonso Henriques'), '2469');
  assert.equal(numeroDePorta('12, Rua do Ouro'), '12');
});

test('aceita a letra que às vezes acompanha o número', () => {
  assert.equal(numeroDePorta('Rua do Campo Alegre 1021 A'), '1021');
  assert.equal(numeroDePorta('Rua do Campo Alegre 1021A'), '1021');
});

test('não confunde código postal com número de porta', () => {
  assert.equal(numeroDePorta('Rua Dom Afonso Henriques, 4445-512'), null);
  assert.equal(numeroDePorta('4445-512 Águas Santas'), null);
});

test('encontra o número quando a morada continua depois dele', () => {
  // era o que faltava: com a localidade ou o código postal a seguir, o número
  // deixava de ser visto e o app nem sequer tentava procurá-lo
  assert.equal(numeroDePorta('Rua da Piedade 93, Águas Santas'), '93');
  assert.equal(numeroDePorta('Rua da Piedade 93, Águas Santas, 4425-120'), '93');
  assert.equal(numeroDePorta('Rua da Piedade, 93, Maia'), '93');
  assert.equal(numeroDePorta('Avenida da Boavista 1837 A, Porto'), '1837');
});

test('sem número, não inventa', () => {
  assert.equal(numeroDePorta('Rua Dom Afonso Henriques'), null);
  assert.equal(numeroDePorta('Câmara de Gaia'), null);
  assert.equal(numeroDePorta(''), null);
  assert.equal(numeroDePorta(null), null);
  assert.equal(numeroDePorta(undefined), null);
});

// ---------------------------------------------------------------- Photon
const feature = (props, lon = -8.6, lat = 41.2) => ({
  properties: props, geometry: { coordinates: [lon, lat] },
});

test('lê uma morada com número de porta', () => {
  const r = lerPhoton({ features: [feature({
    street: 'Rua Dom Afonso Henriques', housenumber: '2469', city: 'Maia', postcode: '4445-512',
  })] }, 'x');
  assert.equal(r[0].label, 'Rua Dom Afonso Henriques 2469');
  assert.equal(r[0].numero, '2469');
  assert.equal(r[0].lat, 41.2);
  assert.equal(r[0].lon, -8.6);
});

test('lê uma rua sem número, e marca-a como tal', () => {
  const r = lerPhoton({ features: [feature({
    name: 'Rua Dom Afonso Henriques', district: 'Ardegães', city: 'Águas Santas', postcode: '4445-512',
  })] }, 'x');
  assert.equal(r[0].label, 'Rua Dom Afonso Henriques');
  assert.equal(r[0].numero, null);
  assert.equal(r[0].sub, 'Ardegães, Águas Santas, 4445-512');
});

test('não repete a mesma palavra na linha de baixo', () => {
  const r = lerPhoton({ features: [feature({ name: 'Porto', city: 'Porto', district: 'Porto' })] }, 'x');
  assert.equal(r[0].sub, 'Porto');
});

test('sem nome nem rua, usa a cidade e depois o que foi escrito', () => {
  assert.equal(lerPhoton({ features: [feature({ city: 'Maia' })] }, 'x')[0].label, 'Maia');
  assert.equal(lerPhoton({ features: [feature({})] }, 'escrito')[0].label, 'escrito');
});

test('respostas estragadas do Photon não rebentam', () => {
  for (const mau of [null, undefined, {}, { features: null }, { features: [] }, { features: [null] },
    { features: [{ properties: {} }] }]) {
    assert.deepEqual(lerPhoton(mau, 'x'), [], JSON.stringify(mau));
  }
});

// ---------------------------------------------------------------- Nominatim
test('lê o número de porta do Nominatim', () => {
  const r = lerNominatim([{
    lat: '41.21', lon: '-8.61', name: 'Rua Dom Afonso Henriques 2469',
    display_name: 'Rua Dom Afonso Henriques 2469, Ardegães, Maia, Porto',
    address: { house_number: '2469' },
  }]);
  assert.equal(r[0].numero, '2469');
  assert.equal(r[0].lat, 41.21);
  assert.equal(r[0].sub, 'Ardegães, Maia, Porto');
});

test('sem nome, usa a primeira parte do nome completo', () => {
  const r = lerNominatim([{ lat: '41', lon: '-8', display_name: 'Rua X, Maia, Porto' }]);
  assert.equal(r[0].label, 'Rua X');
  assert.equal(r[0].numero, null);
});

test('respostas estragadas do Nominatim não rebentam', () => {
  for (const mau of [null, undefined, {}, [], [null], [{}], 'texto']) {
    assert.deepEqual(lerNominatim(mau), [], JSON.stringify(mau));
  }
});

// ---------------------------------------------------------------- decisão
test('temNumero diz se alguma morada tem porta', () => {
  assert.equal(temNumero([{ numero: null }, { numero: '12' }]), true);
  assert.equal(temNumero([{ numero: null }, { numero: null }]), false);
  assert.equal(temNumero([]), false);
});

// ---------------------------------------------------------------- pergunta estruturada
test('separa a morada em rua, localidade e código postal', () => {
  assert.deepEqual(partesDaMorada('Rua da Piedade 93, Águas Santas, 4425-120', '93'),
    { street: '93 Rua da Piedade', city: 'Águas Santas', postalcode: '4425-120' });
  assert.deepEqual(partesDaMorada('Rua da Piedade 93', '93'), { street: '93 Rua da Piedade' });
  assert.deepEqual(partesDaMorada('Rua da Piedade 93, Águas Santas', '93'),
    { street: '93 Rua da Piedade', city: 'Águas Santas' });
});

test('põe sempre o número à frente da rua, que é como o Nominatim procura', () => {
  assert.equal(partesDaMorada('Rua X, 2469', '2469').street, '2469 Rua X');
  assert.equal(partesDaMorada('2469 Rua X', '2469').street, '2469 Rua X');
  assert.equal(partesDaMorada('12, Rua do Ouro', '12').street, '12 Rua do Ouro');
});

test('sem número, a morada vai como está', () => {
  assert.deepEqual(partesDaMorada('Câmara de Gaia', null), { street: 'Câmara de Gaia' });
  assert.deepEqual(partesDaMorada('Trindade, Porto', null), { street: 'Trindade', city: 'Porto' });
});

test('o código postal é reconhecido esteja onde estiver', () => {
  assert.equal(partesDaMorada('4445-512 Águas Santas', null).postalcode, '4445-512');
  assert.equal(partesDaMorada('4445-512 Águas Santas', null).street, 'Águas Santas');
});

test('texto vazio não dá pergunta nenhuma', () => {
  for (const mau of ['', '   ', ',,,', null, undefined]) assert.equal(partesDaMorada(mau, null), null);
});

// ---------------------------------------------------------------- ruas com números no nome
test('a vírgula antes do número não muda nada', () => {
  assert.equal(numeroDePorta('Rua da Piedade, 93'), '93');
  assert.deepEqual(partesDaMorada('Rua da Piedade, 93', '93'), { street: '93 Rua da Piedade' });
  assert.deepEqual(partesDaMorada('Rua da Piedade, 93, Maia', '93'),
    { street: '93 Rua da Piedade', city: 'Maia' });
});

test('uma rua com números no nome não fica estropiada', () => {
  // o número de porta é o do fim; o do nome da rua tem de ficar onde está
  assert.deepEqual(partesDaMorada('Rua dos 123, 93', '93'), { street: '93 Rua dos 123' });
  assert.deepEqual(partesDaMorada('Rua dos 123 93', '93'), { street: '93 Rua dos 123' });
});

test('mesmo quando o nome da rua tem o mesmo número da porta', () => {
  // era aqui que partia: o nome ficava "Rua dos" e procurava-se a rua errada
  assert.deepEqual(partesDaMorada('Rua dos 93, 93', '93'), { street: '93 Rua dos 93' });
  assert.deepEqual(partesDaMorada('Rua dos 93 93', '93'), { street: '93 Rua dos 93' });
  assert.deepEqual(partesDaMorada('Rua dos 93, 93 A, Maia', '93'),
    { street: '93 Rua dos 93', city: 'Maia' });
});

test('o número de porta só sai das pontas do nome da rua', () => {
  assert.equal(semNumero('Rua X 93', '93'), 'Rua X');
  assert.equal(semNumero('Rua X, 93', '93'), 'Rua X');
  assert.equal(semNumero('93 Rua X', '93'), 'Rua X');
  assert.equal(semNumero('Rua 93 de Maio', '93'), 'Rua 93 de Maio', 'no meio do nome, fica');
});

test('quando os dígitos são o nome da rua, não se diz que falta o número', () => {
  const achou = [{ label: 'Rua dos 123', numero: null }];
  assert.equal(numeroNoNome(achou, '123'), true);
  assert.equal(numeroNoNome(achou, '93'), false, 'outro número não é o nome da rua');
  assert.equal(numeroNoNome([{ label: 'Rua da Piedade' }], '93'), false);
  assert.equal(numeroNoNome([{ label: 'Rua 1234' }], '123'), false, 'não casa com parte de um número');
  assert.equal(numeroNoNome([{ label: 'Rua X' }], null), false);
  assert.equal(numeroNoNome([{}], '93'), false, 'resultado sem nome não rebenta');
});
