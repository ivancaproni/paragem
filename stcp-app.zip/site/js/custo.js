/**
 * MODELO DE CUSTO - o que se considera "melhor" num percurso.
 *
 * O algoritmo (raptor.js) sabe percorrer a rede, mas não tem opinião nenhuma:
 * quanto tempo se aceita andar a pé, se vale a pena um transbordo a mais, qual
 * de dois percursos parecidos se mostra primeiro, tudo isso está aqui.
 *
 * É este o ficheiro a mexer quando se quer mudar o comportamento do app sem
 * tocar no algoritmo. Os números vêm de rules.js; aqui ficam as decisões que
 * usam esses números.
 */
import { A_PE, PERCURSO } from './rules.js';

export const CUSTO = {
  // ------------------------------------------------------------ andar a pé
  raio: {
    transbordo: A_PE.transbordo_m,        // entre duas paragens
    acesso: A_PE.ate_a_paragem_m,         // da origem até à primeira paragem
    destino: A_PE.ate_ao_destino_m,       // da última paragem até ao destino
    acessoMax: PERCURSO.acesso_raio_max_m,
    acessoPasso: PERCURSO.acesso_passo_m,
    acessoMinParagens: PERCURSO.acesso_min_paragens,
  },

  /** Minutos a pé a partir de uma distância em linha reta. */
  minutosAPe(m) {
    return Math.max(A_PE.minimo_min, Math.round((m * A_PE.desvio) / A_PE.velocidade_ms / 60));
  },

  /** Minutos a pé quando a distância já é a da rua (não se aplica o desvio outra vez). */
  minutosDeRua(m) {
    return Math.max(A_PE.minimo_min, Math.round(m / A_PE.velocidade_ms / 60));
  },

  /** Metros pela rua a partir da linha reta. */
  metrosDeRua(m) { return Math.round(m * A_PE.desvio); },

  // ------------------------------------------------------------ transportes
  transbordosMax: PERCURSO.transbordos_max,
  opcoesMax: PERCURSO.opcoes_max,

  /** Tempo mínimo entre sair de um transporte e apanhar o seguinte. */
  esperaNoTransbordo(chegouDeTransporte) {
    return chegouDeTransporte ? PERCURSO.troca_na_mesma_paragem_min : 0;
  },

  /** Troço que a rede não cobre: estimativa de carro/TVDE. */
  minutosDeCarro(m) { return Math.round(m / PERCURSO.tvde_ms / 60); },

  // ------------------------------------------------------------ pesquisa
  voltasMax: PERCURSO.voltas_max,
  alternativasAteMin: PERCURSO.alternativas_ate_min,
  recuoChegarAteMin: PERCURSO.chegar_ate_recuo_min,

  // ------------------------------------------------------------ percursos incompletos
  incompletoOpcoes: PERCURSO.incompleto_opcoes,

  /** Só interessa uma paragem que aproxime mesmo do destino. */
  aproximaDoDestino(mAoDestino, mInicial) {
    return mAoDestino <= mInicial * PERCURSO.incompleto_aproxima;
  },

  /** Quanto pior fica um percurso incompleto: tempo + o que falta + cada transbordo. */
  custoIncompleto(chegada, mAoDestino, transbordos) {
    return chegada + mAoDestino / PERCURSO.tvde_ms / 60
      + transbordos * PERCURSO.incompleto_por_transbordo_min;
  },

  // ------------------------------------------------------------ escolhas entre opções
  /**
   * Onde apanhar o transporte, quando a mesma viagem passa em várias paragens
   * ao alcance. Ganha a que dá menos caminhada; em caso de empate, a que sai
   * mais tarde, porque deixa mais folga a quem vai a pé.
   */
  melhorEmbarque(candidato, atual) {
    if (!atual) return true;
    if (candidato.m !== atual.m) return candidato.m < atual.m;
    return candidato.dep > atual.dep;
  },

  /** Apanhar a mesma linha duas vezes seguidas é sair e voltar a entrar: não se mostra. */
  saiEVoltaAEntrar(it) {
    const rides = it.legs.filter((l) => l.type === 'ride');
    return rides.some((r, i) => i > 0 && r.route.short === rides[i - 1].route.short);
  },

  /** Total de minutos a pé de um percurso, do princípio ao fim. */
  minutosAPeTotal(it) {
    return it.legs.reduce((a, l) => a + (l.type === 'walk' ? l.dur : 0), 0)
      + (it.last.type === 'walk' ? it.last.dur : 0);
  },

  /**
   * Duas opções com as mesmas linhas a chegar à mesma hora são o mesmo veículo
   * apanhado noutra paragem. Esta chave junta-as para ficar só a melhor.
   */
  chaveDaViagem(it) {
    if (it.walkOnly) return 'walk';
    return it.legs.filter((l) => l.type === 'ride').map((l) => l.route.short).join('+') + '@' + it.arrive;
  },

  /** Identidade de um percurso, para não repetir a mesma sugestão. */
  assinatura(it) {
    return it.legs.filter((l) => l.type === 'ride')
      .map((l) => l.route.short + '@' + l.from + '>' + l.to).join('|');
  },

  /** Tempo de porta a porta, contando a caminhada inicial. */
  portaAPorta(it) { return it.arrive - horaDeSair(it); },

  // ------------------------------------------------------------ ordem final
  /** Pesquisa por hora de partida: quem chega mais cedo aparece primeiro. */
  ordenar(a, b) {
    return (b.complete - a.complete) || a.arrive - b.arrive || a.transfers - b.transfers;
  },

  /** "Chegar até": primeiro quem deixa sair mais tarde e ainda chega a horas. */
  ordenarChegarAte(a, b) {
    return (b.complete - a.complete) || horaDeSair(b) - horaDeSair(a)
      || a.arrive - b.arrive || a.transfers - b.transfers;
  },
};

/** Hora a que é preciso sair da origem: a partida do transporte menos a caminhada inicial. */
export function horaDeSair(it) {
  const w = it.legs[0] && it.legs[0].type === 'walk' ? it.legs[0].dur : 0;
  return it.depart - w;
}
