/**
 * Troca de ecrã e histórico do browser.
 *
 * O botão Voltar do iPhone tem de funcionar como em qualquer site, por isso cada
 * ecrã é uma entrada no histórico em vez de um estado só do app.
 */

const ouvintes = [];
/** Regista quem quer saber que o ecrã mudou (por exemplo, o mapa, para se redesenhar). */
export const quandoMostrar = (fn) => ouvintes.push(fn);

export function show(view) {
  document.querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + view));
  window.scrollTo(0, 0);
  ouvintes.forEach((f) => f(view));
}

/** Vai para um ecrã, deixando o anterior no histórico. */
export const go = (view) => { history.pushState({ view }, ''); show(view); };

export function iniciarNavegacao() {
  document.querySelectorAll('[data-back]').forEach((b) => b.addEventListener('click', () => history.back()));
  window.addEventListener('popstate', (e) => show((e.state && e.state.view) || 'search'));
  history.replaceState({ view: 'search' }, '');
}
