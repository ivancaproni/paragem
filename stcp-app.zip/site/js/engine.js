/* Motor de pesquisa de percursos (RAPTOR) + zonas Andante.
 * Módulo puro: não toca no ecrã nem na rede, por isso corre tal e qual nos testes. */
import { A_PE, PERCURSO, ANDANTE } from './rules.js';

const INF = 1e9;
const WALK_MS = A_PE.velocidade_ms;
const DETOUR = A_PE.desvio;
const TRANSFER_RADIUS = A_PE.transbordo_m;
const EGRESS_RADIUS = A_PE.ate_ao_destino_m;
const ACCESS_RADIUS = A_PE.ate_a_paragem_m;
const MIN_CHANGE = PERCURSO.troca_na_mesma_paragem_min;
const CAR_MS = PERCURSO.tvde_ms;


function dist(lat1, lon1, lat2, lon2) {
  const r = Math.PI / 180;
  const a = Math.sin((lat2 - lat1) * r / 2) ** 2 +
    Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin((lon2 - lon1) * r / 2) ** 2;
  return 12742000 * Math.asin(Math.sqrt(a));
}
const walkMin = (m) => Math.max(1, Math.round((m * DETOUR) / WALK_MS / 60));

function norm(s) {
  return (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
}

class Network {
  constructor(net) {
    this.raw = net;
    const S = net.stops;
    this.n = S.length;
    this.stopId = S.map(s => s[0]);
    this.stopCode = S.map(s => s[1]);
    this.stopName = S.map(s => s[2]);
    this.lat = Float64Array.from(S.map(s => s[3]));
    this.lon = Float64Array.from(S.map(s => s[4]));
    this.zone = S.map(s => s[5] || '');
    this.routes = net.routes.map(r => ({ short: r[0], long: r[1], color: r[2], text: r[3], type: r[4] }));
    this.calendar = net.calendar;
    this.zoneAdj = net.zoneAdj || {};
    this.zoneDist = net.zoneDist || {};
    // tabela oficial de titulos entre estacoes de metro (so vale para percursos so de metro)
    this.metroZ = net.metroZ ? net.metroZ.z : null;
    this.metroZi = new Map();
    if (net.metroZ) net.metroZ.i.forEach((stopIx, k) => this.metroZi.set(stopIx, k));
    this.used = new Uint8Array(this.n);
    (net.used || []).forEach(i => { this.used[i] = 1; });

    // v1: tempos em minutos; v2: tempos em segundos (precisao igual a da STCP)
    const unit = (net.v || 1) >= 2 ? 60 : 1;
    this.unit = unit;
    this.patterns = net.patterns.map(p => {
      const t = p.t;
      const nt = t.length / 3, L = p.s.length;
      const start = new Int32Array(nt), prof = new Int32Array(nt), svc = new Int32Array(nt);
      for (let j = 0; j < nt; j++) { start[j] = t[3 * j]; prof[j] = t[3 * j + 1]; svc[j] = t[3 * j + 2]; }
      const profiles = p.p.map(a => Int32Array.from(a));
      // tempos absolutos em minutos por viagem x paragem (arredondados para baixo, como no site da STCP)
      const tm = new Int32Array(nt * L);
      const maxOff = new Int32Array(L);
      for (let j = 0; j < nt; j++) {
        const pr = profiles[prof[j]], base = j * L;
        for (let i = 0; i < L; i++) tm[base + i] = Math.floor((start[j] + pr[i]) / unit);
        for (let i = 0; i < L; i++) maxOff[i] = Math.max(maxOff[i], tm[base + i] - tm[base]);
      }
      return { r: p.r, d: p.d, h: p.h, s: p.s, sh: p.sh, L, profiles, start, prof, svc, tm, maxOff };
    });
    this.stopPatterns = Array.from({ length: this.n }, () => []);
    this.patterns.forEach((p, pi) => p.s.forEach((s, pos) => this.stopPatterns[s].push(pi, pos)));
    this.searchKey = this.stopName.map((nm, i) => norm(nm + ' ' + this.stopCode[i]));
    this._grid();
    this.footpaths = Array.from({ length: this.n }, () => []);
    for (let i = 0; i < this.n; i++) {
      if (!this.used[i]) continue;
      for (const j of this.near(this.lat[i], this.lon[i], TRANSFER_RADIUS)) {
        if (j === i || !this.used[j]) continue;
        this.footpaths[i].push(j, walkMin(dist(this.lat[i], this.lon[i], this.lat[j], this.lon[j])));
      }
    }
  }

  _grid() {
    this.cell = 0.005; // ~ 550 m
    this.grid = new Map();
    for (let i = 0; i < this.n; i++) {
      const k = Math.floor(this.lat[i] / this.cell) + ':' + Math.floor(this.lon[i] / this.cell);
      if (!this.grid.has(k)) this.grid.set(k, []);
      this.grid.get(k).push(i);
    }
  }

  /** paragens a menos de `radius` metros */
  near(lat, lon, radius) {
    const out = [];
    const cy = Math.floor(lat / this.cell), cx = Math.floor(lon / this.cell);
    const ry = Math.ceil(radius / 550) + 1, rx = Math.ceil(radius / 400) + 1;
    for (let y = cy - ry; y <= cy + ry; y++) for (let x = cx - rx; x <= cx + rx; x++) {
      const c = this.grid.get(y + ':' + x);
      if (!c) continue;
      for (const i of c) if (dist(lat, lon, this.lat[i], this.lon[i]) <= radius) out.push(i);
    }
    return out;
  }

  /** as k paragens mais proximas (com linhas) */
  nearest(lat, lon, k = 4) {
    let r = 300, res = [];
    while (res.length < k && r < 20000) { res = this.near(lat, lon, r).filter(i => this.used[i]); r *= 2; }
    return res.map(i => ({ i, m: dist(lat, lon, this.lat[i], this.lon[i]) }))
      .sort((a, b) => a.m - b.m).slice(0, k);
  }

  search(q, limit = 30) {
    const nq = norm(q);
    if (!nq) return [];
    const words = nq.split(' ');
    const res = [];
    for (let i = 0; i < this.n; i++) {
      if (!this.used[i]) continue;
      const key = this.searchKey[i];
      if (!words.every(w => key.includes(w))) continue;
      const score = (norm(this.stopCode[i]) === nq ? 0 : key.startsWith(nq) ? 1 : 2);
      res.push({ i, score });
    }
    res.sort((a, b) => a.score - b.score || this.stopName[a.i].localeCompare(this.stopName[b.i]));
    return res.slice(0, limit).map(r => r.i);
  }

  /** uma linha que serve a paragem (para saber se e metro ou autocarro) */
  routeAt(stop) {
    const sp = this.stopPatterns[stop];
    return sp.length ? this.routes[this.patterns[sp[0]].r] : null;
  }

  /** linhas que passam na paragem */
  linesAt(stop) {
    const set = new Map();
    const sp = this.stopPatterns[stop];
    for (let k = 0; k < sp.length; k += 2) {
      const r = this.routes[this.patterns[sp[k]].r];
      set.set(r.short, r);
    }
    return [...set.values()].sort((a, b) => a.short.localeCompare(b.short, 'pt', { numeric: true }));
  }

  // ------------------------------------------------------------ calendario
  static addDays(iso, n) {
    const d = new Date(iso + 'T12:00:00Z');
    d.setUTCDate(d.getUTCDate() + n);
    return d.toISOString().slice(0, 10);
  }

  /** viagens ativas por padrao para uma data de servico; inclui as viagens
   *  de ontem que passam da meia-noite (horas >= 24:00), deslocadas -1440. */
  _active(dateIso) {
    if (this._actCache && this._actCache.date === dateIso) return this._actCache.list;
    const today = new Set(this.calendar[dateIso] || []);
    const yday = new Set(this.calendar[Network.addDays(dateIso, -1)] || []);
    const list = this.patterns.map(p => {
      const arr = []; // pares [indice da viagem, deslocamento]
      const L = p.L, last = L - 1;
      for (let j = 0; j < p.start.length; j++) {
        if (today.has(p.svc[j])) arr.push([j, 0]);
        if (yday.has(p.svc[j]) && p.tm[j * L + last] >= 1440) arr.push([j, -1440]);
      }
      arr.sort((a, b) => (p.tm[a[0] * L] + a[1]) - (p.tm[b[0] * L] + b[1]));
      const ix = Int32Array.from(arr.map(a => a[0])), sh = Int32Array.from(arr.map(a => a[1]));
      const st = Int32Array.from(arr.map(a => p.tm[a[0] * L] + a[1]));
      return { ix, sh, st };
    });
    this._actCache = { date: dateIso, list };
    return list;
  }

  hasService(dateIso) { return !!(this.calendar[dateIso] && this.calendar[dateIso].length); }

  _earliest(pi, act, pos, t) {
    const p = this.patterns[pi], a = act[pi], st = a.st;
    // primeira viagem com st >= t - maxOff[pos]
    let lo = 0, hi = st.length;
    const lim = t - p.maxOff[pos];
    while (lo < hi) { const m = (lo + hi) >> 1; if (st[m] < lim) lo = m + 1; else hi = m; }
    let best = -1, bestT = INF;
    for (let j = lo; j < st.length; j++) {
      const tt = p.tm[a.ix[j] * p.L + pos] + a.sh[j];
      if (tt >= t && tt < bestT) { best = j; bestT = tt; }
      if (st[j] > bestT) break;
    }
    return best;
  }
  _time(pi, act, j, pos) { const p = this.patterns[pi], a = act[pi]; return p.tm[a.ix[j] * p.L + pos] + a.sh[j]; }
  /** hora (minutos) da viagem `trip` (indice real) na posicao `pos`, com deslocamento `shift` */
  tripTime(pi, trip, shift, pos) { const p = this.patterns[pi]; return p.tm[trip * p.L + pos] + shift; }
  /** hora exata em segundos (para comparar com o tempo real) */
  tripSec(pi, trip, shift, pos) { const p = this.patterns[pi]; return (p.start[trip] + p.profiles[p.prof[trip]][pos]) * (this.unit === 60 ? 1 : 60) + shift * 60; }

  // ------------------------------------------------------------ RAPTOR
  /**
   * @param {object} q { origin: stopIdx, dest: {lat, lon, stop?}, date: 'YYYY-MM-DD', time: minutos, maxTransfers }
   * @returns lista de itinerarios (pareto chegada x transbordos) + parciais se necessario
   */
  /** origem: indice de paragem (compatibilidade) ou {stop?, lat, lon} */
  _origin(o) {
    if (typeof o === 'number') return { stop: o, lat: this.lat[o], lon: this.lon[o] };
    if (o.stop != null) return { stop: o.stop, lat: this.lat[o.stop], lon: this.lon[o.stop] };
    return { stop: null, lat: o.lat, lon: o.lon };
  }

  /** paragens a pe a partir de uma morada: todas ate 800 m (alarga ate 2 km se houver poucas) */
  accessStops(lat, lon) {
    let r = ACCESS_RADIUS, res = [];
    while (r <= 2000) {
      res = this.near(lat, lon, r).filter(i => this.used[i]);
      if (res.length >= 3) break;
      r += 400;
    }
    return res.map(i => { const m = dist(lat, lon, this.lat[i], this.lon[i]); return { i, m, w: walkMin(m) }; });
  }

  route(q) {
    const K = (q.maxTransfers ?? PERCURSO.transbordos_max) + 1;
    const O = this._origin(q.origin);
    const act = this._active(q.date);
    const n = this.n;
    const tau = [new Float64Array(n).fill(INF)];
    const par = [new Array(n)];
    const best = new Float64Array(n).fill(INF);
    let marked = new Set();

    // ronda 0: paragem de origem (+ paragens a pe dela) ou morada (+ paragens a pe dela)
    if (O.stop != null) {
      tau[0][O.stop] = q.time; best[O.stop] = q.time; marked.add(O.stop);
      par[0][O.stop] = { type: 'origin' };
      const fp0 = this.footpaths[O.stop];
      for (let k = 0; k < fp0.length; k += 2) {
        const s = fp0[k], w = fp0[k + 1];
        if (q.time + w < tau[0][s]) {
          tau[0][s] = best[s] = q.time + w; par[0][s] = { type: 'walk', from: O.stop, dur: w }; marked.add(s);
        }
      }
    } else {
      for (const a of this.accessStops(O.lat, O.lon)) {
        if (q.time + a.w < tau[0][a.i]) {
          tau[0][a.i] = best[a.i] = q.time + a.w; par[0][a.i] = { type: 'access', dur: a.w, m: a.m }; marked.add(a.i);
        }
      }
    }

    // destinos (egress)
    const egress = new Map();
    if (q.dest.stop != null) egress.set(q.dest.stop, 0);
    for (const s of this.near(q.dest.lat, q.dest.lon, EGRESS_RADIUS)) {
      const w = walkMin(dist(q.dest.lat, q.dest.lon, this.lat[s], this.lon[s]));
      if (!egress.has(s) || egress.get(s) > w) egress.set(s, s === q.dest.stop ? 0 : w);
    }
    let bestTarget = INF;

    for (let k = 1; k <= K; k++) {
      tau[k] = new Float64Array(n).fill(INF);
      par[k] = new Array(n);
      const Q = new Map();
      for (const s of marked) {
        const sp = this.stopPatterns[s];
        for (let x = 0; x < sp.length; x += 2) {
          const pi = sp[x], pos = sp[x + 1];
          if (!Q.has(pi) || Q.get(pi) > pos) Q.set(pi, pos);
        }
      }
      const newly = new Set();
      for (const [pi, p0] of Q) {
        const p = this.patterns[pi];
        let trip = -1, boardPos = -1;
        for (let pos = p0; pos < p.s.length; pos++) {
          const s = p.s[pos];
          if (trip >= 0) {
            const arr = this._time(pi, act, trip, pos);
            if (arr < Math.min(best[s], bestTarget)) {
              tau[k][s] = best[s] = arr;
              par[k][s] = { type: 'ride', pi, trip, from: p.s[boardPos], boardPos, pos,
                dep: this._time(pi, act, trip, boardPos), arr, trip: act[pi].ix[trip], shift: act[pi].sh[trip] };
              newly.add(s);
            }
          }
          const prev = tau[k - 1][s];
          if (prev < INF) {
            const ready = prev + (k > 1 && par[k - 1][s] && par[k - 1][s].type === 'ride' ? MIN_CHANGE : 0);
            if (trip < 0 || ready <= this._time(pi, act, trip, pos)) {
              const j = this._earliest(pi, act, pos, ready);
              if (j >= 0 && (trip < 0 || this._time(pi, act, j, pos) < this._time(pi, act, trip, pos))) {
                trip = j; boardPos = pos;
              }
            }
          }
        }
      }
      // transbordos a pe
      for (const s of [...newly]) {
        const fp = this.footpaths[s];
        for (let x = 0; x < fp.length; x += 2) {
          const t2 = fp[x], w = fp[x + 1];
          const arr = tau[k][s] + w;
          if (arr < Math.min(tau[k][t2], best[t2], bestTarget)) {
            tau[k][t2] = best[t2] = arr; par[k][t2] = { type: 'walk', from: s, dur: w }; newly.add(t2);
          }
        }
      }
      for (const [s, w] of egress) if (tau[k][s] + w < bestTarget) bestTarget = tau[k][s] + w;
      marked = newly;
      if (!marked.size) break;
    }

    // melhores por numero de viagens (pareto)
    const out = [];
    let prevBest = INF;
    for (let k = 1; k < tau.length; k++) {
      let bs = -1, bt = INF;
      for (const [s, w] of egress) {
        const t = tau[k][s] + w;
        if (t < bt || (t === bt && w < (egress.get(bs) ?? INF))) { bt = t; bs = s; }
      }
      if (bs >= 0 && bt < prevBest) {
        out.push(this._build(tau, par, k, bs, q, { type: 'walk', m: dist(this.lat[bs], this.lon[bs], q.dest.lat, q.dest.lon), dur: egress.get(bs) }));
        prevBest = bt;
      }
    }
    if (out.length) return out;

    // sem ligacao completa: aproxima o mais possivel e devolve troco em falta
    const d0 = dist(O.lat, O.lon, q.dest.lat, q.dest.lon);
    let cand = [];
    for (let k = 1; k < tau.length; k++) {
      for (let s = 0; s < n; s++) {
        if (tau[k][s] >= INF || !par[k][s] || par[k][s].type !== 'ride') continue;
        const m = dist(this.lat[s], this.lon[s], q.dest.lat, q.dest.lon);
        if (m > d0 * 0.75) continue;
        cand.push({ k, s, m, score: tau[k][s] + m / CAR_MS / 60 + k * 4 });
      }
    }
    cand.sort((a, b) => a.score - b.score);
    const seen = new Set();
    for (const c of cand) {
      if (out.length >= 3) break;
      const it = this._build(tau, par, c.k, c.s, q, { type: 'uncovered', m: c.m, dur: Math.round(c.m / CAR_MS / 60) });
      const sig = it.legs.filter(l => l.type === 'ride').map(l => l.route.short).join('>');
      if (seen.has(sig)) continue;
      seen.add(sig); out.push(it);
    }
    return out;
  }

  /** Varias opcoes: repete a pesquisa apos a 1.a partida para obter alternativas distintas. */
  /** Hora a que e preciso sair de casa/da origem (a partida do transporte menos a caminhada inicial). */
  static leaveAt(it) {
    const w = it.legs[0] && it.legs[0].type === 'walk' ? it.legs[0].dur : 0;
    return it.depart - w;
  }

  /**
   * "Chegar ate": procura a partida mais tardia que ainda chega a horas.
   * Faz uma pesquisa binaria sobre a hora de partida (a hora de chegada so pode piorar
   * quando se sai mais tarde), e depois recolhe as opcoes a volta dessa hora.
   */
  planArriveBy(q, arriveBy, maxOptions = PERCURSO.opcoes_max) {
    const SPAN = PERCURSO.chegar_ate_recuo_min;
    const base = { ...q };
    delete base.arriveBy;              // senao a chamada a plan() voltava aqui
    // Nao faz sentido mandar sair a uma hora que ja passou: quem pesquisa para hoje
    // passa em `notBefore` a hora atual.
    const cedoDemais = Number.isFinite(q.notBefore) ? q.notBefore : -INF;
    if (cedoDemais > arriveBy) return [];
    const earliest = (t) => {
      let a = INF;
      for (const it of this.route({ ...base, time: t })) if (it.complete && it.arrive < a) a = it.arrive;
      return a;
    };
    let lo = Math.max(arriveBy - SPAN, cedoDemais);
    if (earliest(lo) > arriveBy) return [];        // nem saindo o mais cedo possivel chega a horas
    let hi = arriveBy;
    while (hi - lo > 1) {                          // maior t com chegada <= arriveBy
      const mid = Math.floor((lo + hi) / 2);
      if (earliest(mid) <= arriveBy) lo = mid; else hi = mid;
    }
    const tardia = lo;
    const seen = new Map(), out = [];
    const juntar = (its) => {
      for (const it of its) {
        if (it.arrive > arriveBy) continue;
        if (Network.leaveAt(it) < cedoDemais) continue;   // partida ja passada
        const sig = it.legs.filter(l => l.type === 'ride').map(l => l.route.short + '@' + l.from + '>' + l.to).join('|');
        if (!seen.has(sig)) { seen.set(sig, it); out.push(it); }
      }
    };
    juntar(this.plan({ ...base, time: tardia }, 3));
    juntar(this.plan({ ...base, time: Math.max(arriveBy - SPAN, cedoDemais, tardia - 60) }, maxOptions + 6));
    // ir a pe pode sair a hora que quiser: ajustar para chegar mesmo a horas
    const aPe = out.find(it => it.walkOnly);
    if (aPe) { aPe.depart = Math.max(arriveBy - aPe.last.dur, cedoDemais); aPe.arrive = aPe.depart + aPe.last.dur; }
    const porta = (it) => it.arrive - Network.leaveAt(it);
    // se o transporte demora mais do que ir a pe, nao vale a pena mostra-lo
    const kept = aPe ? out.filter(it => it.walkOnly || porta(it) < porta(aPe)) : out;
    // primeiro quem pode sair mais tarde e ainda chega a horas
    kept.sort((a, b) => (b.complete - a.complete) || Network.leaveAt(b) - Network.leaveAt(a)
      || a.arrive - b.arrive || a.transfers - b.transfers);
    return kept.slice(0, maxOptions);
  }

  plan(q, maxOptions = PERCURSO.opcoes_max) {
    if (q.arriveBy != null) return this.planArriveBy(q, q.arriveBy, maxOptions);
    const seen = new Map();
    let results = [];
    const O = this._origin(q.origin);
    const direct = dist(O.lat, O.lon, q.dest.lat, q.dest.lon);
    if (direct <= EGRESS_RADIUS && (O.stop == null || q.dest.stop !== O.stop)) {
      results.push({ legs: [], rides: 0, transfers: 0, depart: q.time, arrive: q.time + walkMin(direct),
        finalStop: O.stop, complete: true, walkOnly: true, fare: null,
        last: { type: 'walk', m: direct, dur: walkMin(direct), lat: q.dest.lat, lon: q.dest.lon } });
    }
    let t = q.time;
    for (let round = 0; round < 6 && results.length < maxOptions + 1; round++) {
      const its = this.route({ ...q, time: t });
      if (!its.length) break;
      let minDep = INF;
      for (const it of its) {
        const sig = it.legs.filter(l => l.type === 'ride').map(l => l.route.short + '@' + l.from + '>' + l.to).join('|');
        minDep = Math.min(minDep, it.depart);
        if (!seen.has(sig)) { seen.set(sig, it); results.push(it); }
      }
      if (minDep >= INF || minDep - q.time > 180) break;
      t = minDep + 1;
    }
    // descartar percursos que apanham a mesma linha duas vezes seguidas (sai e volta a entrar)
    const sameTwice = (it) => {
      const rides = it.legs.filter(l => l.type === 'ride');
      return rides.some((r, i) => i > 0 && r.route.short === rides[i - 1].route.short);
    };
    for (let i = results.length - 1; i >= 0; i--) if (sameTwice(results[i])) results.splice(i, 1);

    // mesma(s) linha(s) a chegar a mesma hora = mesmo autocarro apanhado noutra paragem: fica o de menos caminhada
    const walkOf = (it) => it.legs.reduce((a, l) => a + (l.type === 'walk' ? l.dur : 0), 0) + (it.last.type === 'walk' ? it.last.dur : 0);
    const byTrip = new Map();
    for (const it of results) {
      const k = it.walkOnly ? 'walk' : it.legs.filter(l => l.type === 'ride').map(l => l.route.short).join('+') + '@' + it.arrive;
      const cur = byTrip.get(k);
      if (!cur || walkOf(it) < walkOf(cur)) byTrip.set(k, it);
    }
    results = [...byTrip.values()];

    // se ir a pe e mais rapido, nao mostrar autocarros que chegam depois
    const walk = results.find(r => r.walkOnly);
    const kept = walk ? results.filter(r => r.walkOnly || r.arrive < walk.arrive) : results;
    kept.sort((a, b) => (b.complete - a.complete) || a.arrive - b.arrive || a.transfers - b.transfers);
    return kept.slice(0, maxOptions);
  }

  _build(tau, par, k, s, q, last) {
    const legs = [];
    let cur = s, kk = k;
    let guard = 0;
    while (guard++ < 50) {
      const p = par[kk][cur];
      if (!p || p.type === 'origin') break;
      if (p.type === 'access') { // da morada de origem ate a primeira paragem
        legs.unshift({ type: 'walk', from: -1, to: cur, dur: p.dur, m: Math.round(p.m * DETOUR), access: true });
        break;
      }
      if (p.type === 'walk') {
        legs.unshift({ type: 'walk', from: p.from, to: cur, dur: p.dur,
          m: Math.round(dist(this.lat[p.from], this.lon[p.from], this.lat[cur], this.lon[cur]) * DETOUR) });
        cur = p.from;
        if (kk === 0) continue;
        if (par[kk][cur] && par[kk][cur].type === 'ride') continue;
        continue;
      }
      const pat = this.patterns[p.pi];
      legs.unshift({ type: 'ride', pi: p.pi, route: this.routes[pat.r], head: pat.h, from: p.from, to: cur,
        boardPos: p.boardPos, alightPos: p.pos, dep: p.dep, arr: p.arr,
        stops: pat.s.slice(p.boardPos, p.pos + 1), trip: p.trip, shift: p.shift });
      cur = p.from; kk--;
    }
    // junta troços a pé seguidos: quem anda a pé vai direto, nao passa por paragens pelo caminho
    for (let i = legs.length - 1; i > 0; i--) {
      const a = legs[i - 1], b = legs[i];
      if (a.type !== 'walk' || b.type !== 'walk') continue;
      const m = a.access
        ? a.m + b.m
        : Math.round(dist(this.lat[a.from], this.lon[a.from], this.lat[b.to], this.lon[b.to]) * DETOUR);
      legs.splice(i - 1, 2, { ...a, to: b.to, m, dur: Math.max(1, Math.round(m / WALK_MS / 60)) });
    }
    let lastStop = s;
    let end = tau[k][s] + (last.dur || 0);
    // se o percurso acaba a pé, vai-se a pé direto de onde se sai do transporte ate ao destino
    const tail = legs[legs.length - 1];
    if ((last.type === 'walk' || last.type === 'uncovered') && tail && tail.type === 'walk' && !tail.access) {
      const prev = legs[legs.length - 2];
      if (prev && prev.type === 'ride') {
        legs.pop();
        lastStop = prev.to;
        const m = dist(this.lat[lastStop], this.lon[lastStop], q.dest.lat, q.dest.lon);
        const dur = last.type === 'walk' ? walkMin(m) : Math.round(m / CAR_MS / 60);
        last = { ...last, m, dur };
        end = prev.arr + dur;
      }
    }
    const rides = legs.filter(l => l.type === 'ride');
    const it = {
      legs, rides: rides.length, transfers: Math.max(0, rides.length - 1),
      depart: rides.length ? rides[0].dep : q.time, arrive: end,
      finalStop: lastStop, last: { ...last, lat: q.dest.lat, lon: q.dest.lon },
      complete: last.type !== 'uncovered',
    };
    it.fare = this.fare(it);
    return it;
  }

  // ------------------------------------------------------------ zonas
  zoneDistances(z0) {
    const d = { [z0]: 0 };
    const qq = [z0];
    while (qq.length) {
      const z = qq.shift();
      for (const y of this.zoneAdj[z] || []) if (!(y in d)) { d[y] = d[z] + 1; qq.push(y); }
    }
    // aneis conhecidos oficialmente mandam sobre o calculo por vizinhanca
    for (const [k, v] of Object.entries(this.zoneDist)) {
      const [a, b] = k.split('|');
      if (a === z0) d[b] = v; else if (b === z0) d[a] = v;
    }
    return d;
  }

  /** Titulo oficial do Metro do Porto, quando o percurso e feito so de metro. */
  metroTitle(rides) {
    if (!this.metroZ || !rides.length) return null;
    for (const r of rides) if (this.routes[this.patterns[r.pi].r].type !== 1) return null;
    const a = this.metroZi.get(rides[0].from), b = this.metroZi.get(rides[rides.length - 1].to);
    if (a == null || b == null) return null;
    const n = +this.metroZ[a][b];
    return n >= 2 ? 'Z' + n : null;
  }

  /** Titulo ocasional Andante necessario: aneis contados a partir da zona da 1.a validacao. */
  fare(it) {
    const rides = it.legs.filter(l => l.type === 'ride');
    if (!rides.length) return null;
    const z0 = this.zone[rides[0].from];
    const zones = new Set();
    for (const r of rides) for (const s of r.stops) zones.add(this.zone[s]);
    if (!z0 || zones.has('')) return { z: null, zones: [...zones].filter(Boolean), reason: 'zona desconhecida' };
    const d = this.zoneDistances(z0);
    let ring = 0, unknown = false;
    for (const z of zones) { if (!(z in d)) unknown = true; else ring = Math.max(ring, d[z]); }
    if (unknown) return { z: null, zones: [...zones], reason: 'adjacencia de zonas desconhecida' };
    let z = 'Z' + Math.max(2, ring + 1);
    const oficial = this.metroTitle(rides);
    if (oficial) z = oficial;
    const info = ANDANTE[z] || null;
    const fonte = oficial ? 'metro' : 'estimativa';
    const lastBoard = rides[rides.length - 1].dep;
    const span = lastBoard - rides[0].dep;
    return {
      z, zones: [...zones], origin: z0, fonte, preco: info ? info.preco : null, dur: info ? info.dur : null,
      overTime: info ? span > info.dur : false,
    };
  }

  /** proximas partidas da mesma linha/sentido na paragem de embarque, a partir de `t` */
  /** Partidas anteriores da mesma linha na mesma paragem (util em "chegar ate"). */
  prevDepartures(leg, dateIso, t, count = 2) {
    return this.nextDepartures(leg, dateIso, t - 120, 99).filter(x => x < t).slice(-count);
  }

  nextDepartures(leg, dateIso, t, count = 3) {
    const act = this._active(dateIso);
    const res = [];
    const route = this.patterns[leg.pi].r;
    const sp = this.stopPatterns[leg.from];
    for (let x = 0; x < sp.length; x += 2) {
      const pi = sp[x], pos = sp[x + 1];
      const p = this.patterns[pi];
      if (p.r !== route) continue;
      const toPos = p.s.indexOf(leg.to, pos + 1);
      if (toPos < 0) continue;
      const a = act[pi];
      for (let j = 0; j < a.ix.length; j++) {
        const tt = p.tm[a.ix[j] * p.L + pos] + a.sh[j];
        if (tt >= t && tt <= t + PERCURSO.janela_partidas_min) res.push(tt);
      }
    }
    return [...new Set(res)].sort((a, b) => a - b).slice(0, count);
  }
}

Network.prototype.scheduledSecsAt = function (stop, routeShort, dateIso) {
  const act = this._active(dateIso), out = [];
  const sp = this.stopPatterns[stop];
  for (let x = 0; x < sp.length; x += 2) {
    const pi = sp[x], pos = sp[x + 1], p = this.patterns[pi];
    if (this.routes[p.r].short.toUpperCase() !== String(routeShort).toUpperCase()) continue;
    const a = act[pi];
    for (let j = 0; j < a.ix.length; j++) out.push(this.tripSec(pi, a.ix[j], a.sh[j], pos));
  }
  return out;
};

function decodePoly(str) {
  const pts = []; let i = 0, lat = 0, lon = 0;
  while (i < str.length) {
    for (const which of [0, 1]) {
      let b, shift = 0, res = 0;
      do { b = str.charCodeAt(i++) - 63; res |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
      const v = (res & 1) ? ~(res >> 1) : (res >> 1);
      if (which === 0) lat += v; else lon += v;
    }
    pts.push([lat / 1e5, lon / 1e5]);
  }
  return pts;
}

export { Network, dist, walkMin, norm, decodePoly, ANDANTE, EGRESS_RADIUS };
