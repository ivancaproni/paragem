/**
 * MOTOR DE PERCURSOS - junta as peças.
 *
 * Este ficheiro é a porta de entrada do motor e não tem lógica própria: pede as
 * etiquetas ao algoritmo, manda montar os itinerários, aplica o tarifário e
 * arruma a lista. As decisões estão espalhadas por camadas independentes, cada
 * uma testável à parte:
 *
 *   geo.js         distâncias e texto, sem saber o que é uma paragem
 *   timetable.js   a rede como dados: paragens, padrões, calendário, horas
 *   custo.js       o que se considera melhor (raios a pé, ordem, filtros)
 *   raptor.js      o algoritmo por rondas, que pergunta tudo ao custo.js
 *   itinerario.js  etiquetas -> lista de troços legível
 *   tarifario.js   zonas e títulos Andante
 *
 * Para mudar comportamento, mexe-se no rules.js (números) ou no custo.js
 * (critérios). Só se mexe aqui para mudar a forma como as opções são pedidas.
 */
import { dist, norm, decodePoly } from './geo.js';
import { CUSTO, horaDeSair } from './custo.js';
import { Horarios, INF } from './timetable.js';
import { rondas, alvosCompletos, alvosIncompletos } from './raptor.js';
import { construir } from './itinerario.js';
import { distanciasDeZona, tituloMetro, titulo } from './tarifario.js';
import { ANDANTE } from './rules.js';

class Network extends Horarios {
  // ------------------------------------------------------------ uma pesquisa
  /**
   * Percursos a partir de uma hora de partida.
   * @param q {origin, dest: {lat, lon, stop?}, date: 'YYYY-MM-DD', time: minutos, maxTransfers?}
   * @returns itinerários completos, ou os que mais aproximam quando a rede não chega lá
   */
  route(q) {
    const custo = this.custo;
    const ctx = rondas(this, q, custo);
    const out = [];

    for (const alvo of alvosCompletos(ctx.tau, ctx.egress)) {
      const m = dist(this.lat[alvo.stop], this.lon[alvo.stop], q.dest.lat, q.dest.lon);
      out.push(this._montar(ctx, alvo.k, alvo.stop, q, { type: 'walk', m, dur: alvo.dur }));
    }
    if (out.length) return out;

    // sem ligação completa: mostra-se o que aproxima, com o troço em falta
    const vistos = new Set();
    for (const c of alvosIncompletos(this, ctx, q, custo)) {
      if (out.length >= custo.incompletoOpcoes) break;
      const it = this._montar(ctx, c.k, c.stop, q,
        { type: 'uncovered', m: c.m, dur: custo.minutosDeCarro(c.m) });
      const sig = it.legs.filter((l) => l.type === 'ride').map((l) => l.route.short).join('>');
      if (vistos.has(sig)) continue;
      vistos.add(sig); out.push(it);
    }
    return out;
  }

  _montar(ctx, k, stop, q, last) {
    const it = construir(this, ctx, k, stop, q, last, this.custo);
    it.fare = this.fare(it);
    return it;
  }

  // ------------------------------------------------------------ varias opcoes
  /** Repete a pesquisa a partir de cada partida seguinte, para dar alternativas distintas. */
  plan(q, maxOptions = CUSTO.opcoesMax) {
    if (q.arriveBy != null) return this.planArriveBy(q, q.arriveBy, maxOptions);
    const custo = this.custo;
    const seen = new Map();
    let results = [];

    // se o destino é aqui ao lado, ir a pé é uma opção como as outras
    const O = this.origem(q.origin);
    const direto = dist(O.lat, O.lon, q.dest.lat, q.dest.lon);
    if (direto <= custo.raio.destino && (O.stop == null || q.dest.stop !== O.stop)) {
      const dur = custo.minutosAPe(direto);
      results.push({
        legs: [], rides: 0, transfers: 0, depart: q.time, arrive: q.time + dur,
        finalStop: O.stop, complete: true, walkOnly: true, fare: null,
        last: { type: 'walk', m: direto, dur, lat: q.dest.lat, lon: q.dest.lon },
      });
    }

    let t = q.time;
    for (let volta = 0; volta < custo.voltasMax && results.length < maxOptions + 1; volta++) {
      const its = this.route({ ...q, time: t });
      if (!its.length) break;
      let minDep = INF;
      for (const it of its) {
        const sig = custo.assinatura(it);
        minDep = Math.min(minDep, it.depart);
        if (!seen.has(sig)) { seen.set(sig, it); results.push(it); }
      }
      if (minDep >= INF || minDep - q.time > custo.alternativasAteMin) break;
      t = minDep + 1;
    }

    results = results.filter((it) => !custo.saiEVoltaAEntrar(it));

    // mesmas linhas à mesma hora = mesmo veículo apanhado noutra paragem: fica o de menos caminhada
    const porViagem = new Map();
    for (const it of results) {
      const k = custo.chaveDaViagem(it);
      const atual = porViagem.get(k);
      if (!atual || custo.minutosAPeTotal(it) < custo.minutosAPeTotal(atual)) porViagem.set(k, it);
    }
    results = [...porViagem.values()];

    // se ir a pé é mais rápido, não mostrar transportes que chegam depois
    const aPe = results.find((r) => r.walkOnly);
    const ficam = aPe ? results.filter((r) => r.walkOnly || r.arrive < aPe.arrive) : results;
    ficam.sort(custo.ordenar);
    return ficam.slice(0, maxOptions);
  }

  /**
   * "Chegar até": procura a partida mais tardia que ainda chega a horas.
   * Faz uma pesquisa binária sobre a hora de partida (a chegada só pode piorar
   * quando se sai mais tarde) e depois recolhe as opções à volta dessa hora.
   */
  planArriveBy(q, arriveBy, maxOptions = CUSTO.opcoesMax) {
    const custo = this.custo;
    const SPAN = custo.recuoChegarAteMin;
    const base = { ...q };
    delete base.arriveBy;              // senao a chamada a plan() voltava aqui
    // Nao faz sentido mandar sair a uma hora que ja passou: quem pesquisa para hoje
    // passa em `notBefore` a hora atual.
    const cedoDemais = Number.isFinite(q.notBefore) ? q.notBefore : -INF;
    if (cedoDemais > arriveBy) return [];

    const chegadaSaindoAs = (t) => {
      let a = INF;
      for (const it of this.route({ ...base, time: t })) if (it.complete && it.arrive < a) a = it.arrive;
      return a;
    };
    let lo = Math.max(arriveBy - SPAN, cedoDemais);
    if (chegadaSaindoAs(lo) > arriveBy) return [];   // nem saindo o mais cedo possivel chega a horas
    let hi = arriveBy;
    while (hi - lo > 1) {                            // maior t com chegada <= arriveBy
      const mid = Math.floor((lo + hi) / 2);
      if (chegadaSaindoAs(mid) <= arriveBy) lo = mid; else hi = mid;
    }
    const tardia = lo;

    const seen = new Map(), out = [];
    const juntar = (its) => {
      for (const it of its) {
        if (it.arrive > arriveBy) continue;
        if (horaDeSair(it) < cedoDemais) continue;   // partida ja passada
        const sig = custo.assinatura(it);
        if (!seen.has(sig)) { seen.set(sig, it); out.push(it); }
      }
    };
    juntar(this.plan({ ...base, time: tardia }, 3));
    juntar(this.plan({ ...base, time: Math.max(arriveBy - SPAN, cedoDemais, tardia - 60) }, maxOptions + 6));

    // ir a pé pode sair à hora que quiser: ajustar para chegar mesmo a horas
    const aPe = out.find((it) => it.walkOnly);
    if (aPe) {
      aPe.depart = Math.max(arriveBy - aPe.last.dur, cedoDemais);
      aPe.arrive = aPe.depart + aPe.last.dur;
    }
    // se o transporte demora mais do que ir a pé, não vale a pena mostrá-lo
    const ficam = aPe
      ? out.filter((it) => it.walkOnly || custo.portaAPorta(it) < custo.portaAPorta(aPe))
      : out;
    ficam.sort(custo.ordenarChegarAte);
    return ficam.slice(0, maxOptions);
  }

  // ------------------------------------------------------------ tarifario
  fare(it) { return titulo(this, it); }
  zoneDistances(z0) { return distanciasDeZona(this, z0); }
  metroTitle(rides) { return tituloMetro(this, rides); }

  /** Hora a que é preciso sair da origem. */
  static leaveAt(it) { return horaDeSair(it); }
}

const walkMin = (m) => CUSTO.minutosAPe(m);
const EGRESS_RADIUS = CUSTO.raio.destino;

export { Network, Horarios, CUSTO, dist, walkMin, norm, decodePoly, ANDANTE, EGRESS_RADIUS };
