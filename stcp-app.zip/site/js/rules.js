/**
 * REGRAS DO APP - o único sítio a mexer para afinar comportamentos.
 *
 * Tudo o que aqui está é ajustável sem perceber o resto do código. Cada valor diz
 * o que faz, em que unidade está e porque tem aquele número. Depois de mudar, corra
 * `node --test testes/` para confirmar que nada partiu.
 */

/** Andar a pé: velocidade e desvio das ruas face à linha reta. */
export const A_PE = {
  velocidade_ms: 1.25,      // m/s (~4,5 km/h), passo normal de adulto
  desvio: 1.25,             // as ruas dão voltas: distância real ≈ linha reta × isto
  transbordo_m: 400,        // até onde se aceita andar entre duas paragens
  ate_a_paragem_m: 800,     // da morada de origem até às paragens candidatas
  ate_ao_destino_m: 1200,   // último troço a pé aceitável
  minimo_min: 1,            // nenhum troço a pé aparece com menos do que isto
};

/** Percursos: limites do cálculo. */
export const PERCURSO = {
  transbordos_max: 4,
  opcoes_max: 5,
  troca_na_mesma_paragem_min: 1,
  tvde_ms: 6,               // m/s (~22 km/h), estimativa do troço que a rede não cobre
  janela_partidas_min: 240, // quanto tempo à frente se procuram partidas da mesma linha
  chegar_ate_recuo_min: 240, // em "chegar até", até quanto antes se procura a partida
  fronteira_zonas_m: 3000,  // paragens seguidas mais afastadas do que isto não provam fronteira de zona

  // Procura de paragens a pé a partir de uma morada: começa no raio normal e
  // alarga enquanto não houver paragens que cheguem (zonas com pouca rede).
  acesso_raio_max_m: 2000,
  acesso_passo_m: 400,
  acesso_min_paragens: 3,

  // Quantas vezes se repete a pesquisa (a partir da partida seguinte) para
  // arranjar alternativas, e até quanto tempo à frente vale a pena ir.
  voltas_max: 6,
  alternativas_ate_min: 180,

  // Quando a rede não cobre o percurso todo: só se mostram paragens que
  // aproximem mesmo do destino, e cada transbordo extra tem de compensar.
  incompleto_aproxima: 0.75,  // ficar a mais do que isto da distância inicial não ajuda
  incompleto_por_transbordo_min: 4,
  incompleto_opcoes: 3,
};

/**
 * Tarifário Andante ocasional (preços de 2026).
 * `dur` é a validade do título em minutos, contada da 1.ª validação.
 */
export const ANDANTE = {
  Z2: { preco: 1.40, dur: 60 }, Z3: { preco: 1.85, dur: 60 }, Z4: { preco: 2.30, dur: 75 },
  Z5: { preco: 2.80, dur: 90 }, Z6: { preco: 3.25, dur: 105 }, Z7: { preco: 3.75, dur: 120 },
  Z8: { preco: 4.20, dur: 135 }, Z9: { preco: 4.65, dur: 150 },
};

/**
 * Tempo real da STCP. A API mistura no mesmo campo previsões ao vivo e horas do
 * horário, por isso é preciso decidir de que viagem é cada chegada.
 */
export const TEMPO_REAL = {
  horizonte_min: 90,        // partidas mais longe do que isto não têm dados ao vivo
  atraso_max_min: 10,       // partidas que já passaram há mais do que isto são ignoradas
  tolerancia_min: 15,       // desvio máximo face ao horário para ser a mesma viagem
  vizinhas_recuo_min: 60,   // horários a olhar à volta, para ver se outro fica mais perto
  vizinhas_max: 20,
  previsao_seg: 20,         // se a hora ao vivo bate certo com o horário (±isto), é previsão
  cache_seg: 20,            // não repetir o pedido à mesma paragem dentro deste tempo
  pedido_timeout_ms: 6000,
};

/** Interface. */
export const INTERFACE = {
  recentes: 3,
  espera_a_escrever_ms: 350, // tempo parado antes de procurar moradas
  letras_min_morada: 3,
  gps_espera_ms: 8000,       // botão atualizar: quanto se espera por uma posição nova
  gps_espera_fundo_ms: 12000,
  gps_idade_max_ms: 60000,   // posição em cache aceitável ao abrir o app
  mesma_origem_destino_m: 30,
  troco_final_visivel_m: 30, // abaixo disto não vale a pena mostrar "a pé até ao destino"
};

/**
 * Avisos de meteorologia, por ordem de importância.
 * `grupo` evita dois avisos redundantes (por exemplo, dois casacos).
 * `teste` recebe {code, snow, rain, prob, wind, gust, feels, uv} e devolve verdadeiro/falso.
 * Os limiares estão calibrados para o Porto, onde venta quase sempre; a sensação
 * térmica da Open-Meteo já inclui o arrefecimento pelo vento.
 */
export const AVISOS = [
  { id: 'trovoada', icone: 'bolt', texto: 'Trovoada', teste: (c) => c.code >= 95 },
  { id: 'neve', icone: 'snow', texto: 'Pode nevar', teste: (c) => c.snow > 0 || (c.code >= 71 && c.code <= 77) },
  { id: 'chuva', icone: 'umbrella', texto: 'Leva guarda-chuva', teste: (c) => c.rain >= 0.2 || (c.prob != null && c.prob >= 40) },
  { id: 'ventania', grupo: 'vento', icone: 'wind', texto: 'Vento muito forte', teste: (c) => c.gust >= 55 || c.wind >= 40 },
  { id: 'frio', grupo: 'casaco', icone: 'coat', texto: 'Leva casaco', teste: (c) => c.feels != null && c.feels <= 12 },
  { id: 'cortavento', grupo: 'casaco', icone: 'wind', texto: 'Leva corta-vento', teste: (c) => c.feels != null && c.feels <= 18 && (c.wind >= 25 || c.gust >= 40) },
  { id: 'calor', icone: 'water', texto: 'Calor: leva água', teste: (c) => c.feels != null && c.feels >= 28 },
  { id: 'sol', icone: 'sun', texto: 'Protetor solar', teste: (c) => c.uv >= 7 },
];

/** Avisos que se mostram a vermelho (mau tempo, não só desconforto). */
export const AVISOS_GRAVES = ['chuva', 'neve', 'trovoada'];

/** Quando a diferença entre temperatura e sensação térmica chega a isto, mostra-se as duas. */
export const MOSTRAR_SENSACAO_DIF = 3;
