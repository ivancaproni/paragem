/* Proxima Paragem - app PWA */
(function () {
  'use strict';
  const CFG = window.APP_CONFIG || {};
  const E = window.Engine;
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // ------------------------------------------------------------ armazenamento local (tolerante a falhas)
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* ignorado */ } },
  };

  const state = {
    net: null, meta: null, shapes: null,
    origin: null,   // indice da paragem
    dest: null,     // {type:'stop', stop, lat, lon, label} | {type:'place', lat, lon, label, sub}
    me: null,       // {lat, lon}
    results: [], query: null,
    proxy: store.get('proxy', CFG.REALTIME_PROXY || ''),
  };

  // ------------------------------------------------------------ hora de Lisboa
  function lisbonNow() {
    const f = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Lisbon', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
    const p = Object.fromEntries(f.formatToParts(new Date()).map(x => [x.type, x.value]));
    return { date: `${p.year}-${p.month}-${p.day}`, min: (+p.hour) * 60 + (+p.minute) };
  }
  const hhmm = (m) => { m = ((Math.round(m) % 1440) + 1440) % 1440; return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); };
  const fmtDist = (m) => m < 950 ? Math.round(m / 10) * 10 + ' m' : (m / 1000).toFixed(1).replace('.', ',') + ' km';
  const fmtDur = (m) => m < 60 ? `${Math.round(m)} min` : `${Math.floor(m / 60)} h ${String(Math.round(m % 60)).padStart(2, '0')}`;
  const euro = (v) => v == null ? '' : v.toFixed(2).replace('.', ',') + ' €';

  // ------------------------------------------------------------ icones
  const ICON = {
    stop: '<svg viewBox="0 0 24 24"><rect x="5" y="3" width="14" height="13" rx="3" fill="currentColor"/><rect x="7" y="5" width="10" height="5" rx="1" fill="#fff"/><rect x="11" y="16" width="2" height="6" fill="currentColor"/></svg>',
    pin: '<svg viewBox="0 0 24 24"><path d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12Z" fill="currentColor"/><circle cx="12" cy="10" r="2.6" fill="#fff"/></svg>',
    map: '<svg viewBox="0 0 24 24"><path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2Z M9 4v14 M15 6v14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
    loc: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4" fill="currentColor"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3" stroke="currentColor" stroke-width="2"/></svg>',
    clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    walk: '<svg viewBox="0 0 24 24"><circle cx="13" cy="4" r="2" fill="currentColor"/><path d="M10 22l2-7 3 3v6M8 12l2-4 4 1 2 4 3 1M12 15l-1-6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  };

  function badge(route, cls = '') {
    const bg = route.color ? '#' + route.color : 'var(--brand)';
    const fg = route.text ? '#' + route.text : '#fff';
    return `<span class="badge ${cls}" style="background:${bg};color:${fg}">${esc(route.short)}</span>`;
  }
  const routeColor = (r) => (r.color ? '#' + r.color : '#0f5257');

  // ------------------------------------------------------------ navegacao
  function show(view) {
    document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + view));
    window.scrollTo(0, 0);
    if (view === 'detail' && map) setTimeout(() => map.invalidateSize(), 50);
  }
  document.querySelectorAll('[data-back]').forEach(b => b.addEventListener('click', () => history.back()));
  window.addEventListener('popstate', (e) => show((e.state && e.state.view) || 'search'));
  history.replaceState({ view: 'search' }, '');
  const go = (view) => { history.pushState({ view }, ''); show(view); };

  // ------------------------------------------------------------ dados
  async function loadData() {
    const st = $('#data-status');
    try {
      const [net, meta] = await Promise.all([
        fetch('data/net.json').then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }),
        fetch('data/meta.json').then(r => r.ok ? r.json() : null).catch(() => null),
      ]);
      state.net = new E.Network(net);
      state.meta = meta;
      const now = lisbonNow();
      if (!state.net.hasService(now.date)) {
        st.textContent = 'Os horários guardados não cobrem a data de hoje. Abra o app com internet para atualizar.';
        st.classList.remove('hidden');
      }
      fetch('data/shapes.json').then(r => r.json()).then(s => { state.shapes = s; }).catch(() => {});
      renderOriginDropdown();
      updateButton();
    } catch (e) {
      st.textContent = 'Não foi possível carregar os horários da STCP (' + e.message + ').';
      st.classList.add('err'); st.classList.remove('hidden');
    }
  }

  // ------------------------------------------------------------ localizacao
  function locate() {
    if (!('geolocation' in navigator)) return;
    navigator.geolocation.getCurrentPosition(
      (p) => { state.me = { lat: p.coords.latitude, lon: p.coords.longitude }; renderOriginDropdown(); },
      () => { state.meDenied = true; renderOriginDropdown(); },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 });
  }

  // ------------------------------------------------------------ recentes
  const recent = {
    list(kind) { return store.get('recent_' + kind, []); },
    add(kind, item) {
      const l = this.list(kind).filter(x => x.key !== item.key);
      l.unshift(item); store.set('recent_' + kind, l.slice(0, 6));
    },
  };

  // ------------------------------------------------------------ origem
  const inOrigin = $('#in-origin'), ddOrigin = $('#dd-origin');
  function stopItem(i, extra = '') {
    const N = state.net;
    const lines = N.linesAt(i).slice(0, 8).map(r => badge(r, 'sm')).join('');
    return `<div class="item" data-stop="${i}"><div class="ic">${ICON.stop}</div>
      <div class="tx"><div class="t1">${esc(N.stopName[i])}</div><div class="t2">${esc(N.stopCode[i])}${N.zone[i] ? ' · ' + esc(N.zone[i]) : ''} <span class="lines">${lines}</span></div></div>
      ${extra ? `<div class="meta">${extra}</div>` : ''}</div>`;
  }
  function renderOriginDropdown() {
    const N = state.net;
    if (!N) { ddOrigin.innerHTML = '<div class="spinner"></div>'; return; }
    if (state.origin != null && document.activeElement !== inOrigin) { ddOrigin.innerHTML = ''; return; }
    const q = inOrigin.value.trim();
    let html = '';
    if (q && state.origin == null) {
      const r = N.search(q, 25);
      html = r.length ? r.map(i => stopItem(i)).join('') : '<div class="small" style="padding:8px">Nenhuma paragem encontrada.</div>';
    } else {
      if (state.me) {
        const near = N.nearest(state.me.lat, state.me.lon, 4);
        html += '<div class="dd-head"><span>Perto de si</span></div>' + near.map(x => stopItem(x.i, fmtDist(x.m))).join('');
      } else if (state.meDenied) {
        html += '<div class="small" style="padding:6px 4px">Ative a localização (Definições › Privacidade › Serviços de localização › Safari) para ver as paragens mais próximas.</div>';
      } else {
        html += '<div class="dd-head"><span>Perto de si</span></div><div class="small" style="padding:6px 4px">A obter a sua localização…</div>';
      }
      const rec = recent.list('origin').filter(x => N.stopCode.includes(x.key));
      if (rec.length) html += '<div class="dd-head"><span>Recentes</span></div>' + rec.slice(0, 4).map(x => stopItem(N.stopCode.indexOf(x.key))).join('');
    }
    ddOrigin.innerHTML = html;
  }
  inOrigin.addEventListener('input', () => { state.origin = null; inOrigin.classList.remove('chosen'); renderOriginDropdown(); updateButton(); });
  inOrigin.addEventListener('focus', () => { if (state.origin != null) inOrigin.select(); renderOriginDropdown(); });
  ddOrigin.addEventListener('click', (e) => {
    const it = e.target.closest('[data-stop]'); if (!it) return;
    setOrigin(+it.dataset.stop);
  });
  function setOrigin(i) {
    const N = state.net;
    state.origin = i;
    inOrigin.value = `${N.stopName[i]} (${N.stopCode[i]})`;
    inOrigin.classList.add('chosen');
    inOrigin.blur(); ddOrigin.innerHTML = '';
    recent.add('origin', { key: N.stopCode[i] });
    updateButton();
    if (!state.dest) setTimeout(() => $('#in-dest').focus(), 50);
  }

  // ------------------------------------------------------------ destino
  const inDest = $('#in-dest'), ddDest = $('#dd-dest');
  let geoTimer = null, geoSeq = 0, geoResults = [];
  function renderDestDropdown() {
    const N = state.net; if (!N) return;
    const q = inDest.value.trim();
    let html = '';
    if (state.dest && document.activeElement !== inDest) { ddDest.innerHTML = ''; return; }
    if (!q || state.dest) {
      html += `<div class="item" data-pick="map"><div class="ic">${ICON.map}</div><div class="tx"><div class="t1">Escolher no mapa</div></div></div>`;
      const rec = recent.list('dest');
      if (rec.length) html += '<div class="dd-head"><span>Recentes</span></div>' + rec.map((x, k) =>
        `<div class="item" data-recent="${k}"><div class="ic">${x.type === 'stop' ? ICON.stop : ICON.clock}</div><div class="tx"><div class="t1">${esc(x.label)}</div><div class="t2">${esc(x.sub || '')}</div></div></div>`).join('');
      ddDest.innerHTML = html; return;
    }
    const stops = N.search(q, 5);
    if (stops.length) html += '<div class="dd-head"><span>Paragens</span></div>' + stops.map(i => stopItem(i)).join('');
    html += '<div class="dd-head"><span>Moradas e locais</span></div>';
    if (geoResults.length) {
      html += geoResults.map((g, k) => `<div class="item" data-geo="${k}"><div class="ic">${ICON.pin}</div><div class="tx"><div class="t1">${esc(g.label)}</div><div class="t2">${esc(g.sub)}</div></div></div>`).join('');
    } else {
      html += `<div class="small" style="padding:6px 4px">${state.geoLoading ? 'A procurar…' : (q.length < 3 ? 'Escreva pelo menos 3 letras' : 'Sem moradas encontradas. Experimente “Escolher no mapa”.')}</div>`;
    }
    html += `<div class="item" data-pick="map"><div class="ic">${ICON.map}</div><div class="tx"><div class="t1">Escolher no mapa</div></div></div>`;
    ddDest.innerHTML = html;
  }
  inDest.addEventListener('input', () => {
    state.dest = null; inDest.classList.remove('chosen'); geoResults = []; updateButton();
    clearTimeout(geoTimer);
    const q = inDest.value.trim();
    state.geoLoading = q.length >= 3;
    renderDestDropdown();
    if (q.length >= 3) geoTimer = setTimeout(() => geocode(q), 350);
  });
  inDest.addEventListener('focus', () => { if (state.dest) inDest.select(); renderDestDropdown(); });
  ddDest.addEventListener('click', (e) => {
    const s = e.target.closest('[data-stop]'), g = e.target.closest('[data-geo]'), p = e.target.closest('[data-pick]'), r = e.target.closest('[data-recent]');
    const N = state.net;
    if (s) { const i = +s.dataset.stop; setDest({ type: 'stop', stop: i, lat: N.lat[i], lon: N.lon[i], label: N.stopName[i], sub: 'Paragem ' + N.stopCode[i], key: N.stopCode[i] }); }
    else if (g) setDest(geoResults[+g.dataset.geo]);
    else if (r) {
      const x = recent.list('dest')[+r.dataset.recent];
      if (x.type === 'stop') { const i = N.stopCode.indexOf(x.key); if (i >= 0) setDest({ ...x, stop: i, lat: N.lat[i], lon: N.lon[i] }); }
      else setDest(x);
    }
    else if (p) openPickMap();
  });
  function setDest(d) {
    state.dest = d;
    inDest.value = d.label;
    inDest.classList.add('chosen');
    inDest.blur(); ddDest.innerHTML = '';
    const { stop, ...save } = d;
    recent.add('dest', { ...save, key: d.key || (d.lat.toFixed(5) + ',' + d.lon.toFixed(5)) });
    updateButton();
  }

  async function geocode(q) {
    const seq = ++geoSeq;
    const [w, s, e, n] = CFG.BBOX;
    let res = [];
    try {
      const u = `${CFG.GEOCODER}?q=${encodeURIComponent(q)}&limit=6&bbox=${w},${s},${e},${n}` +
        (state.me ? `&lat=${state.me.lat}&lon=${state.me.lon}` : '&lat=41.15&lon=-8.61');
      const j = await (await fetch(u)).json();
      res = (j.features || []).map(f => {
        const p = f.properties || {};
        const street = [p.street, p.housenumber].filter(Boolean).join(' ');
        const label = p.name || street || p.city || q;
        const sub = [p.name && street ? street : '', p.district || p.locality, p.city, p.postcode].filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(', ');
        const [lon, lat] = f.geometry.coordinates;
        return { type: 'place', lat, lon, label, sub };
      });
    } catch { /* tenta o alternativo */ }
    if (!res.length && CFG.GEOCODER_FALLBACK) {
      try {
        const u = `${CFG.GEOCODER_FALLBACK}?format=jsonv2&limit=6&countrycodes=pt&bounded=1&viewbox=${w},${n},${e},${s}&q=${encodeURIComponent(q)}`;
        const j = await (await fetch(u, { headers: { 'Accept-Language': 'pt-PT' } })).json();
        res = j.map(x => ({ type: 'place', lat: +x.lat, lon: +x.lon, label: x.name || x.display_name.split(',')[0], sub: x.display_name.split(',').slice(1, 4).join(',').trim() }));
      } catch { /* sem resultados */ }
    }
    if (seq !== geoSeq || state.dest) return;
    geoResults = res; state.geoLoading = false; renderDestDropdown();
  }

  // ------------------------------------------------------------ escolher no mapa
  let pickMap = null, pickMarker = null;
  function openPickMap() {
    $('#pick-map-wrap').classList.remove('hidden'); $('.steps').classList.add('hidden');
    inDest.blur();
    if (!pickMap) {
      pickMap = L.map('pick-map', { zoomControl: false }).setView(state.me ? [state.me.lat, state.me.lon] : [41.1496, -8.6109], 14);
      L.tileLayer(CFG.TILES, { attribution: CFG.TILES_ATTR, maxZoom: 19 }).addTo(pickMap);
      pickMap.on('click', (e) => {
        if (pickMarker) pickMarker.remove();
        pickMarker = L.marker(e.latlng, { icon: L.divIcon({ className: '', html: '<div class="end-pin"></div>', iconSize: [22, 22], iconAnchor: [11, 22] }) }).addTo(pickMap);
        setTimeout(() => {
          closePickMap();
          setDest({ type: 'place', lat: e.latlng.lat, lon: e.latlng.lng, label: 'Ponto no mapa', sub: e.latlng.lat.toFixed(5) + ', ' + e.latlng.lng.toFixed(5) });
          reverseName(e.latlng.lat, e.latlng.lng);
        }, 250);
      });
    }
    setTimeout(() => pickMap.invalidateSize(), 50);
  }
  function closePickMap() { $('#pick-map-wrap').classList.add('hidden'); $('.steps').classList.remove('hidden'); }
  $('#btn-pick-cancel').addEventListener('click', closePickMap);
  async function reverseName(lat, lon) {
    try {
      const j = await (await fetch(`https://photon.komoot.io/reverse?lat=${lat}&lon=${lon}`)).json();
      const p = (j.features && j.features[0] && j.features[0].properties) || {};
      const name = p.name || [p.street, p.housenumber].filter(Boolean).join(' ');
      if (name && state.dest && state.dest.lat === lat) { state.dest.label = name; inDest.value = name; }
    } catch { /* fica 'Ponto no mapa' */ }
  }

  // ------------------------------------------------------------ outros controlos
  document.querySelectorAll('[data-clear]').forEach(b => b.addEventListener('click', () => {
    if (b.dataset.clear === 'origin') { state.origin = null; inOrigin.value = ''; inOrigin.classList.remove('chosen'); inOrigin.focus(); renderOriginDropdown(); }
    else { state.dest = null; inDest.value = ''; inDest.classList.remove('chosen'); inDest.focus(); renderDestDropdown(); }
    updateButton();
  }));
  $('#btn-swap').addEventListener('click', () => {
    const N = state.net; if (!N) return;
    const o = state.origin, d = state.dest;
    if (d && d.type === 'stop') {
      if (o != null) setDest({ type: 'stop', stop: o, lat: N.lat[o], lon: N.lon[o], label: N.stopName[o], sub: 'Paragem ' + N.stopCode[o], key: N.stopCode[o] });
      else { state.dest = null; inDest.value = ''; inDest.classList.remove('chosen'); }
      setOrigin(d.stop);
    } else if (d && d.type === 'place') {
      // origem tem de ser paragem: usa a mais proxima do destino
      const n = N.nearest(d.lat, d.lon, 1)[0];
      if (o != null) setDest({ type: 'stop', stop: o, lat: N.lat[o], lon: N.lon[o], label: N.stopName[o], sub: 'Paragem ' + N.stopCode[o], key: N.stopCode[o] });
      if (n) setOrigin(n.i);
    }
  });
  $('#sel-when').addEventListener('change', (e) => {
    const inp = $('#in-when');
    if (e.target.value === 'at') {
      const now = lisbonNow();
      inp.value = `${now.date}T${hhmm(now.min)}`;
      inp.classList.remove('hidden');
    } else inp.classList.add('hidden');
  });
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#step-origin') && state.origin != null) ddOrigin.innerHTML = '';
    if (!e.target.closest('#step-dest') && state.dest) ddDest.innerHTML = '';
  });
  function updateButton() { $('#btn-search').disabled = !(state.net && state.origin != null && state.dest); }

  // ------------------------------------------------------------ pesquisa
  $('#btn-search').addEventListener('click', runSearch);
  $('#btn-refresh').addEventListener('click', () => runSearch(true));

  function queryTime() {
    if ($('#sel-when').value === 'at' && $('#in-when').value) {
      const [d, t] = $('#in-when').value.split('T');
      const [h, m] = t.split(':').map(Number);
      return { date: d, min: h * 60 + m, now: false };
    }
    return { ...lisbonNow(), now: true };
  }

  function runSearch(stay) {
    const N = state.net;
    if (!N || state.origin == null || !state.dest) return;
    if (state.dest.type === 'stop' && state.dest.stop === state.origin) { alert('A origem e o destino são a mesma paragem.'); return; }
    const t = queryTime();
    state.query = { t, origin: state.origin, dest: state.dest };
    $('#res-title').innerHTML = `${esc(N.stopName[state.origin])} → ${esc(state.dest.label)}<small>${t.now ? 'Partida agora' : 'Partida ' + t.date.split('-').reverse().join('/') + ' ' + hhmm(t.min)}</small>`;
    $('#res-list').innerHTML = '<div class="spinner"></div>';
    if (stay !== true) go('results');
    setTimeout(() => {
      let res = [];
      try {
        res = N.plan({ origin: state.origin, dest: { lat: state.dest.lat, lon: state.dest.lon, stop: state.dest.type === 'stop' ? state.dest.stop : null }, date: t.date, time: t.min, maxTransfers: 4 });
      } catch (e) { console.error(e); }
      state.results = res;
      renderResults();
      fetchRealtimeForResults();
    }, 30);
  }

  function chainHtml(it) {
    const parts = [];
    it.legs.forEach(l => {
      if (l.type === 'ride') parts.push(badge(l.route));
      else if (l.type === 'walk') parts.push(`<span class="walk">${ICON.walk}${l.dur}′</span>`);
    });
    if (it.last.type === 'walk' && it.last.dur > 0) parts.push(`<span class="walk">${ICON.walk}${it.last.dur}′</span>`);
    if (it.last.type === 'uncovered') parts.push(`<span class="gap">+ ${fmtDist(it.last.m)} sem STCP</span>`);
    return parts.join('<span class="sep">›</span>');
  }

  function fareHtml(f) {
    if (!f) return '';
    if (!f.z) return `<span class="tag pv" title="${esc(f.reason)}">Zona ?</span>`;
    return `<span class="tag zone">Andante ${f.z}</span><span>${euro(f.preco)} · ${f.zones.join(', ')}</span>`;
  }

  function renderResults() {
    const N = state.net, list = $('#res-list');
    const res = state.results, t = state.query.t;
    if (!res.length) {
      list.innerHTML = `<div class="empty">Não encontrei ligações STCP a partir desta paragem nas próximas horas.<br><br>
        Experimente outra paragem de origem próxima ou outra hora.</div>`;
      return;
    }
    let html = '';
    if (res.every(r => !r.complete)) {
      html += `<div class="infoline">A STCP não chega a menos de ${fmtDist(E.EGRESS_RADIUS)} deste destino. Mostro até onde o autocarro o leva; o resto do caminho aparece a vermelho no mapa (a pé, TVDE, metro ou comboio).</div>`;
    }
    res.forEach((it, k) => {
      const first = it.legs.find(l => l.type === 'ride');
      const total = it.arrive - t.min;
      if (it.walkOnly) {
        html += `<div class="opt" data-opt="${k}"><div class="opt-top"><div class="chain"><span class="walk">${ICON.walk} Ir a pé · ${fmtDist(it.last.m)}</span></div>
          <div class="dur">${fmtDur(total)}<small>chega ${hhmm(it.arrive)}</small></div></div></div>`;
        return;
      }
      const nextTimes = N.nextDepartures(first, t.date, t.min, 4);
      const walkBefore = it.legs[0].type === 'walk' ? it.legs[0].dur : 0;
      const nextBus = nextTimes.find(x => x >= t.min + walkBefore) ?? first.dep;
      const later = nextTimes.filter(x => x > nextBus).slice(0, 2).map(hhmm).join(', ');
      html += `<div class="opt" data-opt="${k}">
        <div class="opt-top"><div class="chain">${chainHtml(it)}</div>
          <div class="dur">${it.complete ? '' : '≈ '}${fmtDur(total)}<small>${it.complete ? 'chega' : 'estimativa c/ TVDE'} ${hhmm(it.arrive)}</small></div></div>
        <div class="next" id="next-${k}">
          <span class="big">${hhmm(nextBus)}</span>
          <span class="muted">${t.now ? 'em ' + Math.max(0, nextBus - t.min) + ' min' : ''}</span>
          <span class="tag pv">Previsão</span>
        </div>
        <div class="later">${walkBefore ? `Caminhe ${walkBefore} min até ${esc(N.stopName[first.from])}. ` : ''}Linha ${esc(first.route.short)} → ${esc(first.head)}${later ? ` · seguintes: ${later}` : ''}</div>
        <div class="opt-foot">${fareHtml(it.fare)}<span>· ${it.transfers ? it.transfers + (it.transfers > 1 ? ' transbordos' : ' transbordo') : 'direto'}</span></div>
        ${it.fare && it.fare.overTime ? `<div class="warnline">O percurso excede ${fmtDur(it.fare.dur)} de validade do ${it.fare.z}: a última validação tem de ser feita dentro desse tempo, senão será descontado outro título.</div>` : ''}
        ${!it.complete ? `<div class="warnline">Faltam ${fmtDist(it.last.m)} até ao destino fora da rede STCP. Toque para ver no mapa e escolher como continuar.</div>` : ''}
      </div>`;
    });
    list.innerHTML = html;
    list.querySelectorAll('[data-opt]').forEach(el => el.addEventListener('click', () => openDetail(+el.dataset.opt)));
  }

  // ------------------------------------------------------------ tempo real
  const rtCache = new Map();
  async function getRealtime(code) {
    const c = rtCache.get(code);
    if (c && Date.now() - c.t < 20000) return c.data;
    const bases = [];
    if (state.proxy) bases.push(state.proxy.replace(/\/+$/, '') + '/rt/' + encodeURIComponent(code));
    else bases.push('https://stcp.pt/api/stops/' + encodeURIComponent(code) + '/realtime'); // so funciona se a STCP permitir CORS
    for (const u of bases) {
      try {
        const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 6000);
        const r = await fetch(u, { signal: ctl.signal }); clearTimeout(to);
        if (!r.ok) continue;
        const data = await r.json();
        rtCache.set(code, { t: Date.now(), data });
        return data;
      } catch { /* sem tempo real */ }
    }
    rtCache.set(code, { t: Date.now(), data: null });
    return null;
  }

  const ALIAS = { '107': 'ZC', 'ZC': '107' };
  /** Devolve {min, realtime} para a linha/sentido na paragem, ou null */
  function matchArrival(data, leg, minMinutes) {
    if (!data) return null;
    const arr = Array.isArray(data) ? data : (data.arrivals || data.results || data.data || []);
    const src = String(data.data_source || data.source || '').toLowerCase();
    const want = String(leg.route.short).toUpperCase();
    const head = E.norm(leg.head);
    const cands = arr.filter(a => {
      const rs = String(a.route_short_name ?? a.line ?? a.route ?? '').toUpperCase();
      const rl = String(a.route_long_name ?? '').toUpperCase();
      return rs === want || rl === want || ALIAS[want] === rs;
    }).map(a => ({ a, min: +(a.arrival_minutes ?? a.minutes ?? a.eta_minutes ?? NaN) }))
      .filter(x => Number.isFinite(x.min) && x.min >= 0 && x.min >= minMinutes);
    if (!cands.length) return null;
    // preferir o mesmo sentido (destino parecido)
    const same = cands.filter(x => { const h = E.norm(x.a.trip_headsign || x.a.headsign || x.a.destination || ''); return !h || !head || h.includes(head) || head.includes(h) || h.split(' ')[0] === head.split(' ')[0]; });
    const pick = (same.length ? same : cands).sort((a, b) => a.min - b.min)[0];
    return { min: pick.min, realtime: isRealtime(pick.a, src), delay: pick.a.delay_minutes };
  }
  function isRealtime(a, src) {
    for (const k of ['realtime', 'is_realtime', 'real_time', 'live', 'estimated']) if (typeof a[k] === 'boolean') return a[k];
    const s = String(a.data_source || a.source || a.type || src || '').toLowerCase();
    if (/sched|hor[aá]rio|plan|timetable|static|gtfs(?!.?rt)|teor/.test(s)) return false;
    return true; // endpoint de tempo real sem indicacao contraria
  }

  async function fetchRealtimeForResults() {
    const t = state.query.t;
    if (!t.now) return; // tempo real so faz sentido para "agora"
    const N = state.net;
    await Promise.all(state.results.map(async (it, k) => {
      if (it.walkOnly) return;
      const leg = it.legs.find(l => l.type === 'ride');
      const walkBefore = it.legs[0].type === 'walk' ? it.legs[0].dur : 0;
      const data = await getRealtime(N.stopCode[leg.from]);
      const m = matchArrival(data, leg, walkBefore);
      const el = document.getElementById('next-' + k);
      if (!el || !m) return;
      const when = lisbonNow().min + m.min;
      el.innerHTML = `<span class="big">${m.min === 0 ? 'A chegar' : m.min + ' min'}</span><span class="muted">≈ ${hhmm(when)}</span>
        <span class="tag ${m.realtime ? 'rt' : 'pv'}">${m.realtime ? 'Tempo real' : 'Previsão'}</span>
        ${m.delay != null && Math.round(m.delay) !== 0 ? `<span class="small">${m.delay > 0 ? '+' : ''}${Math.round(m.delay)} min</span>` : ''}`;
      it.rt = m;
    }));
  }

  // ------------------------------------------------------------ detalhe + mapa
  let map = null, layer = null;
  function ensureMap() {
    if (map) return;
    map = L.map('map', { zoomControl: false, attributionControl: false });
    L.control.attribution({ position: 'topright', prefix: false }).addTo(map);
    L.tileLayer(CFG.TILES, { attribution: CFG.TILES_ATTR, maxZoom: 19, subdomains: 'abcd' }).addTo(map);
    layer = L.layerGroup().addTo(map);
  }
  function shapeSlice(leg) {
    const N = state.net;
    const pat = N.patterns[leg.pi];
    const pts = leg.stops.map(s => [N.lat[s], N.lon[s]]);
    if (!state.shapes || pat.sh < 0 || !state.shapes[pat.sh]) return pts;
    const line = E.decodePoly(state.shapes[pat.sh]);
    const nearestIdx = (p, from) => {
      let bi = from, bd = Infinity;
      for (let i = from; i < line.length; i++) { const d = (line[i][0] - p[0]) ** 2 + (line[i][1] - p[1]) ** 2; if (d < bd) { bd = d; bi = i; } }
      return bi;
    };
    const a = nearestIdx(pts[0], 0), b = nearestIdx(pts[pts.length - 1], a);
    if (b <= a) return pts;
    return [pts[0], ...line.slice(a, b + 1), pts[pts.length - 1]];
  }
  const pin = (cls, color) => L.divIcon({ className: '', html: `<div class="${cls}" style="--c:${color || ''}"></div>`, iconSize: cls === 'end-pin' ? [22, 22] : [14, 14], iconAnchor: cls === 'end-pin' ? [11, 22] : [7, 7] });

  function openDetail(k) {
    const N = state.net, it = state.results[k], t = state.query.t, dest = state.query.dest;
    go('detail');
    ensureMap();
    layer.clearLayers();
    const bounds = [];
    const addLine = (pts, style) => { L.polyline(pts, style).addTo(layer); pts.forEach(p => bounds.push(p)); };
    const o = state.query.origin;
    L.marker([N.lat[o], N.lon[o]], { icon: pin('stop-pin', '#0f5257') }).addTo(layer).bindPopup(esc(N.stopName[o]));
    bounds.push([N.lat[o], N.lon[o]]);

    let tl = '';
    let clock = t.min;
    if (it.walkOnly) {
      addLine([[N.lat[o], N.lon[o]], [dest.lat, dest.lon]], { color: '#5d6b69', weight: 4, dashArray: '2 8' });
    }
    it.legs.forEach((l) => {
      if (l.type === 'walk') {
        addLine([[N.lat[l.from], N.lon[l.from]], [N.lat[l.to], N.lon[l.to]]], { color: '#5d6b69', weight: 4, dashArray: '2 8' });
        tl += `<li class="walk"><span class="node"></span><div><span class="when-t">${hhmm(clock)}</span><span class="what">A pé até ${esc(N.stopName[l.to])}</span></div>
          <div class="sub">${l.dur} min · ${fmtDist(l.m)}</div></li>`;
        clock += l.dur;
      } else {
        const c = routeColor(l.route);
        addLine(shapeSlice(l), { color: c, weight: 6, opacity: .9 });
        l.stops.forEach((s, i) => { if (i === 0 || i === l.stops.length - 1) L.marker([N.lat[s], N.lon[s]], { icon: pin('stop-pin', c) }).addTo(layer).bindPopup(esc(N.stopName[s] + ' (' + N.stopCode[s] + ')')); });
        const pat = N.patterns[l.pi], prof = pat.profiles[l.prof];
        const inter = l.stops.map((s, i) => `<li>${hhmm(l.start + prof[l.boardPos + i])} ${esc(N.stopName[s])}${N.zone[s] ? ' · ' + esc(N.zone[s]) : ''}</li>`).join('');
        const rt = (it.rt && l === it.legs.find(x => x.type === 'ride')) ? `<span class="tag ${it.rt.realtime ? 'rt' : 'pv'}">${it.rt.realtime ? 'Tempo real: ' + it.rt.min + ' min' : 'Previsão'}</span>` : '<span class="tag pv">Previsão</span>';
        tl += `<li style="--c:${c}"><span class="node"></span><div><span class="when-t">${hhmm(l.dep)}</span>${badge(l.route)} <span class="what">${esc(N.stopName[l.from])}</span> ${rt}</div>
          <div class="sub">Direção ${esc(l.head)} · ${l.stops.length - 1} paragens · ${l.arr - l.dep} min</div>
          <details><summary>Ver paragens</summary><ol>${inter}</ol></details></li>
          <li style="--c:${c}" class="${(() => { const nx = it.legs[it.legs.indexOf(l) + 1]; return nx ? (nx.type === 'walk' ? 'walk' : '') : (it.last.type === 'uncovered' ? 'gap' : (dest.type === 'stop' && dest.stop === l.to ? '' : 'walk')); })()}"><span class="node"></span><div><span class="when-t">${hhmm(l.arr)}</span><span class="what">Sair em ${esc(N.stopName[l.to])}</span></div>
          <div class="sub">${esc(N.stopCode[l.to])}${N.zone[l.to] ? ' · zona ' + esc(N.zone[l.to]) : ''}</div></li>`;
        clock = l.arr;
      }
    });

    // ultimo troco
    const fs = it.walkOnly ? o : it.finalStop;
    const from = [N.lat[fs], N.lon[fs]], to = [dest.lat, dest.lon];
    const ll = `${from[0]},${from[1]}`, dl = `${to[0]},${to[1]}`;
    const links = `
      <a href="https://maps.apple.com/?saddr=${ll}&daddr=${dl}&dirflg=w" target="_blank" rel="noopener">A pé (Apple Mapas)</a>
      <a href="https://maps.apple.com/?saddr=${ll}&daddr=${dl}&dirflg=r" target="_blank" rel="noopener">Metro/comboio (Apple Mapas)</a>
      <a href="https://www.google.com/maps/dir/?api=1&origin=${ll}&destination=${dl}&travelmode=transit" target="_blank" rel="noopener">Google Maps</a>
      <a href="https://m.uber.com/ul/?action=setPickup&pickup[latitude]=${from[0]}&pickup[longitude]=${from[1]}&dropoff[latitude]=${to[0]}&dropoff[longitude]=${to[1]}" target="_blank" rel="noopener">TVDE (Uber)</a>`;
    if (dest.type !== 'stop' || dest.stop !== fs) {
      if (it.last.type === 'uncovered') {
        addLine([from, to], { color: '#b3261e', weight: 5, dashArray: '8 8' });
        tl += `<li class="gap" style="--c:#b3261e"><span class="node"></span><div><span class="what">Troço sem STCP: ${fmtDist(it.last.m)} em linha reta</span></div>
          <div class="sub">Continue a pé, de TVDE, metro ou comboio:</div><div class="actions">${links}</div></li>`;
      } else if (it.last.m > 30) {
        addLine([from, to], { color: '#5d6b69', weight: 4, dashArray: '2 8' });
        tl += `<li class="walk"><span class="node"></span><div><span class="when-t">${hhmm(clock)}</span><span class="what">A pé até ao destino</span></div>
          <div class="sub">${it.last.dur} min · ${fmtDist(it.last.m * 1.25)}</div><div class="actions">${links.split('</a>')[0]}</a></div></li>`;
      }
    }
    L.marker(to, { icon: pin('end-pin') }).addTo(layer).bindPopup(esc(dest.label));
    bounds.push(to);
    const arrivedAtStop = dest.type === 'stop' && dest.stop === fs && !it.walkOnly;
    if (!arrivedAtStop) tl += `<li><span class="node" style="border-color:var(--accent)"></span><div><span class="when-t">${hhmm(it.arrive)}</span><span class="what">${esc(dest.label)}</span></div></li>`;
    if (state.me) L.marker([state.me.lat, state.me.lon], { icon: L.divIcon({ className: '', html: '<div class="me-pin"></div>', iconSize: [16, 16], iconAnchor: [8, 8] }) }).addTo(layer);

    const f = it.fare;
    $('#detail-sheet').innerHTML = `
      <div class="sum"><b style="font-size:20px">${fmtDur(it.arrive - t.min)}</b><span class="muted">chega ${hhmm(it.arrive)}</span>
        ${f && f.z ? `<span class="tag zone">Andante ${f.z}</span><span class="small">${euro(f.preco)} · validade ${fmtDur(f.dur)}</span>` : f ? '<span class="tag pv">Zona ?</span>' : ''}</div>
      ${f && f.z ? `<div class="small" style="margin:-4px 0 10px">Zonas atravessadas: ${f.zones.join(', ')} (1.ª validação em ${esc(f.origin)}). Estimativa pelas zonas das paragens; confirme no mapa de zonas Andante.</div>` : ''}
      <ul class="tl">${tl}</ul>`;
    setTimeout(() => { map.invalidateSize(); map.fitBounds(bounds, { padding: [30, 30], maxZoom: 16 }); }, 80);
  }

  // ------------------------------------------------------------ definicoes
  $('#btn-settings').addEventListener('click', () => {
    $('#in-proxy').value = state.proxy || '';
    const m = state.meta;
    $('#data-info').innerHTML = m ? `<p>Horários gerados em ${new Date(m.generated).toLocaleString('pt-PT')} · válidos até ${m.calendar_to.split('-').reverse().join('/')}<br>
      ${m.stops} paragens · ${m.patterns} variantes de linha · ${m.trips} viagens · ${m.stops_with_zone} paragens com zona Andante</p>` : '';
    $('#settings').classList.remove('hidden');
  });
  $('#btn-settings-close').addEventListener('click', () => {
    state.proxy = $('#in-proxy').value.trim();
    store.set('proxy', state.proxy);
    rtCache.clear();
    $('#settings').classList.add('hidden');
  });
  $('#settings').addEventListener('click', (e) => { if (e.target.id === 'settings') $('#settings').classList.add('hidden'); });
  $('#btn-test-proxy').addEventListener('click', async () => {
    const out = $('#proxy-out'); out.classList.remove('hidden'); out.textContent = 'A testar…';
    const prev = state.proxy; state.proxy = $('#in-proxy').value.trim(); rtCache.clear();
    const code = $('#in-test-stop').value.trim().toUpperCase() || 'BCM1';
    const d = await getRealtime(code);
    state.proxy = prev;
    out.textContent = d ? 'OK ✓\n' + JSON.stringify(d, null, 1).slice(0, 1500) : 'Sem resposta. Verifique o endereço do proxy (deve terminar em .workers.dev).';
  });
  $('#btn-clear-recent').addEventListener('click', () => { store.set('recent_origin', []); store.set('recent_dest', []); renderOriginDropdown(); });

  // ------------------------------------------------------------ arranque
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
  loadData();
  locate();
})();
