/**
 * Próxima Paragem - ponto de entrada.
 *
 * Aqui só se liga o que está nos outros módulos: carregar os dados, ouvir os botões,
 * lançar a pesquisa e arrancar. Nada de regras nem de desenho de ecrã.
 */
import { CFG, $, state, store, recentes } from './state.js';
import { esc, hhmm, dataPt, lisbonNow } from './format.js';
import { INTERFACE } from './rules.js';
import * as E from './engine.js';
import { iniciarNavegacao, go } from './navigation.js';
import {
  fields, quandoMudar, locate, locateNow, mePlace, setField, clearField,
  renderDD, renderOriginDropdown,
} from './fields.js';
import {
  renderResults, fetchRealtimeForResults, fetchWeatherForResults,
  obterTempoReal, limparCacheTempoReal,
} from './view-results.js';

/** O botão Buscar só liga quando há dados, origem e destino. */
function updateButton() { $('#btn-search').disabled = !(state.net && state.origin && state.dest); }
quandoMudar(updateButton);

// ------------------------------------------------------------ dados

async function loadData() {
  const st = $('#data-status');
  try {
    const [net, meta] = await Promise.all([
      fetch('data/net.json').then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }),
      fetch('data/meta.json').then(r => r.ok ? r.json() : null).catch(() => null),
    ]);
    state.net = new E.Network(net);
    state.meta = meta;
    const now = lisbonNow();
    if (!state.net.hasService(now.date)) {
      st.textContent = 'Os horários guardados não cobrem a data de hoje. Abra o app com internet para atualizar.';
      st.classList.remove('hidden');
    }
    fetch('data/shapes.json').then(r => r.json()).then(s => { state.shapes = s; }).catch(() => {});
    renderOriginDropdown();
    updateButton();
  } catch (e) {
    st.textContent = 'Não foi possível carregar os horários da STCP (' + e.message + ').';
    st.classList.add('err'); st.classList.remove('hidden');
  }
}


// ------------------------------------------------------------ controlos
document.querySelectorAll('[data-clear]').forEach(b => b.addEventListener('click', () => clearField(b.dataset.clear, true)));
$('#btn-swap').addEventListener('click', () => {
  const o = fields.origin.sel, d = fields.dest.sel;
  if (d) setField('origin', d, { noRecent: true, noFocus: true }); else clearField('origin');
  if (o) setField('dest', o, { noRecent: true }); else clearField('dest');
});
$('#sel-when').addEventListener('change', (e) => {
  const inp = $('#in-when');
  if (e.target.value === 'now') { inp.classList.add('hidden'); return; }
  const now = lisbonNow();
  // "chegar ate" comeca com uma hora daqui a uma hora, que e o caso normal
  const min = e.target.value === 'by' ? now.min + 60 : now.min;
  inp.value = `${now.date}T${hhmm(Math.min(min, 23 * 60 + 59))}`;
  inp.classList.remove('hidden');
});
document.addEventListener('click', (e) => {
  Object.values(fields).forEach(F => { if (!e.target.closest(F.step) && F.sel) F.dd.innerHTML = ''; });
});
// ------------------------------------------------------------ pesquisa
$('#btn-search').addEventListener('click', () => runSearch(false));
$('#btn-refresh').addEventListener('click', async () => {
  const btn = $('#btn-refresh');
  limparCacheTempoReal();   // atualizar tem de ir mesmo buscar dados novos
  // se a origem e a posicao atual, ler o GPS outra vez: pode ja estar na paragem
  if (state.origin && state.origin.key === 'me') {
    btn.classList.add('busy');
    await locateNow();
    btn.classList.remove('busy');
  }
  runSearch(true);
});

function queryTime() {
  const modo = $('#sel-when').value;
  if ((modo === 'at' || modo === 'by') && $('#in-when').value) {
    const [d, t] = $('#in-when').value.split('T');
    const [h, m] = t.split(':').map(Number);
    return { date: d, min: h * 60 + m, now: false, by: modo === 'by' };
  }
  return { ...lisbonNow(), now: true, by: false };
}

export function runSearch(stay) {
  const N = state.net;
  if (!N || !state.origin || !state.dest) return;
  if (state.origin.key === 'me' && state.me) state.origin = fields.origin.sel = mePlace();
  if (E.dist(state.origin.lat, state.origin.lon, state.dest.lat, state.dest.lon) < INTERFACE.mesma_origem_destino_m) { alert('A origem e o destino são o mesmo local.'); return; }
  const t = queryTime();
  state.query = { t, origin: state.origin, dest: state.dest };
  const quando = t.now ? 'Partida agora'
    : `${t.by ? 'Chegar até' : 'Partida'} ${dataPt(t.date)} ${hhmm(t.min)}`;
  $('#res-title').innerHTML = `${esc(state.origin.label)} → ${esc(state.dest.label)}<small>${quando}</small>`;
  $('#res-list').innerHTML = '<div class="spinner"></div>';
  $('#wx').classList.add('hidden'); $('#wx').innerHTML = '';
  if (stay !== true) go('results');
  setTimeout(() => {
    let res = [];
    try {
      const agora = lisbonNow();
      res = N.plan({
        origin: { stop: state.origin.type === 'stop' ? state.origin.stop : null, lat: state.origin.lat, lon: state.origin.lon },
        dest: { lat: state.dest.lat, lon: state.dest.lon, stop: state.dest.type === 'stop' ? state.dest.stop : null },
        date: t.date, time: t.min, arriveBy: t.by ? t.min : null,
        // em "chegar até" hoje, não sugerir partidas que já passaram
        notBefore: t.by && t.date === agora.date ? agora.min : null,
      });
    } catch (e) { console.error(e); }
    state.results = res;
    renderResults();
    fetchRealtimeForResults();
    fetchWeatherForResults();
  }, 30);
}

// ------------------------------------------------------------ definições
$('#btn-settings').addEventListener('click', () => {
  $('#in-proxy').value = store.get('proxy', '') || '';
  const m = state.meta;
  $('#data-info').innerHTML = m ? `<p>Horários gerados em ${new Date(m.generated).toLocaleString('pt-PT')} · válidos até ${dataPt(m.calendar_to)}<br>
    ${m.stops} paragens · ${m.patterns} variantes de linha · ${m.trips} viagens · ${m.stops_with_zone} paragens com zona Andante</p>` : '';
  mostrarRecentes();
  $('#settings').classList.remove('hidden');
});
$('#btn-settings-close').addEventListener('click', () => {
  const own = $('#in-proxy').value.trim();
  store.set('proxy', own);
  state.proxy = own || CFG.REALTIME_PROXY || '';
  limparCacheTempoReal();
  $('#settings').classList.add('hidden');
});
$('#settings').addEventListener('click', (e) => { if (e.target.id === 'settings') $('#settings').classList.add('hidden'); });
$('#btn-test-proxy').addEventListener('click', async () => {
  const out = $('#proxy-out'); out.classList.remove('hidden'); out.textContent = 'A testar…';
  const prev = state.proxy; state.proxy = $('#in-proxy').value.trim() || CFG.REALTIME_PROXY || ''; limparCacheTempoReal();
  const code = $('#in-test-stop').value.trim().toUpperCase() || 'BCM1';
  const d = await obterTempoReal(code);
  state.proxy = prev;
  out.textContent = d ? 'OK ✓\n' + JSON.stringify(d, null, 1).slice(0, 1500) : 'Sem resposta. Verifique o endereço do proxy (deve terminar em .workers.dev).';
});
$('#btn-clear-recent').addEventListener('click', () => {
  const quantos = recentes.lista('origin').length + recentes.lista('dest').length;
  if (!quantos) { mostrarRecentes(); return; }
  const aviso = quantos === 1
    ? 'Apagar a origem/destino recente guardado neste telemóvel?'
    : `Apagar os ${quantos} recentes guardados neste telemóvel?`;
  if (!confirm(aviso)) return;
  recentes.limpar();
  renderDD('origin'); renderDD('dest');
  mostrarRecentes();
});

/** Diz quantos recentes há, para o botão não ser uma caixa fechada. */
function mostrarRecentes() {
  const quantos = recentes.lista('origin').length + recentes.lista('dest').length;
  $('#recent-info').textContent = quantos
    ? `${quantos} guardados (origem e destino). Só ficam neste telemóvel.`
    : 'Nenhum guardado.';
}

// ------------------------------------------------------------ arranque
iniciarNavegacao();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
loadData();
locate();
