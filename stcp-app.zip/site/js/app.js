/* Proxima Paragem - app PWA */
(function () {
  'use strict';
  const CFG = window.APP_CONFIG || {};
  const E = window.Engine;
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // ------------------------------------------------------------ armazenamento local (tolerante a falhas)
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* ignorado */ } },
  };

  const state = {
    net: null, meta: null, shapes: null,
    origin: null,   // indice da paragem
    dest: null,     // {type:'stop', stop, lat, lon, label} | {type:'place', lat, lon, label, sub}
    me: null,       // {lat, lon}
    results: [], query: null,
    proxy: store.get('proxy', '') || CFG.REALTIME_PROXY || '', // valor guardado so se o utilizador alterar em Avancado
  };

  const IS_IOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

  // ------------------------------------------------------------ hora de Lisboa
  function lisbonNow() {
    const f = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Lisbon', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
    const p = Object.fromEntries(f.formatToParts(new Date()).map(x => [x.type, x.value]));
    return { date: `${p.year}-${p.month}-${p.day}`, min: (+p.hour) * 60 + (+p.minute) };
  }
  const hhmm = (m) => { m = ((Math.round(m) % 1440) + 1440) % 1440; return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); };
  const fmtDist = (m) => m < 950 ? Math.round(m / 10) * 10 + ' m' : (m / 1000).toFixed(1).replace('.', ',') + ' km';
  const fmtDur = (m) => m < 60 ? `${Math.round(m)} min` : `${Math.floor(m / 60)} h ${String(Math.round(m % 60)).padStart(2, '0')}`;
  const euro = (v) => v == null ? '' : v.toFixed(2).replace('.', ',') + ' €';

  // ------------------------------------------------------------ icones
  const ICON = {
    stop: '<svg viewBox="0 0 24 24"><rect x="5" y="3" width="14" height="13" rx="3" fill="currentColor"/><rect x="7" y="5" width="10" height="5" rx="1" fill="#fff"/><rect x="11" y="16" width="2" height="6" fill="currentColor"/></svg>',
    pin: '<svg viewBox="0 0 24 24"><path d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12Z" fill="currentColor"/><circle cx="12" cy="10" r="2.6" fill="#fff"/></svg>',
    map: '<svg viewBox="0 0 24 24"><path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2Z M9 4v14 M15 6v14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
    loc: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4" fill="currentColor"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3" stroke="currentColor" stroke-width="2"/></svg>',
    clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    umbrella: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v1.5M3.5 12a8.5 8.5 0 0 1 17 0Z"/><path d="M12 12v7a2 2 0 0 0 4 0"/></svg>',
    snow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M12 3v18M4.2 7.5l15.6 9M19.8 7.5l-15.6 9"/></svg>',
    coat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><path d="M9 3h6l4 3-1.5 4V21H6.5V10L5 6Z"/><path d="M12 3v18"/></svg>',
    water: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10 2.5h4v2.6h-4z"/><path d="M9.6 5.1h4.8a2.2 2.2 0 0 1 2.2 2.2v12.4a2.2 2.2 0 0 1-2.2 2.2H9.6a2.2 2.2 0 0 1-2.2-2.2V7.3a2.2 2.2 0 0 1 2.2-2.2Z"/><path d="M7.4 11.4h9.2"/></svg>',
    sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
    wind: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M3 8h10a3 3 0 1 0-3-3M3 12h14a3 3 0 1 1-3 3M3 16h8a2.5 2.5 0 1 1-2.5 2.5"/></svg>',
    bolt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M13 2 4 14h6l-1 8 9-12h-6Z"/></svg>',
    walk: '<svg viewBox="0 0 24 24"><circle cx="13" cy="4" r="2" fill="currentColor"/><path d="M10 22l2-7 3 3v6M8 12l2-4 4 1 2 4 3 1M12 15l-1-6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  };

  const isMetro = (r) => r && r.type === 1;      // route_type 1 = metro
  const stopWord = (r) => isMetro(r) ? 'estação' : 'paragem';
  function badge(route, cls = '') {
    const bg = route.color ? '#' + route.color : 'var(--brand)';
    const fg = route.text ? '#' + route.text : '#fff';
    const label = isMetro(route) ? 'Metro ' + route.short : route.short;
    return `<span class="badge ${cls}${isMetro(route) ? ' metro' : ''}" style="background:${bg};color:${fg}">${esc(label)}</span>`;
  }
  const routeColor = (r) => (r.color ? '#' + r.color : '#0f5257');

  // ------------------------------------------------------------ navegacao
  function show(view) {
    document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + view));
    window.scrollTo(0, 0);
    if (view === 'detail' && map) setTimeout(() => map.invalidateSize(), 50);
  }
  document.querySelectorAll('[data-back]').forEach(b => b.addEventListener('click', () => history.back()));
  window.addEventListener('popstate', (e) => show((e.state && e.state.view) || 'search'));
  history.replaceState({ view: 'search' }, '');
  const go = (view) => { history.pushState({ view }, ''); show(view); };

  // ------------------------------------------------------------ dados
  async function loadData() {
    const st = $('#data-status');
    try {
      const [net, meta] = await Promise.all([
        fetch('data/net.json').then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }),
        fetch('data/meta.json').then(r => r.ok ? r.json() : null).catch(() => null),
      ]);
      state.net = new E.Network(net);
      state.meta = meta;
      const now = lisbonNow();
      if (!state.net.hasService(now.date)) {
        st.textContent = 'Os horários guardados não cobrem a data de hoje. Abra o app com internet para atualizar.';
        st.classList.remove('hidden');
      }
      fetch('data/shapes.json').then(r => r.json()).then(s => { state.shapes = s; }).catch(() => {});
      renderOriginDropdown();
      updateButton();
    } catch (e) {
      st.textContent = 'Não foi possível carregar os horários da STCP (' + e.message + ').';
      st.classList.add('err'); st.classList.remove('hidden');
    }
  }

  // ------------------------------------------------------------ localizacao
  const mePlace = () => ({ type: 'place', lat: state.me.lat, lon: state.me.lon, label: 'A minha localização', sub: '', key: 'me' });
  // atualiza a posicao quando o app volta ao ecra
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') locate(); });
  function locate() {
    if (!('geolocation' in navigator)) return;
    navigator.geolocation.getCurrentPosition(
      (p) => {
        state.me = { lat: p.coords.latitude, lon: p.coords.longitude };
        // origem por omissao = posicao atual (se o utilizador ainda nao escolheu outra)
        const typing = document.activeElement === inOrigin || inOrigin.value.trim();
        if ((!state.origin && !typing) || (state.origin && state.origin.key === 'me')) setField('origin', mePlace(), { noRecent: true, noFocus: true });
        renderOriginDropdown();
      },
      () => { state.meDenied = true; renderOriginDropdown(); },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 });
  }

  // ------------------------------------------------------------ recentes
  const recent = {
    list(kind) { return store.get('recent_' + kind, []).filter(x => x && x.label); },
    add(kind, item) {
      const l = this.list(kind).filter(x => x.key !== item.key);
      l.unshift(item); store.set('recent_' + kind, l.slice(0, 3));
    },
  };

  // ------------------------------------------------------------ origem e destino (mesmo componente)
  // Cada campo aceita: paragem (nome ou codigo), morada/local, ponto no mapa e, na origem, a localizacao atual.
  // Valor: {type:'stop', stop, lat, lon, label, sub, key} | {type:'place', lat, lon, label, sub, key}
  const fields = {
    origin: { input: $('#in-origin'), dd: $('#dd-origin'), step: '#step-origin', sel: null, geo: [], seq: 0, timer: null, loading: false },
    dest: { input: $('#in-dest'), dd: $('#dd-dest'), step: '#step-dest', sel: null, geo: [], seq: 0, timer: null, loading: false },
  };
  const inOrigin = fields.origin.input, inDest = fields.dest.input;

  function stopPlace(i) {
    const N = state.net;
    return { type: 'stop', stop: i, lat: N.lat[i], lon: N.lon[i], label: N.stopName[i], sub: 'Paragem ' + N.stopCode[i], key: N.stopCode[i] };
  }
  function stopItem(i, extra = '') {
    const N = state.net;
    const lines = N.linesAt(i).slice(0, 8).map(r => badge(r, 'sm')).join('');
    return `<div class="item" data-stop="${i}"><div class="ic">${ICON.stop}</div>
      <div class="tx"><div class="t1">${esc(N.stopName[i])}</div><div class="t2">${[N.stopCode[i], N.zone[i]].filter(Boolean).map(esc).join(' · ')} <span class="lines">${lines}</span></div></div>
      ${extra ? `<div class="meta">${extra}</div>` : ''}</div>`;
  }
  const simpleItem = (attr, icon, t1, t2 = '') =>
    `<div class="item" ${attr}><div class="ic">${icon}</div><div class="tx"><div class="t1">${esc(t1)}</div>${t2 ? `<div class="t2">${esc(t2)}</div>` : ''}</div></div>`;
  const MAP_ITEM = simpleItem('data-pick="map"', ICON.map, 'Escolher no mapa');

  function renderDD(kind) {
    const F = fields[kind], N = state.net;
    if (!N) { F.dd.innerHTML = kind === 'origin' ? '<div class="spinner"></div>' : ''; return; }
    if (F.sel && document.activeElement !== F.input) { F.dd.innerHTML = ''; return; }
    const q = F.sel ? '' : F.input.value.trim();
    let html = '';
    if (!q) {
      if (kind === 'origin') {
        if (state.me) {
          html += simpleItem('data-me="1"', ICON.loc, 'A minha localização', 'Procura as melhores paragens a pé');
          html += '<div class="dd-head"><span>Paragens perto de si</span></div>' +
            N.nearest(state.me.lat, state.me.lon, 4).map(x => stopItem(x.i, fmtDist(x.m))).join('');
        } else if (state.meDenied) {
          html += `<div class="small" style="padding:6px 4px">${IS_IOS
            ? 'Ative a localização (Definições › Privacidade › Serviços de localização › Safari) para ver as paragens mais próximas.'
            : 'Permita o acesso à localização no navegador para ver as paragens mais próximas.'}</div>`;
        } else {
          html += '<div class="dd-head"><span>Perto de si</span></div><div class="small" style="padding:6px 4px">A obter a sua localização…</div>';
        }
      }
      html += MAP_ITEM;
      const rec = recent.list(kind).filter(x => x.type !== 'stop' || N.stopCode.includes(x.key));
      if (rec.length) html += '<div class="dd-head"><span>Recentes</span></div>' + rec.slice(0, 3).map((x, k) =>
        x.type === 'stop' ? stopItem(N.stopCode.indexOf(x.key)) : simpleItem(`data-recent="${k}"`, ICON.clock, x.label, x.sub || '')).join('');
    } else {
      const stops = N.search(q, 5);
      if (stops.length) html += '<div class="dd-head"><span>Paragens</span></div>' + stops.map(i => stopItem(i)).join('');
      html += '<div class="dd-head"><span>Moradas e locais</span></div>';
      if (F.geo.length) html += F.geo.map((g, k) => simpleItem(`data-geo="${k}"`, ICON.pin, g.label, g.sub)).join('');
      else html += `<div class="small" style="padding:6px 4px">${F.loading ? 'A procurar…' : (q.length < 3 ? 'Escreva pelo menos 3 letras' : 'Sem moradas encontradas. Experimente “Escolher no mapa”.')}</div>`;
      html += MAP_ITEM;
    }
    F.dd.innerHTML = html;
  }
  const renderOriginDropdown = () => renderDD('origin');
  const renderDestDropdown = () => renderDD('dest');

  function setField(kind, place, opts = {}) {
    const F = fields[kind];
    F.sel = place;
    state[kind] = place;
    F.input.value = place.type === 'stop' ? `${place.label} (${place.key})` : place.label;
    F.input.classList.add('chosen');
    F.input.blur(); F.dd.innerHTML = '';
    if (!opts.noRecent && place.key !== 'me') {
      const { stop, ...save } = place;
      recent.add(kind, { ...save, key: place.key || (place.lat.toFixed(5) + ',' + place.lon.toFixed(5)) });
    }
    updateButton();
    if (kind === 'origin' && !state.dest && !opts.noFocus) setTimeout(() => inDest.focus(), 50);
  }
  function clearField(kind, focus) {
    const F = fields[kind];
    F.sel = null; state[kind] = null; F.input.value = ''; F.input.classList.remove('chosen'); F.geo = [];
    if (focus) F.input.focus();
    renderDD(kind); updateButton();
  }

  Object.keys(fields).forEach(kind => {
    const F = fields[kind];
    F.input.addEventListener('input', () => {
      F.sel = null; state[kind] = null; F.input.classList.remove('chosen'); F.geo = []; updateButton();
      clearTimeout(F.timer);
      const q = F.input.value.trim();
      F.loading = q.length >= 3;
      renderDD(kind);
      if (q.length >= 3) F.timer = setTimeout(() => geocode(kind, q), 350);
    });
    F.input.addEventListener('focus', () => { if (F.sel) F.input.select(); renderDD(kind); });
    F.dd.addEventListener('click', (e) => {
      const s = e.target.closest('[data-stop]'), g = e.target.closest('[data-geo]'), p = e.target.closest('[data-pick]'),
        r = e.target.closest('[data-recent]'), me = e.target.closest('[data-me]');
      if (s) setField(kind, stopPlace(+s.dataset.stop));
      else if (g) setField(kind, F.geo[+g.dataset.geo]);
      else if (r) setField(kind, recent.list(kind).filter(x => x.type !== 'stop' || state.net.stopCode.includes(x.key))[+r.dataset.recent]);
      else if (me && state.me) setField(kind, mePlace(), { noRecent: true });
      else if (p) openPickMap(kind);
    });
  });

  async function geocode(kind, q) {
    const F = fields[kind];
    const seq = ++F.seq;
    const [w, s, e, n] = CFG.BBOX;
    let res = [];
    try {
      const u = `${CFG.GEOCODER}?q=${encodeURIComponent(q)}&limit=6&bbox=${w},${s},${e},${n}` +
        (state.me ? `&lat=${state.me.lat}&lon=${state.me.lon}` : '&lat=41.15&lon=-8.61');
      const j = await (await fetch(u)).json();
      res = (j.features || []).map(f => {
        const p = f.properties || {};
        const street = [p.street, p.housenumber].filter(Boolean).join(' ');
        const label = p.name || street || p.city || q;
        const sub = [p.name && street ? street : '', p.district || p.locality, p.city, p.postcode].filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(', ');
        const [lon, lat] = f.geometry.coordinates;
        return { type: 'place', lat, lon, label, sub };
      });
    } catch { /* tenta o alternativo */ }
    if (!res.length && CFG.GEOCODER_FALLBACK) {
      try {
        const u = `${CFG.GEOCODER_FALLBACK}?format=jsonv2&limit=6&countrycodes=pt&bounded=1&viewbox=${w},${n},${e},${s}&q=${encodeURIComponent(q)}`;
        const j = await (await fetch(u, { headers: { 'Accept-Language': 'pt-PT' } })).json();
        res = j.map(x => ({ type: 'place', lat: +x.lat, lon: +x.lon, label: x.name || x.display_name.split(',')[0], sub: x.display_name.split(',').slice(1, 4).join(',').trim() }));
      } catch { /* sem resultados */ }
    }
    if (seq !== F.seq || F.sel) return;
    F.geo = res; F.loading = false; renderDD(kind);
  }

  // ------------------------------------------------------------ escolher no mapa
  let pickMap = null, pickMarker = null, pickKind = 'dest';
  function openPickMap(kind) {
    pickKind = kind;
    $('.pick-hint').textContent = kind === 'origin' ? 'Toque no mapa para marcar a origem' : 'Toque no mapa para marcar o destino';
    $('#pick-map-wrap').classList.remove('hidden'); $('.steps').classList.add('hidden');
    fields[kind].input.blur();
    if (!pickMap) {
      pickMap = L.map('pick-map', { zoomControl: false }).setView(state.me ? [state.me.lat, state.me.lon] : [41.1496, -8.6109], 14);
      L.tileLayer(CFG.TILES, { attribution: CFG.TILES_ATTR, maxZoom: 19 }).addTo(pickMap);
      pickMap.on('click', (e) => {
        if (pickMarker) pickMarker.remove();
        pickMarker = L.marker(e.latlng, { icon: L.divIcon({ className: '', html: '<div class="end-pin"></div>', iconSize: [22, 22], iconAnchor: [11, 22] }) }).addTo(pickMap);
        const kindNow = pickKind;
        setTimeout(() => {
          closePickMap();
          setField(kindNow, { type: 'place', lat: e.latlng.lat, lon: e.latlng.lng, label: 'Ponto no mapa', sub: e.latlng.lat.toFixed(5) + ', ' + e.latlng.lng.toFixed(5) });
          reverseName(kindNow, e.latlng.lat, e.latlng.lng);
        }, 250);
      });
    }
    setTimeout(() => pickMap.invalidateSize(), 50);
  }
  function closePickMap() { $('#pick-map-wrap').classList.add('hidden'); $('.steps').classList.remove('hidden'); }
  $('#btn-pick-cancel').addEventListener('click', closePickMap);
  async function reverseName(kind, lat, lon) {
    try {
      const j = await (await fetch(`https://photon.komoot.io/reverse?lat=${lat}&lon=${lon}`)).json();
      const p = (j.features && j.features[0] && j.features[0].properties) || {};
      const name = p.name || [p.street, p.housenumber].filter(Boolean).join(' ');
      const F = fields[kind];
      if (name && F.sel && F.sel.lat === lat) { F.sel.label = name; F.input.value = name; }
    } catch { /* fica 'Ponto no mapa' */ }
  }

  // ------------------------------------------------------------ outros controlos
  document.querySelectorAll('[data-clear]').forEach(b => b.addEventListener('click', () => clearField(b.dataset.clear, true)));
  $('#btn-swap').addEventListener('click', () => {
    const o = fields.origin.sel, d = fields.dest.sel;
    if (d) setField('origin', d, { noRecent: true, noFocus: true }); else clearField('origin');
    if (o) setField('dest', o, { noRecent: true }); else clearField('dest');
  });
  $('#sel-when').addEventListener('change', (e) => {
    const inp = $('#in-when');
    if (e.target.value === 'at') {
      const now = lisbonNow();
      inp.value = `${now.date}T${hhmm(now.min)}`;
      inp.classList.remove('hidden');
    } else inp.classList.add('hidden');
  });
  document.addEventListener('click', (e) => {
    Object.values(fields).forEach(F => { if (!e.target.closest(F.step) && F.sel) F.dd.innerHTML = ''; });
  });
  function updateButton() { $('#btn-search').disabled = !(state.net && state.origin && state.dest); }

  // ------------------------------------------------------------ pesquisa
  $('#btn-search').addEventListener('click', runSearch);
  $('#btn-refresh').addEventListener('click', () => runSearch(true));

  function queryTime() {
    if ($('#sel-when').value === 'at' && $('#in-when').value) {
      const [d, t] = $('#in-when').value.split('T');
      const [h, m] = t.split(':').map(Number);
      return { date: d, min: h * 60 + m, now: false };
    }
    return { ...lisbonNow(), now: true };
  }

  function runSearch(stay) {
    const N = state.net;
    if (!N || !state.origin || !state.dest) return;
    if (state.origin.key === 'me' && state.me) state.origin = fields.origin.sel = mePlace();
    if (E.dist(state.origin.lat, state.origin.lon, state.dest.lat, state.dest.lon) < 30) { alert('A origem e o destino são o mesmo local.'); return; }
    const t = queryTime();
    state.query = { t, origin: state.origin, dest: state.dest };
    $('#res-title').innerHTML = `${esc(state.origin.label)} → ${esc(state.dest.label)}<small>${t.now ? 'Partida agora' : 'Partida ' + t.date.split('-').reverse().join('/') + ' ' + hhmm(t.min)}</small>`;
    $('#res-list').innerHTML = '<div class="spinner"></div>';
    $('#wx').classList.add('hidden'); $('#wx').innerHTML = '';
    if (stay !== true) go('results');
    setTimeout(() => {
      let res = [];
      try {
        res = N.plan({ origin: { stop: state.origin.type === 'stop' ? state.origin.stop : null, lat: state.origin.lat, lon: state.origin.lon }, dest: { lat: state.dest.lat, lon: state.dest.lon, stop: state.dest.type === 'stop' ? state.dest.stop : null }, date: t.date, time: t.min, maxTransfers: 4 });
      } catch (e) { console.error(e); }
      state.results = res;
      renderResults();
      fetchRealtimeForResults();
      fetchWeatherForResults();
    }, 30);
  }

  function chainHtml(it) {
    const parts = [];
    let walk = 0; // soma trocos a pe seguidos, para nao aparecerem em blocos separados
    const flushWalk = () => { if (walk > 0) parts.push(`<span class="walk">${ICON.walk}${walk}′</span>`); walk = 0; };
    it.legs.forEach(l => {
      if (l.type === 'ride') { flushWalk(); parts.push(badge(l.route)); }
      else if (l.type === 'walk') walk += l.dur;
    });
    if (it.last.type === 'walk') walk += it.last.dur || 0;
    flushWalk();
    if (it.last.type === 'uncovered') parts.push(`<span class="gap">+ ${fmtDist(it.last.m)} sem STCP</span>`);
    return parts.join('<span class="sep">›</span>');
  }

  function fareHtml(f) {
    if (!f) return '';
    if (!f.z) return `<span class="tag pv" title="${esc(f.reason)}">Zona ?</span>`;
    return `<span class="tag zone">Andante ${f.z}</span><span>${euro(f.preco)} · ${f.zones.join(', ')}</span>`;
  }

  function renderResults() {
    const N = state.net, list = $('#res-list');
    const res = state.results, t = state.query.t;
    if (!res.length) {
      const o = state.query.origin;
      const noAccess = o.type !== 'stop' && !N.accessStops(o.lat, o.lon).length;
      list.innerHTML = noAccess
        ? `<div class="empty">Não há paragens STCP a menos de 2 km desta origem.<br><br>Escolha uma paragem ou uma morada mais perto da rede STCP.</div>`
        : `<div class="empty">Não encontrei ligações STCP a partir desta origem nas próximas horas.<br><br>Experimente outra origem próxima ou outra hora.</div>`;
      return;
    }
    let html = '';
    if (res.every(r => !r.complete)) {
      html += `<div class="infoline">A STCP não chega a menos de ${fmtDist(E.EGRESS_RADIUS)} deste destino. Mostro até onde o autocarro o leva; o resto do caminho aparece a vermelho no mapa (a pé, TVDE, metro ou comboio).</div>`;
    }
    res.forEach((it, k) => {
      const first = it.legs.find(l => l.type === 'ride');
      const total = it.arrive - t.min;
      if (it.walkOnly) {
        html += `<div class="opt" data-opt="${k}"><div class="opt-top"><div class="chain"><span class="walk">${ICON.walk} Ir a pé · ${fmtDist(it.last.m)}</span></div>
          <div class="dur">${fmtDur(total)}<small>chega ${hhmm(it.arrive)}</small></div></div></div>`;
        return;
      }
      const nextTimes = N.nextDepartures(first, t.date, t.min, 4);
      const walkBefore = it.legs[0].type === 'walk' ? it.legs[0].dur : 0;
      // a hora mostrada e a da viagem deste percurso (o tempo real substitui-a se corresponder)
      const nextBus = first.dep;
      const later = nextTimes.filter(x => x > nextBus).slice(0, 2).map(hhmm).join(', ');
      html += `<div class="opt" data-opt="${k}">
        <div class="opt-top"><div class="chain">${chainHtml(it)}</div>
          <div class="dur" id="dur-${k}">${it.complete ? '' : '≈ '}${fmtDur(total)}<small>${it.complete ? 'chega' : 'estimativa c/ TVDE'} ${hhmm(it.arrive)}</small></div></div>
        <div class="next" id="next-${k}">
          <span class="big">${hhmm(nextBus)}</span>
          <span class="muted">${t.now ? 'em ' + Math.max(0, nextBus - t.min) + ' min' : ''}</span>
          <span class="tag pv">Previsão</span>
        </div>
        <div class="later">${walkBefore ? `Caminhe ${walkBefore} min até ${esc(N.stopName[first.from])}. ` : ''}${isMetro(first.route) ? 'Metro' : 'Linha'} ${esc(first.route.short)} → ${esc(first.head)}${later ? ` · seguintes: ${later}` : ''}</div>
        <div class="opt-foot">${fareHtml(it.fare)}<span>· ${it.transfers ? it.transfers + (it.transfers > 1 ? ' transbordos' : ' transbordo') : 'direto'}</span></div>
        ${it.fare && it.fare.overTime ? `<div class="warnline">O percurso excede ${fmtDur(it.fare.dur)} de validade do ${it.fare.z}: a última validação tem de ser feita dentro desse tempo, senão será descontado outro título.</div>` : ''}
        ${!it.complete ? `<div class="warnline">Faltam ${fmtDist(it.last.m)} até ao destino fora da rede STCP. Toque para ver no mapa e escolher como continuar.</div>` : ''}
      </div>`;
    });
    list.innerHTML = html;
    list.querySelectorAll('[data-opt]').forEach(el => el.addEventListener('click', () => openDetail(+el.dataset.opt)));
  }

  // ------------------------------------------------------------ tempo real
  const rtCache = new Map();
  async function getRealtime(code) {
    const c = rtCache.get(code);
    if (c && Date.now() - c.t < 20000) return c.data;
    const bases = [];
    if (state.proxy) bases.push(state.proxy.replace(/\/+$/, '') + '/rt/' + encodeURIComponent(code));
    else bases.push('https://stcp.pt/api/stops/' + encodeURIComponent(code) + '/realtime'); // so funciona se a STCP permitir CORS
    for (const u of bases) {
      try {
        const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 6000);
        const r = await fetch(u, { signal: ctl.signal }); clearTimeout(to);
        if (!r.ok) continue;
        const data = await r.json();
        rtCache.set(code, { t: Date.now(), data });
        return data;
      } catch { /* sem tempo real */ }
    }
    rtCache.set(code, { t: Date.now(), data: null });
    return null;
  }

  const ALIAS = { '107': 'ZC', 'ZC': '107' };
  /** Devolve {min, realtime} para a linha/sentido na paragem, ou null */
  function matchArrival(data, leg, minMinutes) {
    if (!data) return null;
    const arr = Array.isArray(data) ? data : (data.arrivals || data.results || data.data || []);
    const src = String(data.data_source || data.source || '').toLowerCase();
    const want = String(leg.route.short).toUpperCase();
    const head = E.norm(leg.head);
    const cands = arr.filter(a => {
      const rs = String(a.route_short_name ?? a.line ?? a.route ?? '').toUpperCase();
      const rl = String(a.route_long_name ?? '').toUpperCase();
      return rs === want || rl === want || ALIAS[want] === rs;
    }).map(a => ({ a, min: +(a.arrival_minutes ?? a.minutes ?? a.eta_minutes ?? NaN) }))
      .map(x => ({ ...x, min: Math.max(0, x.min) })) // -1 = "a chegar" (como no site da STCP)
      .filter(x => Number.isFinite(x.min) && x.min >= minMinutes);
    if (!cands.length) return null;
    // preferir o mesmo sentido (destino parecido)
    const same = cands.filter(x => { const h = E.norm(x.a.trip_headsign || x.a.headsign || x.a.destination || ''); return !h || !head || h.includes(head) || head.includes(h) || h.split(' ')[0] === head.split(' ')[0]; });
    const pick = (same.length ? same : cands).sort((a, b) => a.min - b.min)[0];
    return { min: pick.min, realtime: isRealtime(pick.a, src, leg), delay: pick.a.delay_minutes };
  }
  /** A API da STCP devolve no mesmo campo previsoes ao vivo e horas do horario
   *  (validado em 20/09/2026: data_source "realtime" com horas iguais ao horario ao segundo).
   *  Regra: se a hora estimada coincide (<= 20 s) com uma hora do horario da linha nesta paragem,
   *  e horario (Previsao); caso contrario, e estimativa ao vivo (Tempo real). */
  function isRealtime(a, src, leg) {
    for (const k of ['realtime', 'is_realtime', 'real_time', 'live']) if (typeof a[k] === 'boolean') return a[k];
    if (/sched|hor[aá]rio|timetable|static/.test(String(a.data_source || src || '').toLowerCase())) return false;
    const est = a.estimated_arrival_time ? Date.parse(a.estimated_arrival_time) : NaN;
    const sch = a.scheduled_arrival_time ? Date.parse(a.scheduled_arrival_time) : NaN;
    if (Number.isFinite(est) && Number.isFinite(sch)) return Math.abs(est - sch) > 20000;
    if (!Number.isFinite(est) || !state.net || !leg) return false;
    const lis = lisbonParts(new Date(est));
    let sec = lis.sec;
    const svcDate = state.query ? state.query.t.date : lis.date;
    if (lis.date !== svcDate) sec += 86400; // depois da meia-noite: horario do dia anterior (24:xx)
    const sched = state.net.scheduledSecsAt(leg.from, leg.route.short, svcDate);
    return !sched.some(x => Math.abs(x - sec) <= 20);
  }
  function lisbonParts(d) {
    const f = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Lisbon', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' });
    const p = Object.fromEntries(f.formatToParts(d).map(x => [x.type, x.value]));
    return { date: `${p.year}-${p.month}-${p.day}`, sec: (+p.hour) * 3600 + (+p.minute) * 60 + (+p.second) };
  }

  async function fetchRealtimeForResults() {
    const t = state.query.t;
    if (!t.now) return; // tempo real so faz sentido para "agora"
    const N = state.net;
    await Promise.all(state.results.map(async (it, k) => {
      if (it.walkOnly) return;
      const leg = it.legs.find(l => l.type === 'ride');
      const walkBefore = it.legs[0].type === 'walk' ? it.legs[0].dur : 0;
      if (!N.stopCode[leg.from]) return;   // metro nao tem tempo real nesta fonte
      const data = await getRealtime(N.stopCode[leg.from]);
      const m = matchArrival(data, leg, walkBefore);
      const el = document.getElementById('next-' + k);
      if (!el || !m) return;
      const when = lisbonNow().min + m.min;
      // so usar se for mesmo a viagem planeada: ate 15 min de diferenca face ao horario
      const shift = when - leg.dep;
      if (Math.abs(shift) > 15) {
        // a chegada ao vivo nao corresponde a esta viagem (autocarro ja passou, suprimido ou outro sentido)
        el.insertAdjacentHTML('beforeend',
          `<span class="small">tempo real desta linha: ${hhmm(when)}</span>`);
        return;
      }
      it.rt = m; it.shift = shift;
      el.innerHTML = `<span class="big">${m.min === 0 ? 'A chegar' : m.min + ' min'}</span><span class="muted">≈ ${hhmm(when)}</span>
        <span class="tag ${m.realtime ? 'rt' : 'pv'}">${m.realtime ? 'Tempo real' : 'Previsão'}</span>
        ${shift ? `<span class="small">${shift > 0 ? '+' : ''}${shift} min</span>` : ''}`;
      // a chegada acompanha o atraso/adianto do autocarro
      const dur = document.getElementById('dur-' + k);
      if (dur && shift) dur.innerHTML = `${it.complete ? '' : '≈ '}${fmtDur(it.arrive + shift - t.min)}<small>${it.complete ? 'chega ≈' : 'estimativa c/ TVDE'} ${hhmm(it.arrive + shift)}</small>`;
    }));
  }

  // ------------------------------------------------------------ meteorologia (origem e destino)
  const WX_ICON = { umbrella: 'umbrella', snow: 'snow', coat: 'coat', water: 'water', sun: 'sun', wind: 'wind', bolt: 'bolt' };
  const deg = (v) => v == null ? '—' : Math.round(v) + '°';
  const WHERE = { origem: 'na origem', destino: 'no destino', ambos: '' };

  async function fetchWeatherForResults() {
    if (CFG.WEATHER === false || !window.Weather || !state.results.length) return;
    const q = state.query, best = state.results[0];
    try {
      const wx = await Weather.forTrip(
        { lat: q.origin.lat, lon: q.origin.lon }, { lat: q.dest.lat, lon: q.dest.lon },
        q.t.date, q.t.min, best.arrive);
      state.wx = wx;
      const el = $('#wx');
      el.innerHTML = `
        <div class="temps" title="Temperatura à partida e à chegada">${deg(wx.origin.temp)} <em>origem</em>
          <span class="arrow">→</span> ${deg(wx.dest.temp)} <em>destino</em>
          ${wx.showFeels ? `<em>· sente-se ${deg(wx.origin.feels)}/${deg(wx.dest.feels)}</em>` : ''}</div>
        <div class="tips">${wx.tips.map(t => `<span class="tip ${t.id === 'chuva' || t.id === 'neve' || t.id === 'trovoada' ? 'alert' : ''}">${ICON[WX_ICON[t.icon]]}${esc(t.label)}${WHERE[t.where] ? ' <em style="font-style:normal;font-weight:500;opacity:.75">' + WHERE[t.where] + '</em>' : ''}</span>`).join('')}</div>`;
      el.classList.remove('hidden');
    } catch { /* sem meteorologia: o app funciona na mesma */ }
  }

  function wxLine() {
    const wx = state.wx;
    if (!wx) return '';
    const tips = wx.tips.map(t => `${ICON[WX_ICON[t.icon]]}${esc(t.label)}${WHERE[t.where] ? ' ' + WHERE[t.where] : ''}`).join(' · ');
    const feels = wx.showFeels ? ` (sente-se ${deg(wx.origin.feels)} e ${deg(wx.dest.feels)}, com o vento)` : '';
    return `<div class="wx-line">À partida ${deg(wx.origin.temp)} · à chegada ${deg(wx.dest.temp)}${feels}${tips ? ' · ' + tips : ''}</div>`;
  }

  // ------------------------------------------------------------ detalhe + mapa
  let map = null, layer = null;
  function ensureMap() {
    if (map) return;
    map = L.map('map', { zoomControl: false, attributionControl: false });
    L.control.attribution({ position: 'topright', prefix: false }).addTo(map);
    L.tileLayer(CFG.TILES, { attribution: CFG.TILES_ATTR, maxZoom: 19 }).addTo(map);
    layer = L.layerGroup().addTo(map);
  }
  function shapeSlice(leg) {
    const N = state.net;
    const pat = N.patterns[leg.pi];
    const pts = leg.stops.map(s => [N.lat[s], N.lon[s]]);
    if (!state.shapes || pat.sh < 0 || !state.shapes[pat.sh]) return pts;
    const line = E.decodePoly(state.shapes[pat.sh]);
    const nearestIdx = (p, from) => {
      let bi = from, bd = Infinity;
      for (let i = from; i < line.length; i++) { const d = (line[i][0] - p[0]) ** 2 + (line[i][1] - p[1]) ** 2; if (d < bd) { bd = d; bi = i; } }
      return bi;
    };
    const a = nearestIdx(pts[0], 0), b = nearestIdx(pts[pts.length - 1], a);
    if (b <= a) return pts;
    return [pts[0], ...line.slice(a, b + 1), pts[pts.length - 1]];
  }
  const pin = (cls, color) => L.divIcon({ className: '', html: `<div class="${cls}" style="--c:${color || ''}"></div>`, iconSize: cls === 'end-pin' ? [22, 22] : [14, 14], iconAnchor: cls === 'end-pin' ? [11, 22] : [7, 7] });

  function openDetail(k) {
    const N = state.net, it = state.results[k], t = state.query.t, dest = state.query.dest;
    go('detail');
    ensureMap();
    layer.clearLayers();
    const bounds = [];
    const addLine = (pts, style) => { L.polyline(pts, style).addTo(layer); pts.forEach(p => bounds.push(p)); };
    const O = state.query.origin, oPt = [O.lat, O.lon];
    L.marker(oPt, { icon: pin(O.type === 'stop' ? 'stop-pin' : 'start-pin', '#0f5257') }).addTo(layer).bindPopup(esc(O.label));
    bounds.push(oPt);
    const ptOf = (i) => (i < 0 ? oPt : [N.lat[i], N.lon[i]]);

    let tl = '';
    // se comeca a pe, mostra a hora a que deve sair (e nao a hora atual)
    let clock = t.min;
    const firstRide = it.legs.findIndex(l => l.type === 'ride');
    if (firstRide > 0) clock = it.legs[firstRide].dep - it.legs.slice(0, firstRide).reduce((a, l) => a + l.dur, 0);
    if (it.walkOnly) {
      addLine([oPt, [dest.lat, dest.lon]], { color: '#5d6b69', weight: 4, dashArray: '2 8' });
    }
    it.legs.forEach((l) => {
      if (l.type === 'walk') {
        addLine([ptOf(l.from), ptOf(l.to)], { color: '#5d6b69', weight: 4, dashArray: '2 8' });
        tl += `<li class="walk"><span class="node"></span><div><span class="when-t">${hhmm(clock)}</span><span class="what">A pé até à ${stopWord(N.routeAt(l.to))} ${esc(N.stopName[l.to])}${N.stopCode[l.to] && N.stopCode[l.to] !== N.stopName[l.to] ? ` (${esc(N.stopCode[l.to])})` : ''}</span></div>
          <div class="sub">${l.dur} min · ${fmtDist(l.m)}</div></li>`;
        clock += l.dur;
      } else {
        const c = routeColor(l.route);
        addLine(shapeSlice(l), { color: c, weight: 6, opacity: .9 });
        l.stops.forEach((s, i) => { if (i === 0 || i === l.stops.length - 1) L.marker([N.lat[s], N.lon[s]], { icon: pin('stop-pin', c) }).addTo(layer).bindPopup(esc(N.stopName[s] + ' (' + N.stopCode[s] + ')')); });
        const inter = l.stops.map((s, i) => `<li>${hhmm(N.tripTime(l.pi, l.trip, l.shift, l.boardPos + i))} ${esc(N.stopName[s])}${N.zone[s] ? ' · ' + esc(N.zone[s]) : ''}</li>`).join('');
        const rt = (it.rt && l === it.legs.find(x => x.type === 'ride')) ? `<span class="tag ${it.rt.realtime ? 'rt' : 'pv'}">${it.rt.realtime ? 'Tempo real: ' + it.rt.min + ' min' : 'Previsão'}</span>` : '<span class="tag pv">Previsão</span>';
        tl += `<li style="--c:${c}"><span class="node"></span><div><span class="when-t">${hhmm(l.dep)}</span>${badge(l.route)} <span class="what">${esc(N.stopName[l.from])}</span> ${rt}</div>
          <div class="sub">Direção ${esc(l.head)} · ${l.stops.length - 1} paragens · ${l.arr - l.dep} min</div>
          <details><summary>Ver paragens</summary><ol>${inter}</ol></details></li>
          <li style="--c:${c}" class="${(() => { const nx = it.legs[it.legs.indexOf(l) + 1]; return nx ? (nx.type === 'walk' ? 'walk' : '') : (it.last.type === 'uncovered' ? 'gap' : (dest.type === 'stop' && dest.stop === l.to ? '' : 'walk')); })()}"><span class="node"></span><div><span class="when-t">${hhmm(l.arr)}</span><span class="what">Sair em ${esc(N.stopName[l.to])}</span></div>
          <div class="sub">${[N.stopCode[l.to], N.zone[l.to] ? 'zona ' + N.zone[l.to] : ''].filter(Boolean).map(esc).join(' · ')}</div></li>`;
        clock = l.arr;
      }
    });

    // ultimo troco
    const fs = it.walkOnly ? -1 : it.finalStop;
    const from = ptOf(fs), to = [dest.lat, dest.lon];
    const ll = `${from[0]},${from[1]}`, dl = `${to[0]},${to[1]}`;
    const walkLink = IS_IOS
      ? `<a href="https://maps.apple.com/?saddr=${ll}&daddr=${dl}&dirflg=w" target="_blank" rel="noopener">A pé (Apple Mapas)</a>`
      : `<a href="https://www.google.com/maps/dir/?api=1&origin=${ll}&destination=${dl}&travelmode=walking" target="_blank" rel="noopener">A pé (Google Maps)</a>`;
    const links = walkLink + (IS_IOS ? `
      <a href="https://maps.apple.com/?saddr=${ll}&daddr=${dl}&dirflg=r" target="_blank" rel="noopener">Metro/comboio (Apple Mapas)</a>` : '') + `
      <a href="https://www.google.com/maps/dir/?api=1&origin=${ll}&destination=${dl}&travelmode=transit" target="_blank" rel="noopener">${IS_IOS ? 'Google Maps' : 'Metro/comboio (Google Maps)'}</a>
      <a href="https://m.uber.com/ul/?action=setPickup&pickup[latitude]=${from[0]}&pickup[longitude]=${from[1]}&dropoff[latitude]=${to[0]}&dropoff[longitude]=${to[1]}" target="_blank" rel="noopener">TVDE (Uber)</a>`;
    if (dest.type !== 'stop' || dest.stop !== fs) {
      if (it.last.type === 'uncovered') {
        addLine([from, to], { color: '#b3261e', weight: 5, dashArray: '8 8' });
        tl += `<li class="gap" style="--c:#b3261e"><span class="node"></span><div><span class="what">Troço sem STCP: ${fmtDist(it.last.m)} em linha reta</span></div>
          <div class="sub">Continue a pé, de TVDE, metro ou comboio:</div><div class="actions">${links}</div></li>`;
      } else if (it.last.m > 30) {
        addLine([from, to], { color: '#5d6b69', weight: 4, dashArray: '2 8' });
        tl += `<li class="walk"><span class="node"></span><div><span class="when-t">${hhmm(clock)}</span><span class="what">A pé até ao destino</span></div>
          <div class="sub">${it.last.dur} min · ${fmtDist(it.last.m * 1.25)}</div><div class="actions">${walkLink}</div></li>`;
      }
    }
    L.marker(to, { icon: pin('end-pin') }).addTo(layer).bindPopup(esc(dest.label));
    bounds.push(to);
    const arrivedAtStop = dest.type === 'stop' && dest.stop === fs && !it.walkOnly;
    if (!arrivedAtStop) tl += `<li><span class="node" style="border-color:var(--accent)"></span><div><span class="when-t">${hhmm(it.arrive)}</span><span class="what">${esc(dest.label)}</span></div></li>`;
    if (state.me) L.marker([state.me.lat, state.me.lon], { icon: L.divIcon({ className: '', html: '<div class="me-pin"></div>', iconSize: [16, 16], iconAnchor: [8, 8] }) }).addTo(layer);

    const f = it.fare;
    $('#detail-sheet').innerHTML = `
      <div class="sum"><b style="font-size:20px">${fmtDur(it.arrive - t.min)}</b><span class="muted">chega ${hhmm(it.arrive)}</span>
        ${f && f.z ? `<span class="tag zone">Andante ${f.z}</span><span class="small">${euro(f.preco)} · validade ${fmtDur(f.dur)}</span>` : f ? '<span class="tag pv">Zona ?</span>' : ''}</div>
      ${wxLine()}
      ${f && f.z ? `<div class="small" style="margin:-4px 0 10px">Zonas atravessadas: ${f.zones.join(', ')} (1.ª validação em ${esc(f.origin)}). ${f.fonte === 'metro' ? 'Título segundo a tabela oficial do Metro do Porto.' : 'Estimativa pelas zonas das paragens; confirme no mapa de zonas Andante.'}</div>` : ''}
      <ul class="tl">${tl}</ul>`;
    setTimeout(() => { map.invalidateSize(); map.fitBounds(bounds, { padding: [30, 30], maxZoom: 16 }); }, 80);
  }

  // ------------------------------------------------------------ definicoes
  $('#btn-settings').addEventListener('click', () => {
    $('#in-proxy').value = store.get('proxy', '') || '';
    const m = state.meta;
    $('#data-info').innerHTML = m ? `<p>Horários gerados em ${new Date(m.generated).toLocaleString('pt-PT')} · válidos até ${m.calendar_to.split('-').reverse().join('/')}<br>
      ${m.stops} paragens · ${m.patterns} variantes de linha · ${m.trips} viagens · ${m.stops_with_zone} paragens com zona Andante</p>` : '';
    $('#settings').classList.remove('hidden');
  });
  $('#btn-settings-close').addEventListener('click', () => {
    const own = $('#in-proxy').value.trim();
    store.set('proxy', own);
    state.proxy = own || CFG.REALTIME_PROXY || '';
    rtCache.clear();
    $('#settings').classList.add('hidden');
  });
  $('#settings').addEventListener('click', (e) => { if (e.target.id === 'settings') $('#settings').classList.add('hidden'); });
  $('#btn-test-proxy').addEventListener('click', async () => {
    const out = $('#proxy-out'); out.classList.remove('hidden'); out.textContent = 'A testar…';
    const prev = state.proxy; state.proxy = $('#in-proxy').value.trim() || CFG.REALTIME_PROXY || ''; rtCache.clear();
    const code = $('#in-test-stop').value.trim().toUpperCase() || 'BCM1';
    const d = await getRealtime(code);
    state.proxy = prev;
    out.textContent = d ? 'OK ✓\n' + JSON.stringify(d, null, 1).slice(0, 1500) : 'Sem resposta. Verifique o endereço do proxy (deve terminar em .workers.dev).';
  });
  $('#btn-clear-recent').addEventListener('click', () => { store.set('recent_origin', []); store.set('recent_dest', []); renderOriginDropdown(); });

  // ------------------------------------------------------------ arranque
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
  loadData();
  locate();
})();
