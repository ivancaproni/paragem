/** Texto, horas e distâncias. Funções puras: não tocam no ecrã nem na rede. */

/** Escapa texto que vai para dentro de HTML. Usar SEMPRE em tudo o que venha de fora. */
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[c]));

/** Minutos desde a meia-noite -> "08:05". Aceita valores negativos e acima de 24 h. */
export const hhmm = (m) => {
  m = ((Math.round(m) % 1440) + 1440) % 1440;
  return String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
};

/** Metros -> "450 m" ou "1,2 km". */
export const fmtDist = (m) => (m < 950
  ? Math.round(m / 10) * 10 + ' m'
  // arredonda em metros antes de dividir: (0.95).toFixed(1) daria "0.9"
  : (Math.round(m / 100) / 10).toFixed(1).replace('.', ',') + ' km');

/** Minutos -> "45 min" ou "1 h 05". */
export const fmtDur = (m) => (m < 60
  ? `${Math.round(m)} min`
  : `${Math.floor(m / 60)} h ${String(Math.round(m % 60)).padStart(2, '0')}`);

/** Valor -> "1,40 €". Devolve vazio se não houver valor. */
export const euro = (v) => (v == null ? '' : v.toFixed(2).replace('.', ',') + ' €');

/** Temperatura -> "19°", ou "—" se não houver leitura. */
export const deg = (v) => (v == null ? '—' : Math.round(v) + '°');

/** "2026-09-22" -> "22/09/2026". */
export const dataPt = (iso) => String(iso).split('-').reverse().join('/');

const PARTES = (d, comSegundos) => {
  const f = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Lisbon', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
    ...(comSegundos ? { second: '2-digit' } : {}),
  });
  return Object.fromEntries(f.formatToParts(d).map((x) => [x.type, x.value]));
};

/** Data e minutos de agora, sempre na hora de Lisboa (o telemóvel pode estar noutro fuso). */
export function lisbonNow(d = new Date()) {
  const p = PARTES(d, false);
  return { date: `${p.year}-${p.month}-${p.day}`, min: (+p.hour) * 60 + (+p.minute) };
}

/** Como lisbonNow, mas com os segundos, para comparar com horários ao segundo. */
export function lisbonParts(d) {
  const p = PARTES(d, true);
  return { date: `${p.year}-${p.month}-${p.day}`, sec: (+p.hour) * 3600 + (+p.minute) * 60 + (+p.second) };
}
