/**
 * Estado partilhado pelos módulos do ecrã e utilitários pequenos que quase todos usam.
 * É de propósito um objeto simples: o app é pequeno e não justifica mais maquinaria.
 */
import { criarStore, criarRecentes } from './store.js';
import { esc } from './format.js';

export const CFG = (typeof window !== 'undefined' && window.APP_CONFIG) || {};
export const $ = (s) => document.querySelector(s);

export const store = criarStore();
export const recentes = criarRecentes(store);

export const state = {
  net: null,          // rede carregada (motor)
  meta: null,         // data e números dos horários
  shapes: null,       // traçados das linhas
  origin: null,       // {type:'stop'|'place', lat, lon, label, ...}
  dest: null,
  me: null,           // {lat, lon} da última leitura do GPS
  meDenied: false,    // o utilizador recusou a localização
  results: [],
  query: null,        // {t, origin, dest} da última pesquisa
  wx: null,
  // O proxy vem da configuração; só fica guardado se o utilizador o mudar em Avançado.
  proxy: store.get('proxy', '') || CFG.REALTIME_PROXY || '',
};

export const IS_IOS = typeof navigator !== 'undefined' && (
  /iPad|iPhone|iPod/.test(navigator.userAgent)
  || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1));

/** route_type 1 = metro; tudo o resto trata-se por autocarro. */
export const isMetro = (r) => !!r && r.type === 1;
export const stopWord = (r) => (isMetro(r) ? 'estação' : 'paragem');
export const routeColor = (r) => (r.color ? '#' + r.color : '#0f5257');

/** Crachá colorido da linha (o do metro leva a palavra "Metro"). */
export function badge(route, cls = '') {
  const bg = route.color ? '#' + route.color : 'var(--brand)';
  const fg = route.text ? '#' + route.text : '#fff';
  const texto = isMetro(route) ? 'Metro ' + route.short : route.short;
  return `<span class="badge ${cls}${isMetro(route) ? ' metro' : ''}" style="background:${bg};color:${fg}">${esc(texto)}</span>`;
}
