/**
 * Armazenamento no próprio telemóvel (recentes e definições).
 *
 * Tolerante a falhas de propósito: em navegação privada, com as cookies bloqueadas
 * ou com o espaço cheio, o `localStorage` atira erro. Nesse caso o app continua a
 * funcionar, só não se lembra de nada entre sessões.
 */
import { INTERFACE } from './rules.js';

/** Permite trocar o armazenamento nos testes. */
export function criarStore(backend) {
  const bd = backend ?? (typeof localStorage !== 'undefined' ? localStorage : null);
  return {
    get(chave, omissao) {
      try {
        const v = bd.getItem(chave);
        return v == null ? omissao : JSON.parse(v);
      } catch {
        return omissao;
      }
    },
    set(chave, valor) {
      try {
        bd.setItem(chave, JSON.stringify(valor));
        return true;
      } catch {
        return false;   // sem espaço ou sem permissão: segue sem guardar
      }
    },
  };
}

/** Lista de origens/destinos recentes, no máximo `INTERFACE.recentes` de cada. */
export function criarRecentes(store) {
  return {
    lista(tipo) {
      const l = store.get('recent_' + tipo, []);
      return Array.isArray(l) ? l.filter((x) => x && x.label) : [];
    },
    juntar(tipo, item) {
      const l = this.lista(tipo).filter((x) => x.key !== item.key);
      l.unshift(item);
      store.set('recent_' + tipo, l.slice(0, INTERFACE.recentes));
      return l.slice(0, INTERFACE.recentes);
    },
    limpar() {
      store.set('recent_origin', []);
      store.set('recent_dest', []);
    },
  };
}
