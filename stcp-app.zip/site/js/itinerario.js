/**
 * ITINERÁRIOS - transformar as etiquetas do algoritmo em algo legível.
 *
 * O raptor.js deixa, para cada paragem, a hora a que lá se chega e de onde se
 * veio. Aqui anda-se para trás nessa cadeia até à origem e monta-se a lista de
 * troços (a pé / de transporte) que o ecrã mostra, já arrumada: caminhadas
 * seguidas juntam-se numa só, o último troço vai direto ao destino, e o
 * embarque é afinado para a paragem que dá menos caminhada.
 */
import { dist } from './geo.js';

/**
 * Reconstrói um itinerário a partir das etiquetas.
 * @param last {type: 'walk'|'uncovered', m, dur} o que falta depois de sair do transporte
 */
export function construir(H, { tau, par }, k, s, q, last, custo) {
  const legs = [];
  let cur = s, kk = k;
  let guard = 0;
  while (guard++ < 50) {
    const p = par[kk][cur];
    if (!p || p.type === 'origin') break;
    if (p.type === 'access') { // da morada de origem ate a primeira paragem
      legs.unshift({ type: 'walk', from: -1, to: cur, dur: p.dur, m: custo.metrosDeRua(p.m), access: true });
      break;
    }
    if (p.type === 'walk') {
      legs.unshift({
        type: 'walk', from: p.from, to: cur, dur: p.dur,
        m: custo.metrosDeRua(dist(H.lat[p.from], H.lon[p.from], H.lat[cur], H.lon[cur])),
      });
      cur = p.from;
      continue;
    }
    const pat = H.patterns[p.pi];
    legs.unshift({
      type: 'ride', pi: p.pi, route: H.routes[pat.r], head: pat.h, from: p.from, to: cur,
      boardPos: p.boardPos, alightPos: p.pos, dep: p.dep, arr: p.arr,
      stops: pat.s.slice(p.boardPos, p.pos + 1), trip: p.trip, shift: p.shift,
    });
    cur = p.from; kk--;
  }

  juntarCaminhadas(H, legs, custo);

  let lastStop = s;
  let end = tau[k][s] + (last.dur || 0);
  // se o percurso acaba a pé, vai-se direto de onde se sai do transporte até ao destino
  const tail = legs[legs.length - 1];
  if ((last.type === 'walk' || last.type === 'uncovered') && tail && tail.type === 'walk' && !tail.access) {
    const prev = legs[legs.length - 2];
    if (prev && prev.type === 'ride') {
      legs.pop();
      lastStop = prev.to;
      const m = dist(H.lat[lastStop], H.lon[lastStop], q.dest.lat, q.dest.lon);
      const dur = last.type === 'walk' ? custo.minutosAPe(m) : custo.minutosDeCarro(m);
      last = { ...last, m, dur };
      end = prev.arr + dur;
    }
  }

  const rides = legs.filter((l) => l.type === 'ride');
  const it = {
    legs, rides: rides.length, transfers: Math.max(0, rides.length - 1),
    depart: rides.length ? rides[0].dep : q.time, arrive: end,
    finalStop: lastStop, last: { ...last, lat: q.dest.lat, lon: q.dest.lon },
    complete: last.type !== 'uncovered',
  };
  afinarEmbarque(H, it, q, custo);
  return it;
}

/** Quem anda a pé vai direto, não passa pelas paragens do caminho. */
function juntarCaminhadas(H, legs, custo) {
  for (let i = legs.length - 1; i > 0; i--) {
    const a = legs[i - 1], b = legs[i];
    if (a.type !== 'walk' || b.type !== 'walk') continue;
    const m = a.access
      ? a.m + b.m
      : custo.metrosDeRua(dist(H.lat[a.from], H.lon[a.from], H.lat[b.to], H.lon[b.to]));
    legs.splice(i - 1, 2, { ...a, to: b.to, m, dur: custo.minutosDeRua(m) });
  }
}

/**
 * Afina onde se apanha cada transporte.
 *
 * O algoritmo apanha a viagem na primeira paragem onde consegue, mesmo que a
 * mesma viagem passe a seguir muito mais perto de quem espera. Como é o mesmo
 * veículo, a hora de chegada é igual e ninguém quer andar 600 m para ganhar dois
 * minutos de nada. Aqui adia-se o embarque para a paragem que o modelo de custo
 * considerar melhor, sem nunca atrasar a chegada nem perder a viagem.
 */
export function afinarEmbarque(H, it, q, custo) {
  const O = H.origem(q.origin);
  for (let i = 0; i < it.legs.length; i++) {
    const ride = it.legs[i];
    if (ride.type !== 'ride') continue;
    const antes = i > 0 ? it.legs[i - 1] : null;
    if (!antes || antes.type !== 'walk') continue;   // sem caminhada antes, não há escolha

    // de onde se caminha, e a que horas se pode começar
    const daOrigem = !!antes.access;
    const rideAnterior = daOrigem ? null : it.legs[i - 2];
    const de = daOrigem ? O : { lat: H.lat[antes.from], lon: H.lon[antes.from] };
    const prontoEm = rideAnterior && rideAnterior.type === 'ride' ? rideAnterior.arr : q.time;
    const limite = daOrigem ? custo.raio.acesso : custo.raio.transbordo;

    const pat = H.patterns[ride.pi];
    let melhor = null;
    for (let pos = ride.boardPos; pos < ride.alightPos; pos++) {
      const s = pat.s[pos];
      const m = dist(de.lat, de.lon, H.lat[s], H.lon[s]);
      if (m > limite) continue;
      const w = custo.minutosAPe(m);
      const dep = H.tripTime(ride.pi, ride.trip, ride.shift, pos);
      if (prontoEm + w > dep) continue;              // não se chega lá a tempo
      const cand = { pos, s, m, w, dep };
      if (custo.melhorEmbarque(cand, melhor)) melhor = cand;
    }
    if (!melhor || melhor.pos === ride.boardPos) continue;

    antes.to = melhor.s;
    antes.dur = melhor.w;
    antes.m = custo.metrosDeRua(melhor.m);
    ride.from = melhor.s;
    ride.boardPos = melhor.pos;
    ride.dep = melhor.dep;
    ride.stops = pat.s.slice(melhor.pos, ride.alightPos + 1);
    if (i === 0 || it.legs.slice(0, i).every((l) => l.type === 'walk')) it.depart = melhor.dep;
  }
  return it;
}
