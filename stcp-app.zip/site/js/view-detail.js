/** Ecrã de detalhe: linha do tempo do percurso e mapa. */
import { $, state, IS_IOS, isMetro, stopWord, routeColor, badge, CFG } from './state.js';
import { esc, hhmm, fmtDist, fmtDur, euro } from './format.js';
import { INTERFACE } from './rules.js';
import * as E from './engine.js';
import { wxLine } from './view-results.js';
import { go, quandoMostrar } from './navigation.js';

let map = null, layer = null;
// quando se volta ao detalhe, o Leaflet precisa de recalcular o tamanho
quandoMostrar((v) => { if (v === 'detail' && map) setTimeout(() => map.invalidateSize(), 50); });
function ensureMap() {
  if (map) return;
  map = L.map('map', { zoomControl: false, attributionControl: false });
  L.control.attribution({ position: 'topright', prefix: false }).addTo(map);
  L.tileLayer(CFG.TILES, { attribution: CFG.TILES_ATTR, maxZoom: 19 }).addTo(map);
  layer = L.layerGroup().addTo(map);
}
function shapeSlice(leg) {
  const N = state.net;
  const pat = N.patterns[leg.pi];
  const pts = leg.stops.map(s => [N.lat[s], N.lon[s]]);
  if (!state.shapes || pat.sh < 0 || !state.shapes[pat.sh]) return pts;
  const line = E.decodePoly(state.shapes[pat.sh]);
  const nearestIdx = (p, from) => {
    let bi = from, bd = Infinity;
    for (let i = from; i < line.length; i++) { const d = (line[i][0] - p[0]) ** 2 + (line[i][1] - p[1]) ** 2; if (d < bd) { bd = d; bi = i; } }
    return bi;
  };
  const a = nearestIdx(pts[0], 0), b = nearestIdx(pts[pts.length - 1], a);
  if (b <= a) return pts;
  return [pts[0], ...line.slice(a, b + 1), pts[pts.length - 1]];
}
const pin = (cls, color) => L.divIcon({ className: '', html: `<div class="${cls}" style="--c:${color || ''}"></div>`, iconSize: cls === 'end-pin' ? [22, 22] : [14, 14], iconAnchor: cls === 'end-pin' ? [11, 22] : [7, 7] });

export function openDetail(k) {
  const N = state.net, it = state.results[k], t = state.query.t, dest = state.query.dest;
  go('detail');
  ensureMap();
  layer.clearLayers();
  const bounds = [];
  const addLine = (pts, style) => { L.polyline(pts, style).addTo(layer); pts.forEach(p => bounds.push(p)); };
  const O = state.query.origin, oPt = [O.lat, O.lon];
  L.marker(oPt, { icon: pin(O.type === 'stop' ? 'stop-pin' : 'start-pin', '#0f5257') }).addTo(layer).bindPopup(esc(O.label));
  bounds.push(oPt);
  const ptOf = (i) => (i < 0 ? oPt : [N.lat[i], N.lon[i]]);

  let tl = '';
  // se comeca a pe, mostra a hora a que deve sair (e nao a hora atual)
  let clock = t.min;
  const firstRide = it.legs.findIndex(l => l.type === 'ride');
  if (firstRide > 0) clock = it.legs[firstRide].dep - it.legs.slice(0, firstRide).reduce((a, l) => a + l.dur, 0);
  if (it.walkOnly) {
    addLine([oPt, [dest.lat, dest.lon]], { color: '#5d6b69', weight: 4, dashArray: '2 8' });
  }
  it.legs.forEach((l) => {
    if (l.type === 'walk') {
      addLine([ptOf(l.from), ptOf(l.to)], { color: '#5d6b69', weight: 4, dashArray: '2 8' });
      tl += `<li class="walk"><span class="node"></span><div><span class="when-t">${hhmm(clock)}</span><span class="what">A pé até à ${stopWord(N.routeAt(l.to))} ${esc(N.stopName[l.to])}${N.stopCode[l.to] && N.stopCode[l.to] !== N.stopName[l.to] ? ` (${esc(N.stopCode[l.to])})` : ''}</span></div>
        <div class="sub">${l.dur} min · ${fmtDist(l.m)}</div></li>`;
      clock += l.dur;
    } else {
      const c = routeColor(l.route);
      addLine(shapeSlice(l), { color: c, weight: 6, opacity: .9 });
      l.stops.forEach((s, i) => { if (i === 0 || i === l.stops.length - 1) L.marker([N.lat[s], N.lon[s]], { icon: pin('stop-pin', c) }).addTo(layer).bindPopup(esc(N.stopName[s] + ' (' + N.stopCode[s] + ')')); });
      const inter = l.stops.map((s, i) => `<li>${hhmm(N.tripTime(l.pi, l.trip, l.shift, l.boardPos + i))} ${esc(N.stopName[s])}${N.zone[s] ? ' · ' + esc(N.zone[s]) : ''}</li>`).join('');
      const rt = (it.rt && l === it.legs.find(x => x.type === 'ride')) ? `<span class="tag ${it.rt.realtime ? 'rt' : 'pv'}">${it.rt.realtime ? 'Tempo real: ' + it.rt.min + ' min' : 'Previsão'}</span>` : '<span class="tag pv">Previsão</span>';
      tl += `<li style="--c:${c}"><span class="node"></span><div><span class="when-t">${hhmm(l.dep)}</span>${badge(l.route)} <span class="what">${esc(N.stopName[l.from])}</span> ${rt}</div>
        <div class="sub">Direção ${esc(l.head)} · ${l.stops.length - 1} paragens · ${l.arr - l.dep} min</div>
        <details><summary>Ver paragens</summary><ol>${inter}</ol></details></li>
        <li style="--c:${c}" class="${(() => { const nx = it.legs[it.legs.indexOf(l) + 1]; return nx ? (nx.type === 'walk' ? 'walk' : '') : (it.last.type === 'uncovered' ? 'gap' : (dest.type === 'stop' && dest.stop === l.to ? '' : 'walk')); })()}"><span class="node"></span><div><span class="when-t">${hhmm(l.arr)}</span><span class="what">Sair em ${esc(N.stopName[l.to])}</span></div>
        <div class="sub">${[N.stopCode[l.to], N.zone[l.to] ? 'zona ' + N.zone[l.to] : ''].filter(Boolean).map(esc).join(' · ')}</div></li>`;
      clock = l.arr;
    }
  });

  // ultimo troco
  const fs = it.walkOnly ? -1 : it.finalStop;
  const from = ptOf(fs), to = [dest.lat, dest.lon];
  const ll = `${from[0]},${from[1]}`, dl = `${to[0]},${to[1]}`;
  const walkLink = IS_IOS
    ? `<a href="https://maps.apple.com/?saddr=${ll}&daddr=${dl}&dirflg=w" target="_blank" rel="noopener">A pé (Apple Mapas)</a>`
    : `<a href="https://www.google.com/maps/dir/?api=1&origin=${ll}&destination=${dl}&travelmode=walking" target="_blank" rel="noopener">A pé (Google Maps)</a>`;
  const links = walkLink + (IS_IOS ? `
    <a href="https://maps.apple.com/?saddr=${ll}&daddr=${dl}&dirflg=r" target="_blank" rel="noopener">Metro/comboio (Apple Mapas)</a>` : '') + `
    <a href="https://www.google.com/maps/dir/?api=1&origin=${ll}&destination=${dl}&travelmode=transit" target="_blank" rel="noopener">${IS_IOS ? 'Google Maps' : 'Metro/comboio (Google Maps)'}</a>
    <a href="https://m.uber.com/ul/?action=setPickup&pickup[latitude]=${from[0]}&pickup[longitude]=${from[1]}&dropoff[latitude]=${to[0]}&dropoff[longitude]=${to[1]}" target="_blank" rel="noopener">TVDE (Uber)</a>`;
  if (dest.type !== 'stop' || dest.stop !== fs) {
    if (it.last.type === 'uncovered') {
      addLine([from, to], { color: '#b3261e', weight: 5, dashArray: '8 8' });
      tl += `<li class="gap" style="--c:#b3261e"><span class="node"></span><div><span class="what">Troço sem STCP: ${fmtDist(it.last.m)} em linha reta</span></div>
        <div class="sub">Continue a pé, de TVDE, metro ou comboio:</div><div class="actions">${links}</div></li>`;
    } else if (it.last.m > INTERFACE.troco_final_visivel_m) {
      addLine([from, to], { color: '#5d6b69', weight: 4, dashArray: '2 8' });
      tl += `<li class="walk"><span class="node"></span><div><span class="when-t">${hhmm(clock)}</span><span class="what">A pé até ao destino</span></div>
        <div class="sub">${it.last.dur} min · ${fmtDist(it.last.m * 1.25)}</div><div class="actions">${walkLink}</div></li>`;
    }
  }
  L.marker(to, { icon: pin('end-pin') }).addTo(layer).bindPopup(esc(dest.label));
  bounds.push(to);
  const arrivedAtStop = dest.type === 'stop' && dest.stop === fs && !it.walkOnly;
  if (!arrivedAtStop) tl += `<li><span class="node" style="border-color:var(--accent)"></span><div><span class="when-t">${hhmm(it.arrive)}</span><span class="what">${esc(dest.label)}</span></div></li>`;
  if (state.me) L.marker([state.me.lat, state.me.lon], { icon: L.divIcon({ className: '', html: '<div class="me-pin"></div>', iconSize: [16, 16], iconAnchor: [8, 8] }) }).addTo(layer);

  const f = it.fare;
  $('#detail-sheet').innerHTML = `
    <div class="sum"><b style="font-size:20px">${fmtDur(it.arrive - t.min)}</b><span class="muted">chega ${hhmm(it.arrive)}</span>
      ${f && f.z ? `<span class="tag zone">Andante ${f.z}</span><span class="small">${euro(f.preco)} · validade ${fmtDur(f.dur)}</span>` : f ? '<span class="tag pv">Zona ?</span>' : ''}</div>
    ${wxLine()}
    ${f && f.z ? `<div class="small" style="margin:-4px 0 10px">Zonas atravessadas: ${f.zones.join(', ')} (1.ª validação em ${esc(f.origin)}). ${f.fonte === 'metro' ? 'Título segundo a tabela oficial do Metro do Porto.' : 'Estimativa pelas zonas das paragens; confirme no mapa de zonas Andante.'}</div>` : ''}
    <ul class="tl">${tl}</ul>`;
  setTimeout(() => { map.invalidateSize(); map.fitBounds(bounds, { padding: [30, 30], maxZoom: 16 }); }, 80);
}

