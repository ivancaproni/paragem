/**
 * Geometria e texto.
 *
 * Camada mais baixa do motor: não sabe o que é uma paragem nem um horário.
 * Não depende de nada, por isso pode ser usada em qualquer sítio sem arrastar
 * o resto do código atrás.
 */

/** Distância em linha reta entre dois pontos, em metros. */
export function dist(lat1, lon1, lat2, lon2) {
  const r = Math.PI / 180;
  const a = Math.sin((lat2 - lat1) * r / 2) ** 2 +
    Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin((lon2 - lon1) * r / 2) ** 2;
  return 12742000 * Math.asin(Math.sqrt(a));
}

/** Texto comparável: sem acentos, minúsculas, espaços normalizados. */
export function norm(s) {
  return (s || '').normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toLowerCase().replace(/\s+/g, ' ').trim();
}

/** Polyline codificada (formato do Google) para uma lista de [lat, lon]. */
export function decodePoly(str) {
  const pts = []; let i = 0, lat = 0, lon = 0;
  while (i < str.length) {
    for (const which of [0, 1]) {
      let b, shift = 0, res = 0;
      do { b = str.charCodeAt(i++) - 63; res |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
      const v = (res & 1) ? ~(res >> 1) : (res >> 1);
      if (which === 0) lat += v; else lon += v;
    }
    pts.push([lat / 1e5, lon / 1e5]);
  }
  return pts;
}
