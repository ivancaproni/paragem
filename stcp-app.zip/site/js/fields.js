/**
 * Campos de origem e destino. São o mesmo componente, usado duas vezes.
 *
 * Cada campo aceita: paragem (nome ou código), morada ou local, ponto no mapa e,
 * na origem, a localização atual. O valor guardado tem sempre a forma
 *   {type:'stop', stop, lat, lon, label, sub, key}  ou
 *   {type:'place', lat, lon, label, sub, key}
 */
import { CFG, $, state, recentes, IS_IOS, badge } from './state.js';
import { ICON } from './icons.js';
import { esc, fmtDist } from './format.js';
import * as E from './engine.js';
import { INTERFACE } from './rules.js';
import { numeroDePorta, semNumero, lerPhoton, lerNominatim, temNumero } from './moradas.js';

/** Chamado sempre que a escolha muda, para o app reavaliar o botão Buscar. */
let aoMudar = () => {};
export const quandoMudar = (fn) => { aoMudar = fn; };


export const mePlace = () => ({ type: 'place', lat: state.me.lat, lon: state.me.lon, label: 'A minha localização', sub: '', key: 'me' });
// atualiza a posicao quando o app volta ao ecra
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') locate(); });
/** Le uma posicao nova (sem cache). Usado no botao atualizar, para nao ficar
 *  a calcular a partir de onde o utilizador estava ha uns minutos. */
export function locateNow(maxWait = INTERFACE.gps_espera_ms) {
  return new Promise((resolve) => {
    if (!('geolocation' in navigator)) return resolve(false);
    let done = false;
    const finish = (ok) => { if (!done) { done = true; resolve(ok); } };
    navigator.geolocation.getCurrentPosition(
      (p) => { state.me = { lat: p.coords.latitude, lon: p.coords.longitude }; finish(true); },
      () => finish(false),
      { enableHighAccuracy: true, timeout: maxWait, maximumAge: 0 });
    setTimeout(() => finish(false), maxWait + 500);
  });
}

export function locate() {
  if (!('geolocation' in navigator)) return;
  navigator.geolocation.getCurrentPosition(
    (p) => {
      state.me = { lat: p.coords.latitude, lon: p.coords.longitude };
      // origem por omissao = posicao atual (se o utilizador ainda nao escolheu outra)
      const typing = document.activeElement === inOrigin || inOrigin.value.trim();
      if ((!state.origin && !typing) || (state.origin && state.origin.key === 'me')) setField('origin', mePlace(), { noRecent: true, noFocus: true });
      renderOriginDropdown();
    },
    () => { state.meDenied = true; renderOriginDropdown(); },
    { enableHighAccuracy: true, timeout: INTERFACE.gps_espera_fundo_ms, maximumAge: INTERFACE.gps_idade_max_ms });
}


// Cada campo aceita: paragem (nome ou codigo), morada/local, ponto no mapa e, na origem, a localizacao atual.
// Valor: {type:'stop', stop, lat, lon, label, sub, key} | {type:'place', lat, lon, label, sub, key}
export const fields = {
  origin: { input: $('#in-origin'), dd: $('#dd-origin'), step: '#step-origin', sel: null, geo: [], seq: 0, timer: null, loading: false },
  dest: { input: $('#in-dest'), dd: $('#dd-dest'), step: '#step-dest', sel: null, geo: [], seq: 0, timer: null, loading: false },
};
const inOrigin = fields.origin.input, inDest = fields.dest.input;

/** Índice da paragem pela chave guardada (código da STCP ou identificador interno). */
export function indiceDaParagem(chave) {
  const N = state.net;
  if (!N || !chave) return -1;
  const i = N.stopCode.indexOf(chave);
  return i >= 0 ? i : N.stopId.indexOf(chave);
}

/** Recentes que ainda existem na rede (as paragens mudam de nome e desaparecem). */
export function recentesValidos(kind) {
  return recentes.lista(kind).filter((x) => x.type !== 'stop' || indiceDaParagem(x.key) >= 0);
}

export function stopPlace(i) {
  const N = state.net;
  // as estações de metro não têm código próprio; nesse caso a chave é o identificador interno
  const codigo = N.stopCode[i];
  return {
    type: 'stop', stop: i, lat: N.lat[i], lon: N.lon[i], label: N.stopName[i],
    sub: codigo ? 'Paragem ' + codigo : 'Estação de metro',
    codigo,                       // só o código público da STCP; o metro não tem
    key: codigo || N.stopId[i],   // chave interna dos recentes, nunca mostrada
  };
}
export function stopItem(i, extra = '') {
  const N = state.net;
  const lines = N.linesAt(i).slice(0, 8).map(r => badge(r, 'sm')).join('');
  return `<div class="item" data-stop="${i}"><div class="ic">${ICON.stop}</div>
    <div class="tx"><div class="t1">${esc(N.stopName[i])}</div><div class="t2">${[N.stopCode[i], N.zone[i]].filter(Boolean).map(esc).join(' · ')} <span class="lines">${lines}</span></div></div>
    ${extra ? `<div class="meta">${extra}</div>` : ''}</div>`;
}
const simpleItem = (attr, icon, t1, t2 = '', meta = '') =>
  `<div class="item" ${attr}><div class="ic">${icon}</div><div class="tx"><div class="t1">${esc(t1)}</div>${t2 ? `<div class="t2">${esc(t2)}</div>` : ''}</div>${meta ? `<div class="meta">${esc(meta)}</div>` : ''}</div>`;
const MAP_ITEM = simpleItem('data-pick="map"', ICON.map, 'Escolher no mapa');

export function renderDD(kind) {
  const F = fields[kind], N = state.net;
  if (!N) { F.dd.innerHTML = kind === 'origin' ? '<div class="spinner"></div>' : ''; return; }
  if (F.sel && document.activeElement !== F.input) { F.dd.innerHTML = ''; return; }
  const q = F.sel ? '' : F.input.value.trim();
  let html = '';
  if (!q) {
    if (kind === 'origin') {
      if (state.me) {
        html += simpleItem('data-me="1"', ICON.loc, 'A minha localização', 'Procura as melhores paragens a pé');
        html += '<div class="dd-head"><span>Paragens perto de si</span></div>' +
          N.nearest(state.me.lat, state.me.lon, 4).map(x => stopItem(x.i, fmtDist(x.m))).join('');
      } else if (state.meDenied) {
        html += `<div class="small" style="padding:6px 4px">${IS_IOS
          ? 'Ative a localização (Definições › Privacidade › Serviços de localização › Safari) para ver as paragens mais próximas.'
          : 'Permita o acesso à localização no navegador para ver as paragens mais próximas.'}</div>`;
      } else {
        html += '<div class="dd-head"><span>Perto de si</span></div><div class="small" style="padding:6px 4px">A obter a sua localização…</div>';
      }
    }
    html += MAP_ITEM;
    const rec = recentesValidos(kind);
    if (rec.length) html += '<div class="dd-head"><span>Recentes</span></div>' + rec.slice(0, INTERFACE.recentes).map((x, k) =>
      x.type === 'stop' ? stopItem(indiceDaParagem(x.key)) : simpleItem(`data-recent="${k}"`, ICON.clock, x.label, x.sub || '')).join('');
  } else {
    const stops = N.search(q, 5);
    if (stops.length) html += '<div class="dd-head"><span>Paragens</span></div>' + stops.map(i => stopItem(i)).join('');
    html += '<div class="dd-head"><span>Moradas e locais</span></div>';
    // com a localização conhecida, a distância é o que distingue seis ruas com o mesmo nome
    if (F.geo.length) {
      html += F.geo.map((g, k) => simpleItem(`data-geo="${k}"`, ICON.pin, g.label, g.sub,
        state.me ? fmtDist(E.dist(state.me.lat, state.me.lon, g.lat, g.lon)) : '')).join('');
      if (F.semNumero) {
        html += `<div class="small" style="padding:6px 4px">Não encontrei o número ${esc(F.semNumero)} nesta morada.
          Escolha a rua mais provável, ou marque o ponto exato em “Escolher no mapa”.</div>`;
      }
    }
    else html += `<div class="small" style="padding:6px 4px">${F.loading ? 'A procurar…' : (q.length < INTERFACE.letras_min_morada ? `Escreva pelo menos ${INTERFACE.letras_min_morada} letras` : 'Sem moradas encontradas. Experimente “Escolher no mapa”.')}</div>`;
    html += MAP_ITEM;
  }
  F.dd.innerHTML = html;
}
export const renderOriginDropdown = () => renderDD('origin');
export const renderDestDropdown = () => renderDD('dest');

export function setField(kind, place, opts = {}) {
  const F = fields[kind];
  F.sel = place;
  state[kind] = place;
  // o código entre parênteses só aparece quando existe mesmo (o metro não tem)
  F.input.value = place.type === 'stop' && place.codigo ? `${place.label} (${place.codigo})` : place.label;
  F.input.classList.add('chosen');
  F.input.blur(); F.dd.innerHTML = '';
  if (!opts.noRecent && place.key !== 'me') {
    const { stop, ...save } = place;
    recentes.juntar(kind, { ...save, key: place.key || (place.lat.toFixed(5) + ',' + place.lon.toFixed(5)) });
  }
  aoMudar();
  if (kind === 'origin' && !state.dest && !opts.noFocus) setTimeout(() => inDest.focus(), 50);
}
export function clearField(kind, focus) {
  const F = fields[kind];
  F.sel = null; state[kind] = null; F.input.value = ''; F.input.classList.remove('chosen'); F.geo = [];
  if (focus) F.input.focus();
  renderDD(kind); aoMudar();
}

Object.keys(fields).forEach(kind => {
  const F = fields[kind];
  F.input.addEventListener('input', () => {
    F.sel = null; state[kind] = null; F.input.classList.remove('chosen'); F.geo = []; aoMudar();
    clearTimeout(F.timer);
    const q = F.input.value.trim();
    F.loading = q.length >= INTERFACE.letras_min_morada;
    renderDD(kind);
    if (q.length >= INTERFACE.letras_min_morada) F.timer = setTimeout(() => geocode(kind, q), INTERFACE.espera_a_escrever_ms);
  });
  F.input.addEventListener('focus', () => { if (F.sel) F.input.select(); renderDD(kind); });
  F.dd.addEventListener('click', (e) => {
    const s = e.target.closest('[data-stop]'), g = e.target.closest('[data-geo]'), p = e.target.closest('[data-pick]'),
      r = e.target.closest('[data-recent]'), me = e.target.closest('[data-me]');
    if (s) setField(kind, stopPlace(+s.dataset.stop));
    else if (g) setField(kind, F.geo[+g.dataset.geo]);
    else if (r) setField(kind, recentesValidos(kind)[+r.dataset.recent]);
    else if (me && state.me) setField(kind, mePlace(), { noRecent: true });
    else if (p) openPickMap(kind);
  });
});


/**
 * Procura moradas.
 *
 * Quando se escreve um número de porta e o primeiro geocodificador devolve só a rua,
 * tenta-se outra vez com o número à frente e, se ainda assim nada, pergunta-se ao
 * segundo, que indexa números de outra maneira. Se nenhum souber o número, o app
 * diz isso, em vez de deixar escolher a rua a fingir que é a morada.
 */
async function geocode(kind, q) {
  const F = fields[kind];
  const seq = ++F.seq;
  const [w, s, e, n] = CFG.BBOX;
  const perto = state.me ? `&lat=${state.me.lat}&lon=${state.me.lon}` : '&lat=41.15&lon=-8.61';
  const numero = numeroDePorta(q);
  let res = [];

  const photon = async (pergunta) => {
    const u = `${CFG.GEOCODER}?q=${encodeURIComponent(pergunta)}&limit=6&bbox=${w},${s},${e},${n}${perto}`;
    return lerPhoton(await (await fetch(u)).json(), pergunta);
  };
  const nominatim = async (pergunta) => {
    const u = `${CFG.GEOCODER_FALLBACK}?format=jsonv2&addressdetails=1&limit=6&countrycodes=pt`
      + `&bounded=1&viewbox=${w},${n},${e},${s}&q=${encodeURIComponent(pergunta)}`;
    return lerNominatim(await (await fetch(u, { headers: { 'Accept-Language': 'pt-PT' } })).json());
  };

  try { res = await photon(q); } catch { /* segue para as alternativas */ }

  if (numero && !temNumero(res)) {
    try {
      const outra = await photon(`${numero} ${semNumero(q, numero)}`);
      if (temNumero(outra)) res = outra;
    } catch { /* fica o que havia */ }
  }
  if (CFG.GEOCODER_FALLBACK && (!res.length || (numero && !temNumero(res)))) {
    try {
      const outra = await nominatim(q);
      if (outra.length && (temNumero(outra) || !res.length)) {
        res = temNumero(outra)
          ? outra.filter((r) => r.numero).concat(outra.filter((r) => !r.numero))
          : outra;
      }
    } catch { /* sem resultados */ }
  }

  if (seq !== F.seq || F.sel) return;
  F.geo = res;
  // guarda o número que ninguém encontrou, para o avisar no ecrã
  F.semNumero = numero && !temNumero(res) ? numero : null;
  F.loading = false;
  renderDD(kind);
}

let pickMap = null, pickMarker = null, pickKind = 'dest';
export function openPickMap(kind) {
  pickKind = kind;
  $('.pick-hint').textContent = kind === 'origin' ? 'Toque no mapa para marcar a origem' : 'Toque no mapa para marcar o destino';
  $('#pick-map-wrap').classList.remove('hidden'); $('.steps').classList.add('hidden');
  fields[kind].input.blur();
  if (!pickMap) {
    pickMap = L.map('pick-map', { zoomControl: false }).setView(state.me ? [state.me.lat, state.me.lon] : [41.1496, -8.6109], 14);
    L.tileLayer(CFG.TILES, { attribution: CFG.TILES_ATTR, maxZoom: 19 }).addTo(pickMap);
    pickMap.on('click', (e) => {
      if (pickMarker) pickMarker.remove();
      pickMarker = L.marker(e.latlng, { icon: L.divIcon({ className: '', html: '<div class="end-pin"></div>', iconSize: [22, 22], iconAnchor: [11, 22] }) }).addTo(pickMap);
      const kindNow = pickKind;
      setTimeout(() => {
        closePickMap();
        setField(kindNow, { type: 'place', lat: e.latlng.lat, lon: e.latlng.lng, label: 'Ponto no mapa', sub: e.latlng.lat.toFixed(5) + ', ' + e.latlng.lng.toFixed(5) });
        reverseName(kindNow, e.latlng.lat, e.latlng.lng);
      }, 250);
    });
  }
  setTimeout(() => pickMap.invalidateSize(), 50);
}
function closePickMap() { $('#pick-map-wrap').classList.add('hidden'); $('.steps').classList.remove('hidden'); }
$('#btn-pick-cancel').addEventListener('click', closePickMap);
async function reverseName(kind, lat, lon) {
  try {
    const j = await (await fetch(`https://photon.komoot.io/reverse?lat=${lat}&lon=${lon}`)).json();
    const p = (j.features && j.features[0] && j.features[0].properties) || {};
    const name = p.name || [p.street, p.housenumber].filter(Boolean).join(' ');
    const F = fields[kind];
    if (name && F.sel && F.sel.lat === lat) { F.sel.label = name; F.input.value = name; }
  } catch { /* fica 'Ponto no mapa' */ }
}

