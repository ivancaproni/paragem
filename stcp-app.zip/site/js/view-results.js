/**
 * Lista de resultados: os cartões de cada opção, a tira de meteorologia
 * e a aplicação do tempo real por cima do que já está no ecrã.
 */
import { $, state, isMetro, badge, CFG } from './state.js';
import { ICON } from './icons.js';
import { esc, hhmm, fmtDist, fmtDur, euro, deg, lisbonNow, lisbonParts } from './format.js';
import { TEMPO_REAL, AVISOS_GRAVES } from './rules.js';
import * as E from './engine.js';
import * as RT from './realtime.js';
import * as Weather from './weather.js';
import { openDetail } from './view-detail.js';

const cliente = RT.criarClienteTempoReal({ proxy: () => state.proxy });
/** Usado pelas Definições, quando o utilizador muda o endereço do proxy. */
export const limparCacheTempoReal = () => cliente.limpar();
export const obterTempoReal = (codigo) => cliente.obter(codigo);

export function chainHtml(it) {
  const parts = [];
  let walk = 0; // soma trocos a pe seguidos, para nao aparecerem em blocos separados
  const flushWalk = () => { if (walk > 0) parts.push(`<span class="walk">${ICON.walk}${walk}′</span>`); walk = 0; };
  it.legs.forEach(l => {
    if (l.type === 'ride') { flushWalk(); parts.push(badge(l.route)); }
    else if (l.type === 'walk') walk += l.dur;
  });
  if (it.last.type === 'walk') walk += it.last.dur || 0;
  flushWalk();
  if (it.last.type === 'uncovered') parts.push(`<span class="gap">+ ${fmtDist(it.last.m)} sem STCP</span>`);
  return parts.join('<span class="sep">›</span>');
}

export function fareHtml(f) {
  if (!f) return '';
  if (!f.z) return `<span class="tag pv" title="${esc(f.reason)}">Zona ?</span>`;
  return `<span class="tag zone">Andante ${f.z}</span><span>${euro(f.preco)} · ${f.zones.join(', ')}</span>`;
}

export function renderResults() {
  const N = state.net, list = $('#res-list');
  const res = state.results, t = state.query.t;
  if (!res.length) {
    const o = state.query.origin;
    const noAccess = o.type !== 'stop' && !N.accessStops(o.lat, o.lon).length;
    list.innerHTML = noAccess
      ? `<div class="empty">Não há paragens STCP a menos de 2 km desta origem.<br><br>Escolha uma paragem ou uma morada mais perto da rede STCP.</div>`
      : t.by
        ? `<div class="empty">Não há forma de chegar a este destino até às ${hhmm(t.min)} saindo daqui.<br><br>Experimente uma hora de chegada mais tarde.</div>`
        : `<div class="empty">Não encontrei ligações a partir desta origem nas próximas horas.<br><br>Experimente outra origem próxima ou outra hora.</div>`;
    return;
  }
  let html = '';
  if (res.every(r => !r.complete)) {
    html += `<div class="infoline">A STCP não chega a menos de ${fmtDist(E.EGRESS_RADIUS)} deste destino. Mostro até onde o autocarro o leva; o resto do caminho aparece a vermelho no mapa (a pé, TVDE, metro ou comboio).</div>`;
  }
  res.forEach((it, k) => {
    const first = it.legs.find(l => l.type === 'ride');
    const total = it.arrive - (t.by ? E.Network.leaveAt(it) : t.min);
    if (it.walkOnly) {
      html += `<div class="opt" data-opt="${k}"><div class="opt-top"><div class="chain"><span class="walk">${ICON.walk} Ir a pé · ${fmtDist(it.last.m)}</span></div>
        <div class="dur">${fmtDur(total)}<small>chega ${hhmm(it.arrive)}</small></div></div></div>`;
      return;
    }
    const walkBefore = it.legs[0].type === 'walk' ? it.legs[0].dur : 0;
    // a hora mostrada e a da viagem deste percurso (o tempo real substitui-a se corresponder)
    const nextBus = first.dep;
    const sair = E.Network.leaveAt(it);
    // em "chegar ate" as partidas seguintes ja chegam tarde: mostrar as anteriores
    const outras = (t.by ? N.prevDepartures(first, t.date, nextBus, 2) : N.nextDepartures(first, t.date, nextBus, 3).filter(x => x > nextBus).slice(0, 2)).map(hhmm).join(', ');
    const linha = `${isMetro(first.route) ? 'Metro' : 'Linha'} ${esc(first.route.short)} → ${esc(first.head)}`;
    html += `<div class="opt" data-opt="${k}">
      <div class="opt-top"><div class="chain">${chainHtml(it)}</div>
        <div class="dur" id="dur-${k}">${it.complete ? '' : '≈ '}${fmtDur(total)}<small>${it.complete ? 'chega' : 'estimativa c/ TVDE'} ${hhmm(it.arrive)}</small></div></div>
      <div class="next" id="next-${k}">
        <span class="big">${hhmm(t.by ? sair : nextBus)}</span>
        <span class="muted">${t.by ? 'sair' : (t.now ? 'em ' + Math.max(0, nextBus - t.min) + ' min' : '')}</span>
        <span class="tag pv">Previsão</span>
      </div>
      <div class="later">${t.by
        ? `${walkBefore ? `Caminhe ${walkBefore} min até ${esc(N.stopName[first.from])}. ` : ''}${linha} às <span id="passa-${k}">${hhmm(nextBus)}</span>${outras ? ` · antes: ${outras}` : ''}`
        : `${walkBefore ? `Caminhe ${walkBefore} min até ${esc(N.stopName[first.from])}. ` : ''}${linha}${outras ? ` · seguintes: ${outras}` : ''}`}</div>
      <div class="opt-foot">${fareHtml(it.fare)}<span>· ${it.transfers ? it.transfers + (it.transfers > 1 ? ' transbordos' : ' transbordo') : 'direto'}</span>${t.by ? `<span id="folga-${k}">· folga ${t.min - it.arrive} min</span>` : ''}</div>
      ${it.fare && it.fare.overTime ? `<div class="warnline">O percurso excede ${fmtDur(it.fare.dur)} de validade do ${it.fare.z}: a última validação tem de ser feita dentro desse tempo, senão será descontado outro título.</div>` : ''}
      ${!it.complete ? `<div class="warnline">Faltam ${fmtDist(it.last.m)} até ao destino fora da rede STCP. Toque para ver no mapa e escolher como continuar.</div>` : ''}
    </div>`;
  });
  list.innerHTML = html;
  list.querySelectorAll('[data-opt]').forEach(el => el.addEventListener('click', () => openDetail(+el.dataset.opt)));
}


/**
 * Vai buscar o tempo real de cada opção e aplica-o.
 *
 * Só pede para partidas de hoje que caiam dentro do horizonte da STCP. A decisão
 * de aceitar ou não cada chegada está em realtime.js, que é testável sem ecrã.
 */
export async function fetchRealtimeForResults() {
  const t = state.query.t;
  const agora = lisbonNow();
  if (agora.date !== t.date) return;   // viagem noutro dia: não há nada ao vivo
  const N = state.net;

  await Promise.all(state.results.map(async (it) => {
    if (it.walkOnly) return;
    const leg = it.legs.find((l) => l.type === 'ride');
    if (!leg || !N.stopCode[leg.from]) return;   // o metro não tem tempo real nesta fonte
    const alvo = leg.dep - agora.min;            // daqui a quantos minutos é esta partida
    if (!RT.dentroDoHorizonte(alvo)) return;

    const aPeAntes = it.legs[0].type === 'walk' ? it.legs[0].dur : 0;
    const data = await cliente.obter(N.stopCode[leg.from]);
    const chegada = RT.escolherChegada(data, leg, {
      minimoMin: t.now ? aPeAntes : 0, alvoMin: alvo, norm: E.norm,
    });
    if (!chegada) return;

    const vizinhas = N.nextDepartures(leg, t.date, leg.dep - TEMPO_REAL.vizinhas_recuo_min, TEMPO_REAL.vizinhas_max);
    const d = RT.decidirChegada({ depMin: leg.dep, chegadaMin: chegada.min, agoraMin: agora.min, vizinhas });
    it.rtKey = N.stopCode[leg.from] + '|' + d.quando;
    if (d.tipo === 'nota') { it.rtNote = d.quando; return; }

    const envelope = (data && !Array.isArray(data) && (data.data_source || data.source)) || '';
    it.rt = {
      min: chegada.min,
      realtime: RT.ehTempoReal(chegada.bruto, envelope, { net: N, leg, dataServico: t.date, lisbonParts }),
    };
    it.rtWhen = d.quando;
    it.shift = d.desvio;
  }));

  // não repetir a nota de um autocarro que já foi atribuído a outra opção
  const usados = new Set(state.results.filter((it) => it.rt).map((it) => it.rtKey));
  for (const it of state.results) if (it.rtNote != null && usados.has(it.rtKey)) it.rtNote = null;

  // o tempo real pode mudar a ordem: por partida mais tardia em "chegar até", por chegada nos outros
  const antes = state.results.slice();
  state.results.sort(ordenarComTempoReal(t.by));
  if (state.results.some((it, i) => it !== antes[i])) renderResults();
  state.results.forEach(applyRealtime);
}

/** Critério de ordenação depois de entrar o tempo real. Exportado para poder ser testado. */
export const ordenarComTempoReal = (porChegada) => (a, b) => (b.complete - a.complete)
  || (porChegada ? rtLeave(b) - rtLeave(a) : rtArrive(a) - rtArrive(b))
  || a.transfers - b.transfers;

export const rtArrive = (it) => it.arrive + (it.shift || 0);
export const rtLeave = (it) => E.Network.leaveAt(it) + (it.shift || 0);

/** Escreve no cartao k o que ja se sabe do tempo real (sem ir buscar nada). */
export function applyRealtime(it, k) {
  const t = state.query.t;
  const el = document.getElementById('next-' + k);
  if (!el) return;
  if (it.rtNote != null) {
    // a chegada ao vivo nao corresponde a esta viagem (autocarro ja passou, suprimido ou outro sentido)
    el.insertAdjacentHTML('beforeend', `<span class="small">tempo real desta linha: ${hhmm(it.rtNote)}</span>`);
    return;
  }
  if (!it.rt) return;
  const m = it.rt, shift = it.shift;
  const tag = `<span class="tag ${m.realtime ? 'rt' : 'pv'}">${m.realtime ? 'Tempo real' : 'Previsão'}</span>`;
  const dif = shift ? `<span class="small">${shift > 0 ? '+' : ''}${shift} min</span>` : '';
  el.innerHTML = t.by
    ? `<span class="big">${hhmm(rtLeave(it))}</span><span class="muted">sair</span>${tag}${dif}`
    : t.now
      ? `<span class="big">${m.min === 0 ? 'A chegar' : m.min + ' min'}</span><span class="muted">≈ ${hhmm(it.rtWhen)}</span>${tag}${dif}`
      : `<span class="big">${hhmm(it.rtWhen)}</span><span class="muted">em ${m.min} min</span>${tag}${dif}`;
  // a chegada acompanha o atraso/adianto do autocarro
  const dur = document.getElementById('dur-' + k);
  if (dur && shift) {
    const base = t.by ? rtLeave(it) : t.min;
    dur.innerHTML = `${it.complete ? '' : '≈ '}${fmtDur(rtArrive(it) - base)}<small>${it.complete ? 'chega ≈' : 'estimativa c/ TVDE'} ${hhmm(rtArrive(it))}</small>`;
  }
  // a hora a que o transporte passa acompanha o atraso, senão contradizia a hora de sair
  const passa = document.getElementById('passa-' + k);
  if (passa && shift) passa.textContent = hhmm(it.rtWhen);
  const folga = document.getElementById('folga-' + k);
  // se ja nao chega a horas, a folga nao faz sentido: o aviso por baixo explica
  if (folga && shift) folga.textContent = rtArrive(it) <= t.min ? `· folga ${t.min - rtArrive(it)} min` : '';
  // em "chegar ate", avisar se o atraso faz falhar a hora pedida
  const cartao = el.closest('.opt');
  if (t.by && cartao && rtArrive(it) > t.min && !cartao.querySelector('.rt-late')) {
    cartao.insertAdjacentHTML('beforeend',
      `<div class="warnline rt-late">Com o atraso do ${isMetro(it.legs.find(l => l.type === 'ride').route) ? 'metro' : 'autocarro'}, a chegada passa para as ${hhmm(rtArrive(it))}, depois das ${hhmm(t.min)} que pediu.</div>`);
  }
}


// ------------------------------------------------------------ meteorologia (origem e destino)
// nome do aviso (rules.js) -> nome do ícone (icons.js)
const WX_ICON = { umbrella: 'umbrella', snow: 'snow', coat: 'coat', water: 'water', sun: 'sun', wind: 'wind', bolt: 'bolt' };
const WHERE = { origem: 'na origem', destino: 'no destino', ambos: '' };

export async function fetchWeatherForResults() {
  if (CFG.WEATHER === false || !state.results.length) return;
  const q = state.query, best = state.results[0];
  try {
    const wx = await Weather.forTrip(
      { lat: q.origin.lat, lon: q.origin.lon }, { lat: q.dest.lat, lon: q.dest.lon },
      q.t.date, q.t.min, best.arrive);
    state.wx = wx;
    const el = $('#wx');
    el.innerHTML = `
      <div class="temps" title="Temperatura à partida e à chegada">${deg(wx.origin.temp)} <em>origem</em>
        <span class="arrow">→</span> ${deg(wx.dest.temp)} <em>destino</em>
        ${wx.showFeels ? `<em>· sente-se ${deg(wx.origin.feels)}/${deg(wx.dest.feels)}</em>` : ''}</div>
      <div class="tips">${wx.tips.map(t => `<span class="tip ${AVISOS_GRAVES.includes(t.id) ? 'alert' : ''}">${ICON[WX_ICON[t.icon]]}${esc(t.label)}${WHERE[t.where] ? ' <em style="font-style:normal;font-weight:500;opacity:.75">' + WHERE[t.where] + '</em>' : ''}</span>`).join('')}</div>`;
    el.classList.remove('hidden');
  } catch { /* sem meteorologia: o app funciona na mesma */ }
}

export function wxLine() {
  const wx = state.wx;
  if (!wx) return '';
  const tips = wx.tips.map(t => `${ICON[WX_ICON[t.icon]]}${esc(t.label)}${WHERE[t.where] ? ' ' + WHERE[t.where] : ''}`).join(' · ');
  const feels = wx.showFeels ? ` (sente-se ${deg(wx.origin.feels)} e ${deg(wx.dest.feels)}, com o vento)` : '';
  return `<div class="wx-line">À partida ${deg(wx.origin.temp)} · à chegada ${deg(wx.dest.temp)}${feels}${tips ? ' · ' + tips : ''}</div>`;
}

