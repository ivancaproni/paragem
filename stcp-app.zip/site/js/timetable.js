/**
 * HORÁRIOS - a rede como dados, e as perguntas que se lhe fazem.
 *
 * Esta camada lê o net.json para tabelas rápidas e responde a coisas como
 * "que paragens há aqui à volta", "que viagens circulam hoje", "a que horas
 * passa esta viagem nesta paragem". Não decide nada: não sabe o que é um bom
 * percurso nem quanto tempo alguém aceita andar a pé. Essas decisões estão em
 * custo.js e o algoritmo que as usa está em raptor.js.
 */
import { dist, norm } from './geo.js';
import { CUSTO } from './custo.js';
import { PERCURSO } from './rules.js';

const INF = 1e9;

export class Horarios {
  constructor(net, custo = CUSTO) {
    this.custo = custo;
    this.raw = net;
    const S = net.stops;
    this.n = S.length;
    this.stopId = S.map((s) => s[0]);
    this.stopCode = S.map((s) => s[1]);
    this.stopName = S.map((s) => s[2]);
    this.lat = Float64Array.from(S.map((s) => s[3]));
    this.lon = Float64Array.from(S.map((s) => s[4]));
    this.zone = S.map((s) => s[5] || '');
    this.routes = net.routes.map((r) => ({ short: r[0], long: r[1], color: r[2], text: r[3], type: r[4] }));
    this.calendar = net.calendar;
    this.zoneAdj = net.zoneAdj || {};
    this.zoneDist = net.zoneDist || {};
    // tabela oficial de titulos entre estacoes de metro (so vale para percursos so de metro)
    this.metroZ = net.metroZ ? net.metroZ.z : null;
    this.metroZi = new Map();
    if (net.metroZ) net.metroZ.i.forEach((stopIx, k) => this.metroZi.set(stopIx, k));
    this.used = new Uint8Array(this.n);
    (net.used || []).forEach((i) => { this.used[i] = 1; });

    // v1: tempos em minutos; v2: tempos em segundos (precisao igual a da STCP)
    const unit = (net.v || 1) >= 2 ? 60 : 1;
    this.unit = unit;
    this.patterns = net.patterns.map((p) => {
      const t = p.t;
      const nt = t.length / 3, L = p.s.length;
      const start = new Int32Array(nt), prof = new Int32Array(nt), svc = new Int32Array(nt);
      for (let j = 0; j < nt; j++) { start[j] = t[3 * j]; prof[j] = t[3 * j + 1]; svc[j] = t[3 * j + 2]; }
      const profiles = p.p.map((a) => Int32Array.from(a));
      // tempos absolutos em minutos por viagem x paragem (arredondados para baixo, como no site da STCP)
      const tm = new Int32Array(nt * L);
      const maxOff = new Int32Array(L);
      for (let j = 0; j < nt; j++) {
        const pr = profiles[prof[j]], base = j * L;
        for (let i = 0; i < L; i++) tm[base + i] = Math.floor((start[j] + pr[i]) / unit);
        for (let i = 0; i < L; i++) maxOff[i] = Math.max(maxOff[i], tm[base + i] - tm[base]);
      }
      return { r: p.r, d: p.d, h: p.h, s: p.s, sh: p.sh, L, profiles, start, prof, svc, tm, maxOff };
    });
    this.stopPatterns = Array.from({ length: this.n }, () => []);
    this.patterns.forEach((p, pi) => p.s.forEach((s, pos) => this.stopPatterns[s].push(pi, pos)));
    this.searchKey = this.stopName.map((nm, i) => norm(nm + ' ' + this.stopCode[i]));
    this._grid();
    this._footpaths();
  }

  // ------------------------------------------------------------ procura no espaco
  _grid() {
    this.cell = 0.005; // ~ 550 m
    this.grid = new Map();
    for (let i = 0; i < this.n; i++) {
      const k = Math.floor(this.lat[i] / this.cell) + ':' + Math.floor(this.lon[i] / this.cell);
      if (!this.grid.has(k)) this.grid.set(k, []);
      this.grid.get(k).push(i);
    }
  }

  /** Ligações a pé entre paragens vizinhas. O raio é uma decisão do modelo de custo. */
  _footpaths() {
    const raio = this.custo.raio.transbordo;
    this.footpaths = Array.from({ length: this.n }, () => []);
    for (let i = 0; i < this.n; i++) {
      if (!this.used[i]) continue;
      for (const j of this.near(this.lat[i], this.lon[i], raio)) {
        if (j === i || !this.used[j]) continue;
        this.footpaths[i].push(j, this.custo.minutosAPe(dist(this.lat[i], this.lon[i], this.lat[j], this.lon[j])));
      }
    }
  }

  /** paragens a menos de `radius` metros */
  near(lat, lon, radius) {
    const out = [];
    const cy = Math.floor(lat / this.cell), cx = Math.floor(lon / this.cell);
    const ry = Math.ceil(radius / 550) + 1, rx = Math.ceil(radius / 400) + 1;
    for (let y = cy - ry; y <= cy + ry; y++) for (let x = cx - rx; x <= cx + rx; x++) {
      const c = this.grid.get(y + ':' + x);
      if (!c) continue;
      for (const i of c) if (dist(lat, lon, this.lat[i], this.lon[i]) <= radius) out.push(i);
    }
    return out;
  }

  /** as k paragens mais proximas (com linhas) */
  nearest(lat, lon, k = 4) {
    let r = 300, res = [];
    while (res.length < k && r < 20000) { res = this.near(lat, lon, r).filter((i) => this.used[i]); r *= 2; }
    return res.map((i) => ({ i, m: dist(lat, lon, this.lat[i], this.lon[i]) }))
      .sort((a, b) => a.m - b.m).slice(0, k);
  }

  /** paragens a pe a partir de uma morada: alarga o raio enquanto forem poucas */
  accessStops(lat, lon) {
    const { acesso, acessoMax, acessoPasso, acessoMinParagens } = this.custo.raio;
    let r = acesso, res = [];
    while (r <= acessoMax) {
      res = this.near(lat, lon, r).filter((i) => this.used[i]);
      if (res.length >= acessoMinParagens) break;
      r += acessoPasso;
    }
    return res.map((i) => {
      const m = dist(lat, lon, this.lat[i], this.lon[i]);
      return { i, m, w: this.custo.minutosAPe(m) };
    });
  }

  /** origem: indice de paragem (compatibilidade) ou {stop?, lat, lon} */
  origem(o) {
    if (typeof o === 'number') return { stop: o, lat: this.lat[o], lon: this.lon[o] };
    if (o.stop != null) return { stop: o.stop, lat: this.lat[o.stop], lon: this.lon[o.stop] };
    return { stop: null, lat: o.lat, lon: o.lon };
  }

  // ------------------------------------------------------------ procura por texto
  search(q, limit = 30) {
    const nq = norm(q);
    if (!nq) return [];
    const words = nq.split(' ');
    const res = [];
    for (let i = 0; i < this.n; i++) {
      if (!this.used[i]) continue;
      const key = this.searchKey[i];
      if (!words.every((w) => key.includes(w))) continue;
      const score = (norm(this.stopCode[i]) === nq ? 0 : key.startsWith(nq) ? 1 : 2);
      res.push({ i, score });
    }
    res.sort((a, b) => a.score - b.score || this.stopName[a.i].localeCompare(this.stopName[b.i]));
    return res.slice(0, limit).map((r) => r.i);
  }

  /** uma linha que serve a paragem (para saber se e metro ou autocarro) */
  routeAt(stop) {
    const sp = this.stopPatterns[stop];
    return sp.length ? this.routes[this.patterns[sp[0]].r] : null;
  }

  /** linhas que passam na paragem */
  linesAt(stop) {
    const set = new Map();
    const sp = this.stopPatterns[stop];
    for (let k = 0; k < sp.length; k += 2) {
      const r = this.routes[this.patterns[sp[k]].r];
      set.set(r.short, r);
    }
    return [...set.values()].sort((a, b) => a.short.localeCompare(b.short, 'pt', { numeric: true }));
  }

  // ------------------------------------------------------------ calendario
  static addDays(iso, n) {
    const d = new Date(iso + 'T12:00:00Z');
    d.setUTCDate(d.getUTCDate() + n);
    return d.toISOString().slice(0, 10);
  }

  /** viagens ativas por padrao para uma data de servico; inclui as viagens
   *  de ontem que passam da meia-noite (horas >= 24:00), deslocadas -1440. */
  _active(dateIso) {
    if (this._actCache && this._actCache.date === dateIso) return this._actCache.list;
    const today = new Set(this.calendar[dateIso] || []);
    const yday = new Set(this.calendar[Horarios.addDays(dateIso, -1)] || []);
    const list = this.patterns.map((p) => {
      const arr = []; // pares [indice da viagem, deslocamento]
      const L = p.L, last = L - 1;
      for (let j = 0; j < p.start.length; j++) {
        if (today.has(p.svc[j])) arr.push([j, 0]);
        if (yday.has(p.svc[j]) && p.tm[j * L + last] >= 1440) arr.push([j, -1440]);
      }
      arr.sort((a, b) => (p.tm[a[0] * L] + a[1]) - (p.tm[b[0] * L] + b[1]));
      const ix = Int32Array.from(arr.map((a) => a[0])), sh = Int32Array.from(arr.map((a) => a[1]));
      const st = Int32Array.from(arr.map((a) => p.tm[a[0] * L] + a[1]));
      return { ix, sh, st };
    });
    this._actCache = { date: dateIso, list };
    return list;
  }

  hasService(dateIso) { return !!(this.calendar[dateIso] && this.calendar[dateIso].length); }

  // ------------------------------------------------------------ horas das viagens
  /** primeira viagem do padrao que passa na posicao `pos` a partir de `t` */
  _earliest(pi, act, pos, t) {
    const p = this.patterns[pi], a = act[pi], st = a.st;
    let lo = 0, hi = st.length;
    const lim = t - p.maxOff[pos];
    while (lo < hi) { const m = (lo + hi) >> 1; if (st[m] < lim) lo = m + 1; else hi = m; }
    let best = -1, bestT = INF;
    for (let j = lo; j < st.length; j++) {
      const tt = p.tm[a.ix[j] * p.L + pos] + a.sh[j];
      if (tt >= t && tt < bestT) { best = j; bestT = tt; }
      if (st[j] > bestT) break;
    }
    return best;
  }

  _time(pi, act, j, pos) { const p = this.patterns[pi], a = act[pi]; return p.tm[a.ix[j] * p.L + pos] + a.sh[j]; }

  /** hora (minutos) da viagem `trip` (indice real) na posicao `pos`, com deslocamento `shift` */
  tripTime(pi, trip, shift, pos) { const p = this.patterns[pi]; return p.tm[trip * p.L + pos] + shift; }

  /** hora exata em segundos (para comparar com o tempo real) */
  tripSec(pi, trip, shift, pos) {
    const p = this.patterns[pi];
    return (p.start[trip] + p.profiles[p.prof[trip]][pos]) * (this.unit === 60 ? 1 : 60) + shift * 60;
  }

  /** horas do horario (em segundos) de uma linha numa paragem, no dia dado */
  scheduledSecsAt(stop, routeShort, dateIso) {
    const act = this._active(dateIso), out = [];
    const sp = this.stopPatterns[stop];
    for (let x = 0; x < sp.length; x += 2) {
      const pi = sp[x], pos = sp[x + 1], p = this.patterns[pi];
      if (this.routes[p.r].short.toUpperCase() !== String(routeShort).toUpperCase()) continue;
      const a = act[pi];
      for (let j = 0; j < a.ix.length; j++) out.push(this.tripSec(pi, a.ix[j], a.sh[j], pos));
    }
    return out;
  }

  /** proximas partidas da mesma linha/sentido na paragem de embarque, a partir de `t` */
  nextDepartures(leg, dateIso, t, count = 3) {
    const act = this._active(dateIso);
    const res = [];
    const route = this.patterns[leg.pi].r;
    const sp = this.stopPatterns[leg.from];
    for (let x = 0; x < sp.length; x += 2) {
      const pi = sp[x], pos = sp[x + 1];
      const p = this.patterns[pi];
      if (p.r !== route) continue;
      const toPos = p.s.indexOf(leg.to, pos + 1);
      if (toPos < 0) continue;
      const a = act[pi];
      for (let j = 0; j < a.ix.length; j++) {
        const tt = p.tm[a.ix[j] * p.L + pos] + a.sh[j];
        if (tt >= t && tt <= t + PERCURSO.janela_partidas_min) res.push(tt);
      }
    }
    return [...new Set(res)].sort((a, b) => a - b).slice(0, count);
  }

  /** Partidas anteriores da mesma linha na mesma paragem (util em "chegar ate"). */
  prevDepartures(leg, dateIso, t, count = 2) {
    return this.nextDepartures(leg, dateIso, t - 120, 99).filter((x) => x < t).slice(-count);
  }
}

export { INF };
