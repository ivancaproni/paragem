/**
 * Tempo real da STCP.
 *
 * A API devolve, no mesmo campo, previsões ao vivo e horas tiradas do horário,
 * e devolve todas as chegadas da paragem, de várias linhas e sentidos. Este módulo
 * decide três coisas, por esta ordem:
 *   1. qual das chegadas é da linha e sentido deste percurso;
 *   2. se essa chegada é mesmo da viagem planeada ou de outra passagem da linha;
 *   3. se o valor é uma estimativa ao vivo ou apenas a hora do horário.
 *
 * Tudo aqui é função pura, tirando `criarClienteTempoReal`, que faz o pedido.
 */
import { TEMPO_REAL } from './rules.js';

/** Linhas que a API e os horários tratam por nomes diferentes. */
const ALIAS = { 107: 'ZC', ZC: '107' };

/** A resposta pode vir em vários formatos; devolve sempre uma lista. */
export function lerChegadas(data) {
  if (!data) return [];
  const arr = Array.isArray(data) ? data : (data.arrivals || data.results || data.data || []);
  return Array.isArray(arr) ? arr.filter((x) => x && typeof x === 'object') : [];
}

/** Nome da linha tal como vem na resposta, em maiúsculas. */
const nomeLinha = (a) => String(a.route_short_name ?? a.line ?? a.route ?? '').toUpperCase();

/** Minutos até à chegada. A STCP usa -1 para "a chegar", que aqui vira 0. */
const minutos = (a) => {
  const v = +(a.arrival_minutes ?? a.minutes ?? a.eta_minutes ?? NaN);
  return Number.isFinite(v) ? Math.max(0, v) : NaN;
};

/**
 * Escolhe a chegada desta viagem, ou null.
 * @param {object} data       resposta da API
 * @param {object} leg        troço do percurso ({route, head, from, dep})
 * @param {object} opcoes     {minimoMin, alvoMin, norm}
 */
export function escolherChegada(data, leg, { minimoMin = 0, alvoMin = null, norm } = {}) {
  const lista = lerChegadas(data);
  if (!lista.length || !leg || !leg.route) return null;
  const querida = String(leg.route.short).toUpperCase();
  const destino = norm ? norm(leg.head) : '';

  const candidatas = lista
    .filter((a) => {
      const curto = nomeLinha(a);
      const longo = String(a.route_long_name ?? '').toUpperCase();
      return curto === querida || longo === querida || ALIAS[querida] === curto;
    })
    .map((a) => ({ a, min: minutos(a) }))
    .filter((x) => Number.isFinite(x.min) && x.min >= minimoMin);
  if (!candidatas.length) return null;

  // preferir o mesmo sentido (destino parecido); se nenhuma bater, aceita-se qualquer uma
  const mesmoSentido = norm ? candidatas.filter((x) => {
    const h = norm(x.a.trip_headsign || x.a.headsign || x.a.destination || '');
    return !h || !destino || h.includes(destino) || destino.includes(h)
      || h.split(' ')[0] === destino.split(' ')[0];
  }) : [];
  const conjunto = mesmoSentido.length ? mesmoSentido : candidatas;

  // a chegada certa é a que fica mais perto da hora desta viagem, não a primeira da lista
  const escolhida = alvoMin == null
    ? conjunto.slice().sort((x, y) => x.min - y.min)[0]
    : conjunto.slice().sort((x, y) => Math.abs(x.min - alvoMin) - Math.abs(y.min - alvoMin))[0];
  return { min: escolhida.min, bruto: escolhida.a };
}

/**
 * A hora é uma estimativa ao vivo ou veio do horário?
 *
 * Validado contra o site da STCP em 20/09/2026: o campo `data_source` diz "realtime"
 * mesmo quando a hora é exatamente a do horário, ao segundo. Por isso a regra final
 * é comparar com os horários da linha naquela paragem.
 *
 * @param {object} a     a chegada devolvida pela API
 * @param {string} src   `data_source` do envelope da resposta
 * @param {object} ctx   {net, leg, dataServico, lisbonParts}
 */
export function ehTempoReal(a, src, ctx = {}) {
  for (const k of ['realtime', 'is_realtime', 'real_time', 'live']) {
    if (typeof a[k] === 'boolean') return a[k];
  }
  const fonte = String(a.data_source || src || '').toLowerCase();
  if (/sched|hor[aá]rio|timetable|static/.test(fonte)) return false;

  const est = a.estimated_arrival_time ? Date.parse(a.estimated_arrival_time) : NaN;
  const prev = a.scheduled_arrival_time ? Date.parse(a.scheduled_arrival_time) : NaN;
  if (Number.isFinite(est) && Number.isFinite(prev)) {
    return Math.abs(est - prev) > TEMPO_REAL.previsao_seg * 1000;
  }
  const { net, leg, dataServico, lisbonParts } = ctx;
  if (!Number.isFinite(est) || !net || !leg || !lisbonParts) return false;

  const lis = lisbonParts(new Date(est));
  let seg = lis.sec;
  const dia = dataServico || lis.date;
  if (lis.date !== dia) seg += 86400;   // depois da meia-noite ainda é o dia de serviço anterior (24:xx)
  const horario = net.scheduledSecsAt(leg.from, leg.route.short, dia);
  return !horario.some((x) => Math.abs(x - seg) <= TEMPO_REAL.previsao_seg);
}

/**
 * Esta chegada ao vivo é mesmo da viagem planeada?
 *
 * @param {object} p  {depMin, chegadaMin, agoraMin, vizinhas}
 *   - depMin:     hora do horário desta viagem (minutos desde a meia-noite)
 *   - chegadaMin: minutos que faltam segundo a API
 *   - vizinhas:   horas das outras passagens da mesma linha naquela paragem
 * @returns {{tipo:'usar'|'nota', quando:number, desvio:number, motivo?:string}}
 */
export function decidirChegada({ depMin, chegadaMin, agoraMin, vizinhas = [] }) {
  const quando = agoraMin + chegadaMin;
  const desvio = quando - depMin;
  if (Math.abs(desvio) > TEMPO_REAL.tolerancia_min) {
    return { tipo: 'nota', quando, desvio, motivo: 'longe do horário' };
  }
  // se outra passagem da linha fica mais perto da hora ao vivo, o autocarro é esse, não este
  const maisPerto = vizinhas.reduce(
    (b, x) => (Math.abs(x - quando) < Math.abs(b - quando) ? x : b), depMin);
  if (maisPerto !== depMin) {
    return { tipo: 'nota', quando, desvio, motivo: 'é de outra passagem da linha' };
  }
  return { tipo: 'usar', quando, desvio };
}

/** Vale a pena pedir tempo real para uma partida daqui a `alvoMin` minutos? */
export const dentroDoHorizonte = (alvoMin) =>
  alvoMin <= TEMPO_REAL.horizonte_min && alvoMin >= -TEMPO_REAL.atraso_max_min;

/**
 * Cliente que vai buscar o tempo real de uma paragem, com cache curta.
 * `proxy()` devolve o endereço do Worker; sem ele tenta-se a STCP diretamente,
 * o que só funciona se ela algum dia permitir CORS.
 */
export function criarClienteTempoReal({ proxy, fetchImpl, agora } = {}) {
  const cache = new Map();
  const doFetch = fetchImpl ?? ((...a) => fetch(...a));
  const now = agora ?? (() => Date.now());

  async function obter(codigo) {
    const guardado = cache.get(codigo);
    if (guardado && now() - guardado.t < TEMPO_REAL.cache_seg * 1000) return guardado.data;

    const base = (proxy && proxy()) || '';
    const url = base
      ? base.replace(/\/+$/, '') + '/rt/' + encodeURIComponent(codigo)
      : 'https://stcp.pt/api/stops/' + encodeURIComponent(codigo) + '/realtime';
    let data = null;
    try {
      const ctl = new AbortController();
      const stop = setTimeout(() => ctl.abort(), TEMPO_REAL.pedido_timeout_ms);
      const r = await doFetch(url, { signal: ctl.signal });
      clearTimeout(stop);
      if (r && r.ok) data = await r.json();
    } catch {
      data = null;   // sem rede, fora do ar ou resposta ilegível: fica só o horário
    }
    cache.set(codigo, { t: now(), data });
    return data;
  }

  return { obter, limpar: () => cache.clear() };
}
