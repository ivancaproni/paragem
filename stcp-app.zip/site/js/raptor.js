/**
 * ALGORITMO RAPTOR - percorrer a rede por rondas.
 *
 * Uma ronda = apanhar mais um transporte. Em cada ronda percorrem-se os padrões
 * que passam nas paragens alcançadas na ronda anterior e guarda-se, para cada
 * paragem, a hora mais cedo a que se lá chega (`tau`) e como se lá chegou (`par`).
 *
 * Este ficheiro não decide o que é um bom percurso: recebe o modelo de custo e
 * pergunta-lhe sempre que há uma escolha a fazer. Também não monta itinerários,
 * isso é o itinerario.js. Aqui só ficam etiquetas.
 */
import { dist } from './geo.js';
import { INF } from './timetable.js';

/**
 * Corre as rondas e devolve as etiquetas.
 * @returns {{tau: Float64Array[], par: Array[], egress: Map<number, number>, O: object}}
 */
export function rondas(H, q, custo) {
  const K = (q.maxTransfers ?? custo.transbordosMax) + 1;
  const O = H.origem(q.origin);
  const act = H._active(q.date);
  const n = H.n;
  const tau = [new Float64Array(n).fill(INF)];
  const par = [new Array(n)];
  const best = new Float64Array(n).fill(INF);
  let marked = new Set();

  // ronda 0: a origem e as paragens a que se chega a pé a partir dela
  if (O.stop != null) {
    tau[0][O.stop] = q.time; best[O.stop] = q.time; marked.add(O.stop);
    par[0][O.stop] = { type: 'origin' };
    const fp0 = H.footpaths[O.stop];
    for (let k = 0; k < fp0.length; k += 2) {
      const s = fp0[k], w = fp0[k + 1];
      if (q.time + w < tau[0][s]) {
        tau[0][s] = best[s] = q.time + w;
        par[0][s] = { type: 'walk', from: O.stop, dur: w };
        marked.add(s);
      }
    }
  } else {
    for (const a of H.accessStops(O.lat, O.lon)) {
      if (q.time + a.w < tau[0][a.i]) {
        tau[0][a.i] = best[a.i] = q.time + a.w;
        par[0][a.i] = { type: 'access', dur: a.w, m: a.m };
        marked.add(a.i);
      }
    }
  }

  // paragens onde se pode sair para chegar ao destino, e o que falta andar a pé
  const egress = new Map();
  if (q.dest.stop != null) egress.set(q.dest.stop, 0);
  for (const s of H.near(q.dest.lat, q.dest.lon, custo.raio.destino)) {
    const w = custo.minutosAPe(dist(q.dest.lat, q.dest.lon, H.lat[s], H.lon[s]));
    if (!egress.has(s) || egress.get(s) > w) egress.set(s, s === q.dest.stop ? 0 : w);
  }
  let bestTarget = INF;

  for (let k = 1; k <= K; k++) {
    tau[k] = new Float64Array(n).fill(INF);
    par[k] = new Array(n);

    // padrões a percorrer, cada um a partir da primeira paragem alcançada
    const Q = new Map();
    for (const s of marked) {
      const sp = H.stopPatterns[s];
      for (let x = 0; x < sp.length; x += 2) {
        const pi = sp[x], pos = sp[x + 1];
        if (!Q.has(pi) || Q.get(pi) > pos) Q.set(pi, pos);
      }
    }

    const newly = new Set();
    for (const [pi, p0] of Q) {
      const p = H.patterns[pi];
      let trip = -1, boardPos = -1;
      for (let pos = p0; pos < p.s.length; pos++) {
        const s = p.s[pos];
        // já dentro de um veículo: será que chegamos aqui mais cedo?
        if (trip >= 0) {
          const arr = H._time(pi, act, trip, pos);
          if (arr < Math.min(best[s], bestTarget)) {
            tau[k][s] = best[s] = arr;
            par[k][s] = {
              type: 'ride', pi, trip, from: p.s[boardPos], boardPos, pos,
              dep: H._time(pi, act, trip, boardPos), arr,
              trip: act[pi].ix[trip], shift: act[pi].sh[trip],
            };
            newly.add(s);
          }
        }
        // ou então apanha-se aqui uma viagem mais cedo do que a que trazíamos
        const prev = tau[k - 1][s];
        if (prev < INF) {
          const deTransporte = k > 1 && par[k - 1][s] && par[k - 1][s].type === 'ride';
          const ready = prev + custo.esperaNoTransbordo(deTransporte);
          if (trip < 0 || ready <= H._time(pi, act, trip, pos)) {
            const j = H._earliest(pi, act, pos, ready);
            if (j >= 0 && (trip < 0 || H._time(pi, act, j, pos) < H._time(pi, act, trip, pos))) {
              trip = j; boardPos = pos;
            }
          }
        }
      }
    }

    // transbordos a pé para paragens vizinhas
    for (const s of [...newly]) {
      const fp = H.footpaths[s];
      for (let x = 0; x < fp.length; x += 2) {
        const t2 = fp[x], w = fp[x + 1];
        const arr = tau[k][s] + w;
        if (arr < Math.min(tau[k][t2], best[t2], bestTarget)) {
          tau[k][t2] = best[t2] = arr;
          par[k][t2] = { type: 'walk', from: s, dur: w };
          newly.add(t2);
        }
      }
    }

    for (const [s, w] of egress) if (tau[k][s] + w < bestTarget) bestTarget = tau[k][s] + w;
    marked = newly;
    if (!marked.size) break;
  }

  return { tau, par, egress, O };
}

/**
 * Os melhores destinos por número de viagens (fronteira de Pareto: mais um
 * transbordo só entra na lista se chegar mesmo mais cedo).
 * @returns {{k: number, stop: number, dur: number}[]}
 */
export function alvosCompletos(tau, egress) {
  const out = [];
  let prevBest = INF;
  for (let k = 1; k < tau.length; k++) {
    let bs = -1, bt = INF;
    for (const [s, w] of egress) {
      const t = tau[k][s] + w;
      if (t < bt || (t === bt && w < (egress.get(bs) ?? INF))) { bt = t; bs = s; }
    }
    if (bs >= 0 && bt < prevBest) {
      out.push({ k, stop: bs, dur: egress.get(bs) });
      prevBest = bt;
    }
  }
  return out;
}

/**
 * Quando a rede não leva até ao destino: as paragens que mais aproximam,
 * para o utilizador fazer o resto a pé, de TVDE ou de comboio.
 * @returns {{k: number, stop: number, m: number}[]}
 */
export function alvosIncompletos(H, { tau, par, O }, q, custo) {
  const d0 = dist(O.lat, O.lon, q.dest.lat, q.dest.lon);
  const cand = [];
  for (let k = 1; k < tau.length; k++) {
    for (let s = 0; s < H.n; s++) {
      if (tau[k][s] >= INF || !par[k][s] || par[k][s].type !== 'ride') continue;
      const m = dist(H.lat[s], H.lon[s], q.dest.lat, q.dest.lon);
      if (!custo.aproximaDoDestino(m, d0)) continue;
      cand.push({ k, stop: s, m, score: custo.custoIncompleto(tau[k][s], m, k) });
    }
  }
  cand.sort((a, b) => a.score - b.score);
  return cand;
}
