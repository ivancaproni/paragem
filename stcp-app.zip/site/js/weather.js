/* Meteorologia para o percurso: condições na origem (à partida) e no destino (à chegada).
   Fonte: Open-Meteo (gratuito, sem chave, uso não comercial). */
(function (root) {
  'use strict';
  const API = 'https://api.open-meteo.com/v1/forecast';
  const CUR = 'temperature_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_gusts_10m';
  const HOUR = 'temperature_2m,apparent_temperature,precipitation,precipitation_probability,snowfall,weather_code,wind_speed_10m,wind_gusts_10m,uv_index';
  const cache = new Map(); // chave: coordenadas arredondadas -> {t, data}
  const TTL = 15 * 60 * 1000;

  const key = (pts) => pts.map(p => p.lat.toFixed(2) + ',' + p.lon.toFixed(2)).join(';');

  async function fetchPoints(pts) {
    const k = key(pts);
    const hit = cache.get(k);
    if (hit && Date.now() - hit.t < TTL) return hit.data;
    const u = `${API}?latitude=${pts.map(p => p.lat.toFixed(4)).join(',')}&longitude=${pts.map(p => p.lon.toFixed(4)).join(',')}` +
      `&current=${CUR}&hourly=${HOUR}&forecast_days=2&timezone=Europe%2FLisbon`;
    const ctl = new AbortController();
    const to = setTimeout(() => ctl.abort(), 7000);
    const r = await fetch(u, { signal: ctl.signal });
    clearTimeout(to);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    let data = await r.json();
    if (!Array.isArray(data)) data = [data];   // uma só coordenada vem como objeto
    cache.set(k, { t: Date.now(), data });
    return data;
  }

  /** condições numa localização para uma hora (minutos do dia) da data indicada */
  function at(loc, dateIso, minutes) {
    const h = loc.hourly || {};
    const stamp = `${dateIso}T${String(Math.floor((minutes % 1440) / 60)).padStart(2, '0')}:00`;
    let i = (h.time || []).indexOf(stamp);
    if (i < 0) i = 0;
    const cur = loc.current || {};
    const pick = (name, fallback) => (h[name] && h[name][i] != null ? h[name][i] : fallback);
    return {
      temp: pick('temperature_2m', cur.temperature_2m),
      feels: pick('apparent_temperature', cur.apparent_temperature),
      rain: pick('precipitation', cur.precipitation) || 0,
      prob: pick('precipitation_probability', null),
      snow: pick('snowfall', 0) || 0,
      wind: pick('wind_speed_10m', cur.wind_speed_10m) || 0,
      gust: pick('wind_gusts_10m', cur.wind_gusts_10m) || 0,
      uv: pick('uv_index', 0) || 0,
      code: pick('weather_code', cur.weather_code),
    };
  }

  // Avisos por ordem de importância. `group` evita dois avisos redundantes (ex.: dois casacos).
  // A sensação térmica da Open-Meteo já inclui o arrefecimento pelo vento; os limiares
  // estão calibrados para o Porto, onde venta quase sempre.
  const RULES = [
    { id: 'trovoada', icon: 'bolt', label: 'Trovoada', test: (c) => c.code >= 95 },
    { id: 'neve', icon: 'snow', label: 'Pode nevar', test: (c) => c.snow > 0 || (c.code >= 71 && c.code <= 77) },
    { id: 'chuva', icon: 'umbrella', label: 'Leva guarda-chuva', test: (c) => c.rain >= 0.2 || (c.prob != null && c.prob >= 40) },
    { id: 'ventania', group: 'vento', icon: 'wind', label: 'Vento muito forte',
      test: (c) => c.gust >= 55 || c.wind >= 40 },
    { id: 'frio', group: 'casaco', icon: 'coat', label: 'Leva casaco',
      test: (c) => c.feels != null && c.feels <= 12 },
    { id: 'cortavento', group: 'casaco', icon: 'wind', label: 'Leva corta-vento',
      test: (c) => c.feels != null && c.feels <= 18 && (c.wind >= 25 || c.gust >= 40) },
    { id: 'calor', icon: 'water', label: 'Calor: leva água', test: (c) => c.feels != null && c.feels >= 28 },
    { id: 'sol', icon: 'sun', label: 'Protetor solar', test: (c) => c.uv >= 7 },
  ];

  /**
   * @param {{lat,lon}} origin  @param {{lat,lon}} dest
   * @param {string} dateIso  @param {number} departMin  @param {number} arriveMin
   * @returns {Promise<{origin, dest, tips:[{id,icon,label,where}]}>}
   */
  async function forTrip(origin, dest, dateIso, departMin, arriveMin) {
    const data = await fetchPoints([origin, dest]);
    const o = at(data[0], dateIso, departMin);
    const d = at(data[1] || data[0], dateIso, arriveMin);
    const tips = [], groups = new Set();
    for (const r of RULES) {
      const inO = r.test(o), inD = r.test(d);
      if (!inO && !inD) continue;
      if (r.group && groups.has(r.group)) continue;
      if (r.group) groups.add(r.group);
      tips.push({ id: r.id, icon: r.icon, label: r.label, where: inO && inD ? 'ambos' : (inO ? 'origem' : 'destino') });
      if (tips.length === 2) break;   // no máximo dois avisos, para não encher o ecrã
    }
    // sensação térmica só quando difere claramente da temperatura (vento ou sol)
    const gap = (c) => (c.feels != null && c.temp != null && Math.abs(c.feels - c.temp) >= 3);
    return { origin: o, dest: d, tips, showFeels: gap(o) || gap(d) };
  }

  const api = { forTrip, at, RULES };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Weather = api;
})(typeof self !== 'undefined' ? self : this);
