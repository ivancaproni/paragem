/**
 * Meteorologia do percurso: condições na origem à partida e no destino à chegada.
 * Fonte: Open-Meteo (gratuito, sem chave, uso não comercial).
 *
 * Os limiares dos avisos estão em rules.js (`AVISOS`), não aqui.
 */
import { AVISOS, MOSTRAR_SENSACAO_DIF } from './rules.js';

const API = 'https://api.open-meteo.com/v1/forecast';
const AGORA = 'temperature_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_gusts_10m';
const HORA = 'temperature_2m,apparent_temperature,precipitation,precipitation_probability,snowfall,weather_code,wind_speed_10m,wind_gusts_10m,uv_index';
const VALIDADE_MS = 15 * 60 * 1000;
const TIMEOUT_MS = 7000;
const MAX_AVISOS = 2;   // mais do que isto enche o ecrã

const cache = new Map();
const chave = (pts) => pts.map((p) => p.lat.toFixed(2) + ',' + p.lon.toFixed(2)).join(';');

/** Vai buscar a previsão dos dois pontos num só pedido. Deixa passar o erro. */
async function buscarPontos(pts, fetchImpl = fetch) {
  const k = chave(pts);
  const guardado = cache.get(k);
  if (guardado && Date.now() - guardado.t < VALIDADE_MS) return guardado.data;

  const u = `${API}?latitude=${pts.map((p) => p.lat.toFixed(4)).join(',')}`
    + `&longitude=${pts.map((p) => p.lon.toFixed(4)).join(',')}`
    + `&current=${AGORA}&hourly=${HORA}&forecast_days=2&timezone=Europe%2FLisbon`;
  const ctl = new AbortController();
  const parar = setTimeout(() => ctl.abort(), TIMEOUT_MS);
  const r = await fetchImpl(u, { signal: ctl.signal });
  clearTimeout(parar);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  let data = await r.json();
  if (!Array.isArray(data)) data = [data];   // uma só coordenada vem como objeto
  cache.set(k, { t: Date.now(), data });
  return data;
}

/** Condições num ponto, à hora indicada (minutos do dia). Cai para "agora" se faltar a hora. */
export function condicoes(loc, dataIso, minutos) {
  const h = (loc && loc.hourly) || {};
  const marca = `${dataIso}T${String(Math.floor((minutos % 1440) / 60)).padStart(2, '0')}:00`;
  let i = (h.time || []).indexOf(marca);
  if (i < 0) i = 0;
  const agora = (loc && loc.current) || {};
  const ler = (nome, omissao) => (h[nome] && h[nome][i] != null ? h[nome][i] : omissao);
  return {
    temp: ler('temperature_2m', agora.temperature_2m),
    feels: ler('apparent_temperature', agora.apparent_temperature),
    rain: ler('precipitation', agora.precipitation) || 0,
    prob: ler('precipitation_probability', null),
    snow: ler('snowfall', 0) || 0,
    wind: ler('wind_speed_10m', agora.wind_speed_10m) || 0,
    gust: ler('wind_gusts_10m', agora.wind_gusts_10m) || 0,
    uv: ler('uv_index', 0) || 0,
    code: ler('weather_code', agora.weather_code),
  };
}

/**
 * Avisos a mostrar, dadas as condições na origem e no destino.
 * Função pura: é aqui que as regras de rules.js são aplicadas.
 */
export function avisos(origem, destino) {
  const saida = [];
  const grupos = new Set();
  for (const r of AVISOS) {
    const naOrigem = r.teste(origem);
    const noDestino = r.teste(destino);
    if (!naOrigem && !noDestino) continue;
    if (r.grupo && grupos.has(r.grupo)) continue;
    if (r.grupo) grupos.add(r.grupo);
    saida.push({
      id: r.id,
      icon: r.icone,
      label: r.texto,
      where: naOrigem && noDestino ? 'ambos' : (naOrigem ? 'origem' : 'destino'),
    });
    if (saida.length === MAX_AVISOS) break;
  }
  return saida;
}

/** A sensação térmica só se mostra quando difere claramente da temperatura. */
export const mostrarSensacao = (c) =>
  c.feels != null && c.temp != null && Math.abs(c.feels - c.temp) >= MOSTRAR_SENSACAO_DIF;

/** Meteorologia da viagem toda. Atira erro se a API falhar; quem chama ignora. */
export async function forTrip(origem, destino, dataIso, partidaMin, chegadaMin, fetchImpl) {
  const data = await buscarPontos([origem, destino], fetchImpl);
  const o = condicoes(data[0], dataIso, partidaMin);
  const d = condicoes(data[1] || data[0], dataIso, chegadaMin);
  return { origin: o, dest: d, tips: avisos(o, d), showFeels: mostrarSensacao(o) || mostrarSensacao(d) };
}

/** Só para os testes: esvazia a cache entre casos. */
export const limparCache = () => cache.clear();
