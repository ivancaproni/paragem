/**
 * Leitura de moradas: o que se faz com o texto escrito e com o JSON que volta
 * dos geocodificadores. Módulo puro, sem ecrã nem rede, para poder ser testado.
 */

/**
 * Número de porta escrito pelo utilizador.
 *
 * Aceita as três formas que as pessoas escrevem: "Rua X, 2469", "Rua X 93,
 * Águas Santas" e "2469 Rua X". O código postal é tirado antes de procurar,
 * senão os 4445 de "4445-512" passavam por número de porta.
 */
export function numeroDePorta(q) {
  const t = String(q || '').replace(/\b\d{4}-\d{3}\b/g, ' ').trim();
  const fim = t.match(/[\s,]+(\d{1,5})\s*[a-zA-Z]?$/);            // "Rua X, 93"
  if (fim) return fim[1];
  const antesDaVirgula = t.match(/[\s,]+(\d{1,5})\s*[a-zA-Z]?\s*,/); // "Rua X 93, Maia"
  if (antesDaVirgula) return antesDaVirgula[1];
  const inicio = t.match(/^(\d{1,5})[\s,]+\D/);                   // "93 Rua X"
  return inicio ? inicio[1] : null;
}

/**
 * Tira o número de porta do princípio ou do fim da rua, para o pôr noutro sítio.
 *
 * Só nas pontas, de propósito: há ruas com números no nome ("Rua dos 123"), e
 * apagar o número onde calhasse estragava-lhes o nome.
 */
export const semNumero = (q, n) => String(q)
  .replace(new RegExp(`^${n}\\s*[a-zA-Z]?[\\s,]+`), '')
  .replace(new RegExp(`[\\s,]+${n}\\s*[a-zA-Z]?$`), '')
  .trim();

/** "93" ou "93 A": uma parte da morada que é só o número de porta. */
const soONumero = (x) => /^\d{1,5}\s*[a-zA-Z]?$/.test(String(x).trim());

/** Converte uma resposta do Photon nas moradas que o app mostra. */
export function lerPhoton(j, q) {
  return ((j && j.features) || []).filter((f) => f && f.geometry).map((f) => {
    const p = f.properties || {};
    const rua = [p.street, p.housenumber].filter(Boolean).join(' ');
    const label = p.name || rua || p.city || q;
    const sub = [p.name && rua ? rua : '', p.district || p.locality, p.city, p.postcode]
      .filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(', ');
    const [lon, lat] = f.geometry.coordinates;
    return { type: 'place', lat, lon, label, sub, numero: p.housenumber || null };
  });
}

/** Converte uma resposta do Nominatim no mesmo formato. */
export function lerNominatim(j) {
  return (Array.isArray(j) ? j : []).filter((x) => x && x.lat).map((x) => ({
    type: 'place', lat: +x.lat, lon: +x.lon,
    label: x.name || String(x.display_name || '').split(',')[0],
    sub: String(x.display_name || '').split(',').slice(1, 4).join(',').trim(),
    numero: (x.address && x.address.house_number) || null,
  }));
}

export const temNumero = (lista) => lista.some((r) => r.numero);

/**
 * Parte a morada nas componentes que o Nominatim aceita em pesquisa estruturada.
 *
 * É assim que ele procura números de porta a sério: com a pergunta livre (`q`)
 * costuma devolver a rua e deitar o número fora, e não usa as vias de
 * interpolação, que é onde muitos números de Portugal estão registados.
 */
export function partesDaMorada(q, numero) {
  const texto = String(q || '');
  const cp = (texto.match(/\b\d{4}-\d{3}\b/) || [])[0] || null;
  const partes = texto.replace(/\b\d{4}-\d{3}\b/g, ' ')
    .split(',').map((x) => x.trim()).filter(Boolean);
  if (!partes.length) return null;
  // "12, Rua do Ouro": o número está sozinho na primeira parte, junta-se à rua
  if (numero && partes.length > 1 && soONumero(partes[0])) partes.splice(0, 2, partes[0] + ' ' + partes[1]);

  // "Rua dos 93, 93": o número está numa parte só dele, por isso o que sobra do
  // nome da rua é o nome todo, mesmo que também tenha números
  const parteDoNumero = numero ? partes.findIndex((x, i) => i > 0 && soONumero(x)) : -1;
  let rua = partes[0];
  if (numero) rua = parteDoNumero > 0 ? `${numero} ${rua}` : `${numero} ${semNumero(rua, numero)}`.trim();
  if (!rua) return null;
  // a localidade é a última parte que tenha letras, sem contar a do número
  const cidade = partes.slice(1).filter((x, i) => i + 1 !== parteDoNumero)
    .reverse().find((x) => /[a-zA-Z\u00C0-\u024F]/.test(x));
  const out = { street: rua };
  if (cidade) out.city = cidade;
  if (cp) out.postalcode = cp;
  return out;
}

/**
 * Os dígitos escritos são o nome da rua, e não um número de porta?
 *
 * "Rua dos 123" é indistinguível de "Rua X 93" só pelo texto, por isso o app
 * assume porta e tenta procurá-la. Se o geocodificador devolveu uma rua que já
 * tem esses dígitos no nome, era nome: não se avisa que "não se encontrou o
 * número", que seria mentira, nem se vai perguntar outra vez.
 */
export const numeroNoNome = (lista, n) => !!n
  && lista.some((r) => new RegExp(`(^|\\s)${n}(\\s|$)`).test(String(r.label || '')));
