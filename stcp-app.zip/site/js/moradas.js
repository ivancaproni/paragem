/**
 * Leitura de moradas: o que se faz com o texto escrito e com o JSON que volta
 * dos geocodificadores. Módulo puro, sem ecrã nem rede, para poder ser testado.
 */

/**
 * Número de porta escrito pelo utilizador ("Rua X, 2469" ou "2469 Rua X").
 * Devolve null quando não há número, para não confundir com código postal.
 */
export function numeroDePorta(q) {
  const t = String(q || '').trim();
  if (/\b\d{4}-\d{3}\b/.test(t)) return null;            // 4445-512 é código postal
  const fim = t.match(/[\s,]+(\d{1,5})\s*[a-zA-Z]?$/);
  if (fim) return fim[1];
  const inicio = t.match(/^(\d{1,5})[\s,]+\D/);
  return inicio ? inicio[1] : null;
}

/** Tira o número do texto, para o poder pôr noutro sítio da pergunta. */
export const semNumero = (q, n) => String(q).replace(new RegExp(`[\\s,]*\\b${n}\\b[\\s,]*`), ' ').trim();

/** Converte uma resposta do Photon nas moradas que o app mostra. */
export function lerPhoton(j, q) {
  return ((j && j.features) || []).filter((f) => f && f.geometry).map((f) => {
    const p = f.properties || {};
    const rua = [p.street, p.housenumber].filter(Boolean).join(' ');
    const label = p.name || rua || p.city || q;
    const sub = [p.name && rua ? rua : '', p.district || p.locality, p.city, p.postcode]
      .filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(', ');
    const [lon, lat] = f.geometry.coordinates;
    return { type: 'place', lat, lon, label, sub, numero: p.housenumber || null };
  });
}

/** Converte uma resposta do Nominatim no mesmo formato. */
export function lerNominatim(j) {
  return (Array.isArray(j) ? j : []).filter((x) => x && x.lat).map((x) => ({
    type: 'place', lat: +x.lat, lon: +x.lon,
    label: x.name || String(x.display_name || '').split(',')[0],
    sub: String(x.display_name || '').split(',').slice(1, 4).join(',').trim(),
    numero: (x.address && x.address.house_number) || null,
  }));
}

export const temNumero = (lista) => lista.some((r) => r.numero);
