/**
 * TARIFÁRIO ANDANTE - que título é preciso comprar.
 *
 * O título ocasional conta-se em anéis de zona a partir da zona onde se faz a
 * primeira validação: Z2 é a zona de partida mais uma à volta, Z3 mais duas, e
 * assim por diante. Para percursos feitos só de metro usa-se a tabela oficial
 * do Metro do Porto, que manda sobre qualquer cálculo nosso.
 *
 * Os preços e as validades estão em rules.js.
 */
import { ANDANTE } from './rules.js';

/** Quantos anéis separam cada zona de `z0`. */
export function distanciasDeZona(H, z0) {
  const d = { [z0]: 0 };
  const fila = [z0];
  while (fila.length) {
    const z = fila.shift();
    for (const y of H.zoneAdj[z] || []) if (!(y in d)) { d[y] = d[z] + 1; fila.push(y); }
  }
  // as distâncias oficiais mandam sobre o cálculo por vizinhança
  for (const [k, v] of Object.entries(H.zoneDist)) {
    const [a, b] = k.split('|');
    if (a === z0) d[b] = v; else if (b === z0) d[a] = v;
  }
  return d;
}

/** Título oficial do Metro do Porto, quando o percurso é feito só de metro. */
export function tituloMetro(H, rides) {
  if (!H.metroZ || !rides.length) return null;
  for (const r of rides) if (H.routes[H.patterns[r.pi].r].type !== 1) return null;
  const a = H.metroZi.get(rides[0].from), b = H.metroZi.get(rides[rides.length - 1].to);
  if (a == null || b == null) return null;
  const n = +H.metroZ[a][b];
  return n >= 2 ? 'Z' + n : null;
}

/** Título necessário para um itinerário; null se for tudo a pé. */
export function titulo(H, it) {
  const rides = it.legs.filter((l) => l.type === 'ride');
  if (!rides.length) return null;
  const z0 = H.zone[rides[0].from];
  const zones = new Set();
  for (const r of rides) for (const s of r.stops) zones.add(H.zone[s]);
  if (!z0 || zones.has('')) return { z: null, zones: [...zones].filter(Boolean), reason: 'zona desconhecida' };

  const d = distanciasDeZona(H, z0);
  let ring = 0, unknown = false;
  for (const z of zones) { if (!(z in d)) unknown = true; else ring = Math.max(ring, d[z]); }
  if (unknown) return { z: null, zones: [...zones], reason: 'adjacencia de zonas desconhecida' };

  let z = 'Z' + Math.max(2, ring + 1);
  const oficial = tituloMetro(H, rides);
  if (oficial) z = oficial;
  const info = ANDANTE[z] || null;
  const lastBoard = rides[rides.length - 1].dep;
  const span = lastBoard - rides[0].dep;
  return {
    z, zones: [...zones], origin: z0, fonte: oficial ? 'metro' : 'estimativa',
    preco: info ? info.preco : null, dur: info ? info.dur : null,
    overTime: info ? span > info.dur : false,
  };
}
