// Configuracao opcional. O endereco do proxy tambem pode ser colado no proprio app (Definicoes).
window.APP_CONFIG = {
  // Proxy de tempo real (Cloudflare Worker). Vem ja configurado para todos os utilizadores.
  REALTIME_PROXY: 'https://stcp-rt.ivan-955.workers.dev',
  // Pesquisa de moradas (gratuito, OpenStreetMap). Caixa limitada a Area Metropolitana do Porto.
  GEOCODER: 'https://photon.komoot.io/api/',
  GEOCODER_FALLBACK: 'https://nominatim.openstreetmap.org/search',
  BBOX: [-8.80, 40.95, -8.30, 41.45], // oeste, sul, este, norte
  TILES: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
  TILES_ATTR: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>',
};
