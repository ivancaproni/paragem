// Configuracao opcional. O endereco do proxy tambem pode ser colado no proprio app (Definicoes).
window.APP_CONFIG = {
  // Proxy de tempo real (Cloudflare Worker). Vem ja configurado para todos os utilizadores.
  REALTIME_PROXY: 'https://stcp-rt.ivan-955.workers.dev',
  // Pesquisa de moradas (gratuito, OpenStreetMap). Caixa limitada a Area Metropolitana do Porto.
  GEOCODER: 'https://photon.komoot.io/api/',
  GEOCODER_FALLBACK: 'https://nominatim.openstreetmap.org/search',
  BBOX: [-8.80, 40.95, -8.30, 41.45], // oeste, sul, este, norte
  // Avisos de meteorologia na origem e no destino (Open-Meteo, sem chave). false desliga.
  WEATHER: true,
  // Mapa base: OpenStreetMap (gratuito, sem chave; uso ligeiro com atribuicao)
  TILES: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
  TILES_ATTR: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
};
