/* Service worker: app disponivel offline e horarios atualizados em segundo plano. */
const VERSION = 'v15';
// Todos os módulos do app: se faltar algum aqui, o app deixa de abrir sem rede.
const SHELL = ['./', 'index.html', 'css/app.css', 'config.js', 'manifest.webmanifest',
  'js/app.js', 'js/rules.js', 'js/format.js', 'js/icons.js', 'js/store.js', 'js/state.js',
  'js/navigation.js', 'js/realtime.js', 'js/weather.js',
  'js/fields.js', 'js/moradas.js', 'js/view-results.js', 'js/view-detail.js',
  // motor de percursos, por camadas (ver engine.js)
  'js/engine.js', 'js/geo.js', 'js/custo.js', 'js/timetable.js', 'js/raptor.js',
  'js/itinerario.js', 'js/tarifario.js',
  'vendor/leaflet/leaflet.js', 'vendor/leaflet/leaflet.css',
  'icons/icon-192.png', 'icons/apple-touch-icon.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open('shell-' + VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => !k.endsWith(VERSION)).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return; // APIs externas: sempre rede
  if (url.pathname.includes('/data/')) {
    // horarios (ficheiros grandes): responde ja com a copia guardada e atualiza em segundo plano
    e.respondWith(caches.open('data-' + VERSION).then(async (c) => {
      const cached = await c.match(e.request, { ignoreSearch: true });
      const net = fetch(e.request).then(res => { if (res.ok) c.put(e.request, res.clone()); return res; });
      if (cached) { e.waitUntil(net.catch(() => {})); return cached; }
      return net;
    }));
    return;
  }
  // codigo: rede primeiro (para apanhar atualizacoes), cache se estiver offline
  e.respondWith(
    fetch(e.request).then(res => {
      if (res.ok) { const copy = res.clone(); caches.open('data-' + VERSION).then(c => c.put(e.request, copy)); }
      return res;
    }).catch(() => caches.match(e.request, { ignoreSearch: true }))
  );
});
