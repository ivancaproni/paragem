/**
 * Proxy para o app Próxima Paragem (Cloudflare Workers, plano gratuito).
 *
 *  /rt/{CODIGO}   -> https://stcp.pt/api/stops/{CODIGO}/realtime   (tempo real, usado pelo app)
 *  /api/...       -> https://stcp.pt/api/...                        (horarios; so para o build, se preciso)
 *  /wab/...       -> https://wab.stcp.pt/tracking/api/...           (tracados das linhas)
 *  /page/linhas   -> https://stcp.pt/pt/linhas                      (lista de linhas)
 *
 * O browser do iPhone nao pode chamar o site da STCP diretamente (CORS); este Worker faz
 * o pedido e devolve a resposta com os cabecalhos certos. So aceita GET e so estes caminhos.
 */
const ROUTES = [
  { re: /^\/rt\/([A-Za-z0-9_.-]{1,16})$/, to: (m) => `https://stcp.pt/api/stops/${encodeURIComponent(m[1].toUpperCase())}/realtime`, ttl: 15 },
  { re: /^\/api\/((?:stops|route)\/[A-Za-z0-9_.\-/]{1,80})$/, to: (m, q) => `https://stcp.pt/api/${m[1]}${q}`, ttl: 600 },
  { re: /^\/wab\/(route-stops)$/, to: (m, q) => `https://wab.stcp.pt/tracking/api/${m[1]}${q}`, ttl: 3600 },
  { re: /^\/page\/linhas$/, to: () => 'https://stcp.pt/pt/linhas', ttl: 3600 },
];

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const cors = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Max-Age': '86400',
    };
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (request.method !== 'GET') return new Response('Metodo nao permitido', { status: 405, headers: cors });

    let target = null, ttl = 15;
    for (const r of ROUTES) {
      const m = url.pathname.match(r.re);
      if (m) { target = r.to(m, url.search); ttl = r.ttl; break; }
    }
    if (!target) {
      return new Response(JSON.stringify({ ok: true, uso: '/rt/{codigo_paragem}' }),
        { headers: { ...cors, 'Content-Type': 'application/json; charset=utf-8' } });
    }

    const cache = caches.default;
    const key = new Request('https://cache.local/' + encodeURIComponent(target));
    let res = await cache.match(key);
    if (!res) {
      try {
        const up = await fetch(target, {
          headers: { 'Accept': 'application/json, text/html', 'User-Agent': 'Mozilla/5.0 (proxy pessoal de horarios)' },
        });
        const body = await up.arrayBuffer();
        res = new Response(body, {
          status: up.status,
          headers: { 'Content-Type': up.headers.get('Content-Type') || 'application/json; charset=utf-8', 'Cache-Control': `max-age=${ttl}` },
        });
        if (up.ok) ctx.waitUntil(cache.put(key, res.clone()));
      } catch (e) {
        return new Response(JSON.stringify({ error: String(e) }), { status: 502, headers: { ...cors, 'Content-Type': 'application/json' } });
      }
    }
    const out = new Response(res.body, res);
    Object.entries(cors).forEach(([k, v]) => out.headers.set(k, v));
    return out;
  },
};
