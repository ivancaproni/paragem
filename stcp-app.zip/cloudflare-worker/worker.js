/**
 * Proxy de tempo real para o app (Cloudflare Workers, plano gratuito).
 *
 * O site da STCP tem um endpoint (nao oficial) com as chegadas em tempo real
 * de cada paragem: https://stcp.pt/api/stops/{CODIGO}/realtime
 * O browser do iPhone nao o pode chamar diretamente (bloqueio CORS), por isso
 * este Worker faz o pedido e devolve a resposta com os cabecalhos certos.
 *
 * Uso:  https://<o-seu-worker>.workers.dev/rt/BCM1
 */
const ALLOWED_ORIGINS = ['*']; // opcional: troque por ['https://SEU-UTILIZADOR.github.io']

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const origin = request.headers.get('Origin') || '*';
    const allow = ALLOWED_ORIGINS.includes('*') || ALLOWED_ORIGINS.includes(origin) ? (ALLOWED_ORIGINS.includes('*') ? '*' : origin) : 'null';
    const cors = {
      'Access-Control-Allow-Origin': allow,
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Max-Age': '86400',
      'Content-Type': 'application/json; charset=utf-8',
    };
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

    const m = url.pathname.match(/^\/rt\/([A-Za-z0-9_.-]{1,16})$/);
    if (!m) {
      return new Response(JSON.stringify({ ok: true, uso: '/rt/{codigo_paragem}' }), { headers: cors });
    }

    // cache curta (15 s) para poupar pedidos a STCP
    const cache = caches.default;
    const key = new Request('https://cache.local/rt/' + m[1].toUpperCase());
    let res = await cache.match(key);
    if (!res) {
      try {
        const up = await fetch('https://stcp.pt/api/stops/' + encodeURIComponent(m[1].toUpperCase()) + '/realtime', {
          headers: { 'Accept': 'application/json', 'User-Agent': 'Mozilla/5.0 (proxy pessoal de horarios)' },
          cf: { cacheTtl: 0 },
        });
        const body = await up.text();
        res = new Response(body, { status: up.status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'max-age=15' } });
        if (up.ok) ctx.waitUntil(cache.put(key, res.clone()));
      } catch (e) {
        return new Response(JSON.stringify({ error: String(e) }), { status: 502, headers: cors });
      }
    }
    const out = new Response(res.body, res);
    Object.entries(cors).forEach(([k, v]) => out.headers.set(k, v));
    return out;
  },
};
